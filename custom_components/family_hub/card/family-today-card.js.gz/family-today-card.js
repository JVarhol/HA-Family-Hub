// FH-EINK START - source: tools/eink_kit.js, copied into each card by tools/sync_eink_kit.py
// 2026.11.1.16: E-ink screen and Accessibility for every card. Each card attaches with the bits that show a person's
// colour (dots, pills, avatars, tiles) and a little CSS of its own; this does the rest.
//  - E-ink screen (per device, from the calendar's Settings or ?fh_eink=...): black on white with outlines, no
//    shadows/blur/motion, each person's colour turned into the same pattern (black & white) or real ink (6 ink) the
//    calendar gives them, or a stronger version of it (Kaleido).
//  - Accessibility (household setting, settings.accessibility, with per-device overrides, like the rest of Settings):
//    Color vision (a shape and a pattern per person, not just a colour), High contrast (the black & white e-ink look on
//    any screen), Text size, Font (Atkinson Hyperlegible / Lexend, bundled), Reduce motion, Bigger buttons.
(function () {
if (window.__familyHubEink) return;
const MODES = ["bw", "color6", "kaleido"];
const PATTERNS = [
"linear-gradient(#000,#000)",
"repeating-linear-gradient(45deg,#000 0 3px,#fff 3px 6px)",
"radial-gradient(circle,#000 1.6px,#fff 1.9px) 0 0/6px 6px",
"repeating-linear-gradient(0deg,#000 0 2px,#fff 2px 5px)",
"repeating-linear-gradient(90deg,#000 0 2px,#fff 2px 4px)",
"repeating-linear-gradient(45deg,#000 0 1.5px,transparent 1.5px 5px),repeating-linear-gradient(-45deg,#000 0 1.5px,#fff 1.5px 5px)",
"repeating-conic-gradient(#000 0 25%,#fff 0 50%) 0 0/6px 6px",
"repeating-linear-gradient(-45deg,#000 0 6px,#fff 6px 10px)",
];
// Color vision: one shape per person, in the household's order (circle, square, diamond, hexagon, triangle, star,
// pentagon, cross) - used as a clip-path on their avatar/dot
const SHAPES = [
"circle(50% at 50% 50%)",
"inset(6% round 3px)",
"polygon(50% 0,100% 50%,50% 100%,0 50%)",
"polygon(25% 3%,75% 3%,100% 50%,75% 97%,25% 97%,0 50%)",
"polygon(50% 0,100% 95%,0 95%)",
"polygon(50% 0,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%)",
"polygon(50% 0,100% 38%,82% 100%,18% 100%,0 38%)",
"polygon(33% 0,67% 0,67% 33%,100% 33%,100% 67%,67% 67%,67% 100%,33% 100%,33% 67%,0 67%,0 33%,33% 33%)",
];
const SHAPE_NAMES = ["circle", "square", "diamond", "hexagon", "triangle", "star", "pentagon", "cross"];
const INKS = [["red", "#d0201a", 0], ["yellow", "#f0c400", 50], ["green", "#1d8a3a", 130], ["blue", "#1a4fc0", 220]];
// a dashboard link can switch E-ink screen on for the device that opens it: ?fh_eink=bw|color6|kaleido|off
// (&fh_eink_tap=off) - for a frame showing only Today or Chores, where there's no calendar Settings to do it from
function fromUrl() {
try {
const q = new URLSearchParams(window.location.search);
const m = q.get("fh_eink");
if (m && (MODES.includes(m) || m === "off")) localStorage.setItem("familyHubEinkModeLocal", m);
const t = q.get("fh_eink_tap");
if (t === "on" || t === "off") localStorage.setItem("familyHubEinkTappableLocal", t);
} catch (e) {
}
}
fromUrl();
// ---- Accessibility ----
const A11Y = {
colorVision: ["familyHubA11yColorVisionLocal", ["off", "shapes"], "off"],
highContrast: ["familyHubA11yHighContrastLocal", ["off", "on"], "off"],
textScale: ["familyHubA11yTextScaleLocal", ["100", "125", "150", "175", "200"], "100"],
font: ["familyHubA11yFontLocal", ["theme", "legible", "dyslexia"], "theme"],
motion: ["familyHubA11yMotionLocal", ["device", "always", "off"], "device"],
bigButtons: ["familyHubA11yBigButtonsLocal", ["off", "on"], "off"],
};
function a11yClean(obj) {
const out = {};
Object.keys(A11Y).forEach((k) => {
const [, ok, def] = A11Y[k];
const v = obj && obj[k] !== undefined && obj[k] !== null ? String(obj[k]) : def;
out[k] = ok.includes(v) ? v : def;
});
return out;
}
function a11yHousehold() {
try {
const v = JSON.parse(localStorage.getItem("familyHubA11yHouseholdLocal") || "{}");
return a11yClean(v && typeof v === "object" ? v : {});
} catch (e) {
return a11yClean({});
}
}
// this device's own choices ("household" or nothing = follow the household)
function a11yDevice() {
const out = {};
Object.keys(A11Y).forEach((k) => {
try {
const v = localStorage.getItem(A11Y[k][0]);
if (v && v !== "household" && A11Y[k][1].includes(v)) out[k] = v;
} catch (e) {
}
});
return out;
}
function a11y() {
const v = Object.assign(a11yHousehold(), a11yDevice());
let reduce = v.motion === "always";
if (v.motion === "device") {
try {
reduce = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
} catch (e) {
}
}
v.reduceMotion = reduce;
return v;
}
function setHousehold(obj) {
const next = JSON.stringify(a11yClean(obj || {}));
let before = null;
try {
before = localStorage.getItem("familyHubA11yHouseholdLocal");
} catch (e) {
}
if (before === next) return;
try {
localStorage.setItem("familyHubA11yHouseholdLocal", next);
} catch (e) {
}
refreshAll();
}
// every card loads the household settings itself; this reads the Accessibility part of them, at most every 5 minutes
let householdFetch = null, householdAt = 0;
function loadHousehold(hass) {
if (!hass || !hass.connection || householdFetch || Date.now() - householdAt < 5 * 60 * 1000) return;
householdFetch = hass.connection.sendMessagePromise({ type: "family_hub/get_settings" })
.then((r) => {
const s = r && r.settings;
if (s && typeof s === "object") setHousehold(s.accessibility || {});
})
.catch(() => {})
.then(() => {
householdFetch = null;
householdAt = Date.now();
});
}
let fontsAdded = false;
function ensureFonts() {
if (fontsAdded || !document.head) return;
fontsAdded = true;
const face = (family, file, weight, range) => `@font-face { font-family: "${family}"; font-style: normal; font-display: swap; font-weight: ${weight}; src: url("/family_hub_fonts/${file}.woff2") format("woff2"); unicode-range: ${range}; }`;
const LATIN = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD";
const EXT = "U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF";
const css = [];
[["FH Atkinson Hyperlegible", "atkinson-hyperlegible"], ["FH Lexend", "lexend"]].forEach(([family, file]) => {
[400, 700].forEach((w) => {
css.push(face(family, `${file}-latin-${w}-normal`, w, LATIN));
css.push(face(family, `${file}-latin-ext-${w}-normal`, w, EXT));
});
});
const st = document.createElement("style");
st.id = "family-hub-a11y-fonts";
st.textContent = css.join("\n");
document.head.appendChild(st);
}
// ---- E-ink ----
// the real E-ink screen setting of this device
function deviceMode() {
try {
const v = localStorage.getItem("familyHubEinkModeLocal");
return MODES.includes(v) ? v : "off";
} catch (e) {
return "off";
}
}
// the look: the device's E-ink screen, or High contrast (the black & white e-ink look on a normal screen)
function mode() {
const m = deviceMode();
if (m !== "off") return m;
return a11y().highContrast === "on" ? "bw" : "off";
}
function tappable() {
try {
return localStorage.getItem("familyHubEinkTappableLocal") !== "off";
} catch (e) {
return true;
}
}
function toHex(color) {
const c = String(color || "").trim().toLowerCase();
let m = c.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/);
if (m) return m[1].length === 3 ? "#" + m[1].split("").map((x) => x + x).join("") : c;
m = c.match(/^rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)(?:[ ,/]+([\d.]+))?/);
if (!m) return null;
if (m[4] !== undefined && parseFloat(m[4]) < 0.5) return null;
return "#" + [m[1], m[2], m[3]].map((n) => (+n).toString(16).padStart(2, "0")).join("");
}
function hsl(hex) {
const r = parseInt(hex.slice(1, 3), 16) / 255, g = parseInt(hex.slice(3, 5), 16) / 255, b = parseInt(hex.slice(5, 7), 16) / 255;
const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2;
let h = 0, s = 0;
if (max !== min) {
const d = max - min;
s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
h *= 60;
}
return { h, s, l };
}
// the household's people colours in order, as the calendar last worked them out on this device
function household() {
try {
const v = JSON.parse(localStorage.getItem("familyHubEinkPeopleLocal") || "[]");
return Array.isArray(v) ? v.map((x) => toHex(x)).filter(Boolean) : [];
} catch (e) {
return [];
}
}
const seen = [];
let cache = { sig: "", map: {} };
function order() {
const list = household();
seen.forEach((c) => { if (!list.includes(c)) list.push(c); });
return list;
}
// where a colour sits in the household's order (new colours join the end, in the order they're seen)
function personIndex(hex) {
let list = order();
if (!list.includes(hex)) {
seen.push(hex);
list = order();
}
return list.indexOf(hex);
}
function mapFor(m) {
const list = order();
const sig = m + "|" + list.join(",");
if (cache.sig === sig) return cache.map;
const map = {};
const used = new Set();
list.forEach((c, i) => {
if (m === "bw") {
map[c] = PATTERNS[i % PATTERNS.length];
return;
}
const x = hsl(c);
const ranked = x.s < 0.12 ? [["black", "#000", 0]] : INKS.slice().sort((a, b) => {
const d = (k) => Math.min(Math.abs(x.h - k[2]), 360 - Math.abs(x.h - k[2]));
return d(a) - d(b);
}).concat([["black", "#000", 0]]);
const free = ranked.find((ink) => !used.has(ink[0]));
if (free) {
used.add(free[0]);
map[c] = `linear-gradient(${free[1]},${free[1]})`;
} else {
map[c] = `repeating-linear-gradient(45deg,${ranked[0][1]} 0 3px,#fff 3px 6px)`;
}
});
cache = { sig, map };
return map;
}
// the background a person's colour gets on this e-ink screen; null to leave it as it is
function background(color, m) {
m = m || mode();
if (m === "off") return null;
const hex = toHex(color);
if (!hex) return null;
const x = hsl(hex);
if (x.l > 0.94) return null; // white-ish: already fine
if (m === "kaleido") return `hsl(${Math.round(x.h)} ${Math.round(Math.min(1, Math.max(0.6, x.s * 1.6 + 0.15)) * 100)}% 58%)`;
if (!household().includes(hex) && !seen.includes(hex)) seen.push(hex);
return mapFor(m)[hex];
}
// Color vision: a person's shape, a darker shade of their colour (for the shape and the pattern) and their pattern in it
function darker(hex) {
const n = (i) => Math.round(parseInt(hex.slice(i, i + 2), 16) * 0.42);
return `rgb(${n(1)}, ${n(3)}, ${n(5)})`;
}
function cvFor(color) {
const hex = toHex(color);
if (!hex || hsl(hex).l > 0.94) return null;
const i = personIndex(hex);
const dark = darker(hex);
const pattern = PATTERNS[i % PATTERNS.length].replace(/#000/g, dark).replace(/#fff/g, "transparent");
return { shape: SHAPES[i % SHAPES.length], shapeName: SHAPE_NAMES[i % SHAPE_NAMES.length], dark, pattern, index: i };
}
const BASE_CSS = `
:host([eink]) > * { --fc-bg: #fff; --fc-card: #fff; --fc-card-opaque: #fff; --fc-card-menu: #fff; --fc-surface-alt: #fff; --fc-surface2: #fff; --fc-text: #000; --fc-text-secondary: #222; --fc-text-muted: #333; --fc-border: #000; --fc-accent: #000; --fc-accent-text: #fff; --fc-accent2: #000; --fc-accent3: #000; --fc-accent-soft: #fff; --fc-shadow: none; --fc-now: #000; --fc-now-text: #fff; --fc-glass-blur: 0px; --fc-bg-blur: 0px; --fc-bg-image: none; --fc-bg-overlay-image: none; --fc-danger: #000; }
:host([eink]) *, :host([eink]) *::before, :host([eink]) *::after { transition: none !important; animation: none !important; box-shadow: none !important; text-shadow: none !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }
:host([eink]) ha-card { background: #fff !important; color: #000 !important; border: 2px solid #000 !important; border-radius: 8px !important; }
:host([eink]) button:not([data-fh-eink-dot]), :host([eink]) select, :host([eink]) input { border-color: #000 !important; }
:host([eink]) [data-fh-eink-dot] { outline: 1.5px solid #000; outline-offset: -1.5px; }
:host([eink="kaleido"]) [data-fh-eink-dot] { outline: none; }
:host([eink]) .confetti, :host([eink]) .confetti-piece, :host([eink]) .fh-confetti, :host([eink]) [class*="confetti"] { display: none !important; }
:host([eink]) .person-pill, :host([eink]) .pill { color: #000 !important; border: 2px solid #000 !important; }
:host([eink]) .person-pill *, :host([eink]) .pill * { color: #000 !important; }
:host([eink="bw"]) [data-fh-eink-strip], :host([eink="color6"]) [data-fh-eink-strip] { background: linear-gradient(90deg, transparent 0 10px, #fff 10px), var(--fh-eink-strip) !important; padding-left: 15px !important; color: #000 !important; border: 2px solid #000 !important; }
:host([eink="kaleido"]) [data-fh-eink-strip] { color: #000 !important; }
:host([eink]) button:disabled, :host([eink]) button[disabled] { background: #fff !important; color: #444 !important; border: 2px dashed #000 !important; opacity: 1 !important; }
:host([eink]) .person-pill.active-filter, :host([eink]) .pill.active { outline: 3px solid #000; outline-offset: 1px; }
:host([eink]) .person-pill.dimmed { opacity: 1 !important; border-style: dashed !important; }
:host([eink="bw"]) img, :host([eink="bw"]) .has-pic { filter: grayscale(1) contrast(1.3); }
:host([eink-static]) [class$="-fab"], :host([eink-static]) [class*="-fab "], :host([eink-static]) .fab { display: none !important; }
`;
// Accessibility styling every card shares (the calendar has the same rules for its own parts)
const A11Y_CSS = `
:host([a11y-cv]) [data-fh-cv-fill] { clip-path: var(--fh-cv-shape); border-radius: 0 !important; outline: none !important; min-width: 14px; min-height: 14px; }
:host([a11y-cv]) [data-fh-cv-strip] { background: linear-gradient(90deg, transparent 0 10px, var(--fh-cv-base) 10px), var(--fh-cv-pattern), var(--fh-cv-base) !important; padding-left: 15px !important; }
:host([a11y-cv]) [data-fh-cv-strip-avatar] .avatar:not(.has-pic), :host([a11y-cv]) [data-fh-cv-strip-avatar] .person-pill-avatar:not(.has-pic) { clip-path: var(--fh-cv-shape); border-radius: 0 !important; background: var(--fh-cv-dark) !important; color: #fff !important; }
:host([a11y-cv][eink]) [data-fh-cv-strip-avatar] .avatar:not(.has-pic), :host([a11y-cv][eink]) [data-fh-cv-strip-avatar] .person-pill-avatar:not(.has-pic) { background: #000 !important; border: none !important; }
:host([a11y-motion]) *, :host([a11y-motion]) *::before, :host([a11y-motion]) *::after { animation: none !important; transition: none !important; scroll-behavior: auto !important; }
:host([a11y-motion]) .confetti, :host([a11y-motion]) .confetti-piece, :host([a11y-motion]) [class*="confetti"] { display: none !important; }
:host([a11y-font="legible"]) > * { --fc-font-family: "FH Atkinson Hyperlegible", Verdana, sans-serif; font-family: "FH Atkinson Hyperlegible", Verdana, sans-serif !important; }
:host([a11y-font="dyslexia"]) > * { --fc-font-family: "FH Lexend", Verdana, sans-serif; font-family: "FH Lexend", Verdana, sans-serif !important; letter-spacing: 0.02em; word-spacing: 0.08em; }
:host([a11y-font]) button, :host([a11y-font]) input, :host([a11y-font]) select, :host([a11y-font]) textarea { font-family: inherit !important; letter-spacing: inherit; }
:host([a11y-scale]) > :not(style) { zoom: var(--fh-text-scale, 1); }
:host([a11y-scale]) * { -webkit-hyphens: auto; hyphens: auto; word-break: normal !important; overflow-wrap: break-word; }
:host([a11y-big]) button, :host([a11y-big]) select, :host([a11y-big]) [role="button"] { min-height: 46px; min-width: 46px; }
:host([a11y-big]) input[type="checkbox"], :host([a11y-big]) input[type="radio"] { width: 24px !important; height: 24px !important; }
:host([a11y-big]) [class$="-fab"], :host([a11y-big]) .fab { width: 72px !important; height: 72px !important; font-size: 34px !important; }
`;
const attached = new Map();
// what the kit changed on an element, so it can put it back when it's turned off
function restore(el) {
if (el.dataset.fhEinkSet === undefined) return;
el.dataset.fhEinkSet.split(",").filter(Boolean).forEach((prop) => el.style.removeProperty(prop));
if (el.dataset.fhEinkOrigBg) el.style.backgroundColor = el.dataset.fhEinkOrigBg;
const from = el.dataset.fhEinkFrom;
if (from && el.dataset.fhEinkOrig) {
if (from === "border") el.style.borderColor = el.dataset.fhEinkOrig;
else if (from.startsWith("--")) el.style.setProperty(from, el.dataset.fhEinkOrig);
}
["fhEinkFrom", "fhEinkMode", "fhEinkSet", "fhEinkOrig", "fhEinkOrigBg", "fhEinkStrip", "fhEinkDot", "fhCvFill", "fhCvStrip", "fhCvStripAvatar"].forEach((k) => delete el.dataset[k]);
}
function setProps(el, props) {
const names = [];
Object.keys(props).forEach((prop) => {
el.style.setProperty(prop, props[prop], prop.startsWith("--") ? "" : "important");
names.push(prop);
});
el.dataset.fhEinkSet = names.join(",");
}
// where a person's colour sits on an element: its background, its border, or a CSS variable (--person-color)
function colorOf(el, from) {
if (!from || from === "background") return el.style.backgroundColor;
if (from === "border") return el.style.borderTopColor || el.style.borderColor;
return el.style.getPropertyValue(from);
}
function recolor(host, st) {
const root = host.shadowRoot;
if (!root) return;
const m = mode();
const cv = a11y().colorVision === "shapes";
const key = m + (cv ? "+cv" : "");
const groups = [];
(st.opts.strip || []).forEach((sel) => groups.push([sel, "background", "strip"]));
(st.opts.stripFrom || []).forEach(([sel, from]) => groups.push([sel, from, "strip"]));
(st.opts.recolor || []).forEach((sel) => groups.push([sel, "background", "fill"]));
(st.opts.shapes || []).forEach((sel) => groups.push([sel, "background", "shape"]));
groups.forEach(([sel, from, kind]) => root.querySelectorAll(sel).forEach((el) => {
if (m === "off" && !cv) return restore(el);
if (kind !== "strip" && (el.classList.contains("has-pic") || /url\(/.test(el.style.backgroundImage || ""))) return;
const orig = el.dataset.fhEinkOrig !== undefined ? el.dataset.fhEinkOrig : colorOf(el, from);
if (!orig) return;
if (el.dataset.fhEinkOrig === orig && el.dataset.fhEinkMode === key) return;
const bg = m !== "off" && kind !== "shape" ? background(orig, m) : null;
const c = cv ? cvFor(orig) : null;
if (!bg && !c) {
if (el.dataset.fhEinkSet !== undefined) restore(el);
return;
}
if (el.dataset.fhEinkSet !== undefined) restore(el);
el.dataset.fhEinkOrig = orig;
el.dataset.fhEinkMode = key;
el.dataset.fhEinkFrom = from;
if (from === "background") el.dataset.fhEinkOrigBg = orig;
const props = {};
if (c) {
props["--fh-cv-shape"] = c.shape;
props["--fh-cv-dark"] = c.dark;
}
if (bg) {
if (kind === "fill") {
el.dataset.fhEinkDot = "1";
props.background = bg;
} else if (m === "kaleido") {
// a colour tablet keeps the person's colour, stronger: as the fill it was, or as the border/variable it came from
el.dataset.fhEinkStrip = "1";
if (from === "background") props.background = bg;
else if (from === "border") props["border-color"] = bg;
else props[from] = bg;
} else {
el.dataset.fhEinkStrip = "1";
props["--fh-eink-strip"] = bg;
}
}
if (c && (kind === "fill" || kind === "shape")) el.dataset.fhCvFill = "1";
if (c && kind === "strip" && !bg) {
// a strip down the left in the person's own pattern, over the colour the element already had
el.dataset.fhCvStrip = "1";
props["--fh-cv-pattern"] = c.pattern;
props["--fh-cv-base"] = from === "background" ? orig : `color-mix(in srgb, ${orig} 16%, white)`;
}
if (c && kind === "strip") el.dataset.fhCvStripAvatar = "1";
setProps(el, props);
}));
}
function applyA11y(host) {
const v = a11y();
const set = (name, on, value) => (on ? host.setAttribute(name, value === undefined ? "" : value) : host.removeAttribute(name));
set("a11y-cv", v.colorVision === "shapes");
set("a11y-motion", v.reduceMotion || deviceMode() !== "off");
set("a11y-big", v.bigButtons === "on");
set("a11y-font", v.font !== "theme", v.font);
set("a11y-scale", v.textScale !== "100");
if (v.textScale !== "100") host.style.setProperty("--fh-text-scale", String(parseInt(v.textScale, 10) / 100));
else host.style.removeProperty("--fh-text-scale");
if (v.font !== "theme") ensureFonts();
return v;
}
function anyA11y(v) {
return v.colorVision !== "off" || v.reduceMotion || v.bigButtons !== "off" || v.font !== "theme" || v.textScale !== "100";
}
function apply(host) {
const st = attached.get(host);
if (!st) return;
// the calendar loads the household settings itself (and hands the Accessibility part over with setHousehold)
if (!st.opts.a11yOnly) loadHousehold(host._hass || host.hass);
const v = applyA11y(host);
const root = host.shadowRoot;
if (st.opts.a11yOnly) {
// the calendar draws its own e-ink and colour vision; this just gives it the shared accessibility attributes
if (root && !root.querySelector("style[data-fh-a11y]")) {
const s = document.createElement("style");
s.setAttribute("data-fh-a11y", "");
s.textContent = A11Y_CSS;
root.appendChild(s);
}
return;
}
const m = mode();
if (m !== "off") host.setAttribute("eink", m);
else host.removeAttribute("eink");
if (deviceMode() !== "off" && !tappable()) host.setAttribute("eink-static", "");
else host.removeAttribute("eink-static");
if (!root) return;
const on = m !== "off" || anyA11y(v);
let styleEl = root.querySelector("style[data-fh-eink]");
if (on && !styleEl) {
styleEl = document.createElement("style");
styleEl.setAttribute("data-fh-eink", "");
styleEl.textContent = BASE_CSS + A11Y_CSS + (st.opts.css || "");
root.appendChild(styleEl);
} else if (!on && styleEl) {
styleEl.remove();
}
recolor(host, st);
}
function attach(host, opts, tries) {
let st = attached.get(host);
if (!st) {
st = { opts: opts || {}, obs: null, timer: null, queued: false };
attached.set(host, st);
}
if (st.obs) return;
if (!host.shadowRoot) {
if ((tries || 0) < 120) st.timer = setTimeout(() => attach(host, opts, (tries || 0) + 1), 250);
apply(host);
return;
}
st.obs = new MutationObserver(() => {
if (st.queued) return;
st.queued = true;
Promise.resolve().then(() => {
st.queued = false;
if (mode() !== "off" || anyA11y(a11y()) || host.shadowRoot.querySelector("[data-fh-eink-orig],style[data-fh-eink],style[data-fh-a11y]")) apply(host);
else if (!st.opts.a11yOnly) loadHousehold(host._hass || host.hass);
});
});
st.obs.observe(host.shadowRoot, { childList: true, subtree: true });
apply(host);
}
function detach(host) {
const st = attached.get(host);
if (!st) return;
if (st.obs) st.obs.disconnect();
clearTimeout(st.timer);
attached.delete(host);
}
const refreshAll = () => attached.forEach((st, host) => apply(host));
window.addEventListener("family-hub-eink-changed", refreshAll);
window.addEventListener("storage", (e) => { if (!e.key || /^familyHub(Eink|A11y)/.test(e.key)) refreshAll(); });
try {
if (window.matchMedia) {
const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
if (mq && mq.addEventListener) mq.addEventListener("change", refreshAll);
}
} catch (e) {
}
window.__familyHubEink = {
mode, deviceMode, tappable, background, cvFor, a11y, a11yClean, setHousehold, ensureFonts, A11Y_KEYS: A11Y, SHAPES, SHAPE_NAMES,
attach: (host, opts) => attach(host, opts, 0), detach, refreshAll, BASE_CSS, A11Y_CSS,
};
})();
// FH-EINK END
// FH-MODAL-SCROLL START - source: tools/modal_scroll_guard.js, copied into each card by tools/sync_modal_scroll_guard.py
// 2026.11.1.13: the page behind a card's open popup doesn't scroll. Home Assistant's dashboard layout can make a card's
// "fixed" popups move with the card instead of staying on screen, so scrolling under one carried the popup (and its
// buttons) away. While a popup (.modal-overlay.open) is open the page is locked, and anything that still scrolls it -
// a phone ignoring the lock, a dashboard scrolling its own container - is put straight back.
(function () {
if (window.__familyHubModalScroll) return;
if (!window.__familyCalendarSetScrollLock) {
const holders = new Set();
const render = () => {
let styleEl = document.getElementById("family-calendar-scroll-lock-style");
if (!styleEl) {
styleEl = document.createElement("style");
styleEl.id = "family-calendar-scroll-lock-style";
document.head.appendChild(styleEl);
}
styleEl.textContent = holders.size
? `html, body { overflow: hidden !important; height: 100% !important; height: 100dvh !important; overscroll-behavior: none; }`
: "";
};
window.__familyCalendarSetScrollLock = (holder, locked) => {
if (locked) holders.add(holder);
else holders.delete(holder);
render();
};
window.__familyCalendarApplyScrollLock = (locked) => window.__familyCalendarSetScrollLock(window, !!locked);
}
const watched = new Map();
const composedParent = (n) => {
const pn = n.parentNode;
return pn && pn.nodeType === 11 && pn.host ? pn.host : n.parentElement || null;
};
function sync(host) {
const st = watched.get(host);
if (!st) return;
st.queued = false;
const root = host.shadowRoot;
const open = host.isConnected && !!(root && root.querySelector(".modal-overlay.open"));
window.__familyCalendarSetScrollLock(st.key, open);
if (open && !st.guard) {
const spots = [];
for (let n = composedParent(host); n; n = composedParent(n)) {
if (n.nodeType === 1 && (n.scrollHeight > n.clientHeight + 1 || n.scrollTop)) spots.push([n, n.scrollTop]);
}
const winY = window.scrollY || 0;
st.guard = () => {
if ((window.scrollY || 0) !== winY) window.scrollTo(window.scrollX || 0, winY);
for (const [el, top] of spots) if (el.scrollTop !== top) el.scrollTop = top;
};
window.addEventListener("scroll", st.guard, { capture: true, passive: true });
} else if (!open && st.guard) {
window.removeEventListener("scroll", st.guard, { capture: true });
st.guard = null;
}
}
function attach(host, tries) {
const st = watched.get(host);
if (!st || st.obs) return;
const root = host.shadowRoot;
if (!root) {
if (tries < 120) st.timer = setTimeout(() => attach(host, tries + 1), 250);
return;
}
st.obs = new MutationObserver(() => {
if (st.queued) return;
st.queued = true;
Promise.resolve().then(() => sync(host));
});
st.obs.observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ["class"] });
sync(host);
}
window.__familyHubModalScroll = {
watch(host) {
if (watched.has(host)) return;
watched.set(host, { key: { modalOf: host }, obs: null, guard: null, timer: null, queued: false });
attach(host, 0);
},
unwatch(host) {
const st = watched.get(host);
if (!st) return;
if (st.obs) st.obs.disconnect();
clearTimeout(st.timer);
if (st.guard) window.removeEventListener("scroll", st.guard, { capture: true });
window.__familyCalendarSetScrollLock(st.key, false);
watched.delete(host);
},
};
})();
// FH-MODAL-SCROLL END
// Holiday themes, shared by every Family Hub card: a holiday background can switch the theme
// while it's showing. The backend works out the dates (family_hub/holiday_themes/get); this
// checks today against them, refreshes every 30 minutes, and tells cards to re-theme when the
// answer changes (including at midnight).
if (!window.__fhHolidayTheme) {
  window.__fhHolidayTheme = (function () {
    let schedule = null;
    let fetchedAt = 0;
    let loading = null;
    let midnightTimer = null;
    let lastId = null;
    const listeners = new Set();
    const todayKey = () => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    };
    const span = (s) => (Date.parse(s.end) - Date.parse(s.start)) || 0;
    function current() {
      if (!Array.isArray(schedule)) return "";
      const k = todayKey();
      // the most specific wins: a day beats a week, a week beats a month (same rule as the backgrounds)
      const hits = schedule.filter((s) => s && s.theme_id && s.start <= k && k <= s.end).sort((a, b) => span(a) - span(b));
      return hits.length ? hits[0].theme_id : "";
    }
    function notify() {
      const id = current();
      if (id === lastId) return;
      lastId = id;
      listeners.forEach((cb) => {
        try {
          cb();
        } catch (e) {
          // one card's error never stops the others
        }
      });
    }
    function armMidnight() {
      clearTimeout(midnightTimer);
      const now = new Date();
      const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 5);
      midnightTimer = setTimeout(() => {
        notify();
        armMidnight();
      }, next.getTime() - now.getTime());
    }
    function refresh(hass) {
      if (!hass || !hass.connection) return Promise.resolve();
      if (loading) return loading;
      loading = hass.connection
        .sendMessagePromise({ type: "family_hub/holiday_themes/get" })
        .then((r) => {
          schedule = (r && Array.isArray(r.schedule) && r.schedule) || [];
        })
        .catch(() => {
          schedule = schedule || [];
        })
        .then(() => {
          fetchedAt = Date.now();
          loading = null;
          armMidnight();
          notify();
        });
      return loading;
    }
    return {
      themeId(hass) {
        if (hass && !loading && Date.now() - fetchedAt > 30 * 60 * 1000) refresh(hass);
        return current();
      },
      subscribe(cb) {
        listeners.add(cb);
        return () => listeners.delete(cb);
      },
      invalidate(hass) {
        fetchedAt = 0;
        return refresh(hass);
      },
    };
  })();
}
// --- Family Hub shared translation helper (v1.168.76) ------------------- __fhT(key, english, vars
var __fhI18n = (window.__familyHubI18n = window.__familyHubI18n || { hass: null, fb: {}, loading: null, loaded: null });
var __fhEsc = function (s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
};
var __fhT = function (key, fb, vars, mode) {
  var g = window.__familyHubI18n || __fhI18n;
  if (g.fb[key] === undefined) g.fb[key] = fb;
  var str = "";
  try {
    if (g.hass && typeof g.hass.localize === "function") str = g.hass.localize("component.family_hub.fh_ui." + key) || "";
  } catch (e) {
    str = "";
  }
  if (!str) str = fb;
  if (mode === "h") str = __fhEsc(str);
  if (vars) {
    Object.keys(vars).forEach(function (k) {
      var v = vars[k];
      str = str.split("%" + k + "%").join(v === null || v === undefined ? "" : String(v));
    });
  }
  return str;
};
var __fhUseHass = function (hass) {
  if (hass && typeof hass.localize === "function") (window.__familyHubI18n || __fhI18n).hass = hass;
};
var __fhSweep = function (root) {
  if (!root || typeof root.querySelectorAll !== "function") return;
  var g = window.__familyHubI18n || __fhI18n;
  root.querySelectorAll("[data-fh-t]").forEach(function (el) {
    var key = el.getAttribute("data-fh-t");
    var fb = g.fb[key];
    if (fb === undefined) return;
    var cur = (el.textContent || "").trim();
    if (cur !== fb && cur !== el.__fhShown) return;
    var next = __fhT(key, fb);
    if (cur !== next) el.textContent = next;
    el.__fhShown = next;
  });
  [["data-fh-title", "title"], ["data-fh-placeholder", "placeholder"], ["data-fh-aria", "aria-label"], ["data-fh-alt", "alt"]].forEach(function (pair) {
    root.querySelectorAll("[" + pair[0] + "]").forEach(function (el) {
      var key = el.getAttribute(pair[0]);
      var fb = g.fb[key];
      if (fb === undefined) return;
      var cur = el.getAttribute(pair[1]);
      var shownKey = "__fhShown_" + pair[1];
      if (cur !== fb && cur !== el[shownKey]) return;
      var next = __fhT(key, fb);
      if (cur !== next) el.setAttribute(pair[1], next);
      el[shownKey] = next;
    });
  });
};
// -------------------------------------------------------------------------

(function () {
  if (window.__familyCalendarFontLoaded) return;
  window.__familyCalendarFontLoaded = true;
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = "https://fonts.googleapis.com/css2?family=Varela+Round&display=swap";
  document.head.appendChild(link);
})();

// A fixed accent color for reminder rows - reminders aren't tied to any one calendar (and so have no calendar color of their own)
const TODAY_REMINDER_COLOR = "#b58cd9";

// the 7 Mon-Sun day-toggle buttons used by the new Add Event modal's reminder rollover-days picker
const REMINDER_WEEKDAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

// A small, single-day companion to the full Family Week Calendar card - meant to be pasted onto any dashboard (a phone's default view
if (!window.__familyHubTimerAlarm) {
  // (timer + alarm overhaul): the on-screen half of a Family Hub timer alarm
  window.__familyHubTimerAlarm = (function () {
    let modalEl = null;
    let audioCtx = null;
    let beepHandle = null;
    const ringing = new Map(); // uid -> {title, body}
    const dismissedUids = new Set();
    let lastHass = null;
    function myClientId() {
      try {
        let id = sessionStorage.getItem("family_hub_client_id");
        if (!id) {
          id = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
          sessionStorage.setItem("family_hub_client_id", id);
        }
        return id;
      } catch (e) {
        return "";
      }
    }
    function ensureModal() {
      if (modalEl) return modalEl;
      modalEl = document.createElement("div");
      modalEl.id = "family-hub-timer-alarm-overlay";
      Object.assign(modalEl.style, {
        position: "fixed", inset: "0", zIndex: "2147483647", display: "none",
        alignItems: "center", justifyContent: "center",
        background: "rgba(20,16,8,0.78)",
      });
      modalEl.innerHTML =
        '<div class="fh-timer-alarm-box" role="alertdialog" aria-live="assertive" style="background:#fff8ea;color:#3a352c;border-radius:22px;padding:30px 26px;max-width:400px;width:88vw;max-height:86vh;overflow:auto;text-align:center;box-shadow:0 14px 46px rgba(0,0,0,0.45);font-family:-apple-system,\'Segoe UI\',Roboto,sans-serif;">' +
        '<div style="font-size:48px;margin-bottom:6px;">&#9200;</div>' +
        ('<div data-fh-t="text.time_s_up" class="fh-timer-alarm-head" style="font-size:14px;color:#96877a;margin-bottom:14px;font-weight:700;">' + __fhT("text.time_s_up", "Time's up!", null, "h") + '</div>') +
        '<div class="fh-timer-alarm-list" style="display:flex;flex-direction:column;gap:12px;"></div>' +
        ('<button data-fh-t="text.stop_all" type="button" class="fh-timer-alarm-stop-all" style="display:none;margin-top:16px;min-height:46px;width:100%;border:2px solid #8f5a00;border-radius:14px;background:transparent;color:#8f5a00;font-size:16px;font-weight:800;cursor:pointer;">' + __fhT("text.stop_all", "Stop all", null, "h") + '</button>') +
        "</div>";
      document.body.appendChild(modalEl);
      modalEl.addEventListener("click", (e) => {
        const btn = e.target.closest && e.target.closest("button");
        if (!btn) return;
        if (btn.classList.contains("fh-timer-alarm-stop-all")) {
          Array.from(ringing.keys()).forEach((uid) => stop(uid));
        } else if (btn.dataset.uid) {
          stop(btn.dataset.uid);
        }
      });
      return modalEl;
    }
    function render() {
      const el = ensureModal();
      if (!ringing.size) {
        el.style.display = "none";
        return;
      }
      const list = el.querySelector(".fh-timer-alarm-list");
      list.innerHTML = "";
      ringing.forEach((info, uid) => {
        const row = document.createElement("div");
        const title = document.createElement("div");
        title.className = "fh-timer-alarm-title";
        title.style.cssText = "font-size:1.3em;font-weight:800;margin-bottom:4px;overflow-wrap:anywhere;";
        title.textContent = info.title || __fhT("text.timer", "Timer");
        row.appendChild(title);
        if (info.body) {
          const body = document.createElement("div");
          body.style.cssText = "font-size:14px;color:#6b5f52;margin-bottom:10px;overflow-wrap:anywhere;";
          body.textContent = info.body;
          row.appendChild(body);
        }
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "fh-timer-alarm-stop";
        btn.dataset.uid = uid;
        btn.textContent = __fhT("text.stop", "Stop");
        btn.style.cssText = "min-height:54px;width:100%;border:none;border-radius:14px;background:#8f5a00;color:#fff8ea;font-size:19px;font-weight:800;cursor:pointer;";
        row.appendChild(btn);
        list.appendChild(row);
      });
      el.querySelector(".fh-timer-alarm-stop-all").style.display = ringing.size > 1 ? "" : "none";
      el.style.display = "flex";
    }
    function playBeep(atTime, freq) {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "square";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, atTime);
      gain.gain.exponentialRampToValueAtTime(0.3, atTime + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, atTime + 0.13);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(atTime);
      osc.stop(atTime + 0.15);
    }
    // A two-pitch alarm-clock trill via Web Audio (no sound file to ship).
    function beepOnce() {
      try {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === "suspended") audioCtx.resume();
        const now = audioCtx.currentTime;
        [[0, 1046], [0.15, 1318], [0.3, 1046]].forEach(([offset, freq]) => playBeep(now + offset, freq));
      } catch (e) {
        // Autoplay blocked or no Web Audio - the modal is still the alarm.
      }
    }
    // Ends whichever Family Hub screensaver is showing (they all close on
    // pointerdown on their own overlay).
    function wakeAnyScreenSaver() {
      try {
        const overlay = document.querySelector("[data-family-hub-screensaver]");
        if (overlay && overlay.style.display !== "none") {
          overlay.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true }));
        }
      } catch (e) {
        // best-effort
      }
    }
    function start(uid, title, body, hass) {
      if (hass) lastHass = hass;
      if (!uid || dismissedUids.has(uid)) return;
      const isNew = !ringing.has(uid);
      ringing.set(uid, { title: title || (ringing.get(uid) || {}).title || "Timer", body: body || (ringing.get(uid) || {}).body || "" });
      if (!isNew) return;
      wakeAnyScreenSaver();
      render();
      if (!beepHandle) {
        beepOnce();
        beepHandle = setInterval(beepOnce, 950);
      }
    }
    function stop(uid) {
      if (!uid) return;
      dismissedUids.add(uid);
      const had = ringing.delete(uid);
      if (!ringing.size && beepHandle) {
        clearInterval(beepHandle);
        beepHandle = null;
      }
      render();
      if (had && lastHass && lastHass.connection && lastHass.connection.sendMessagePromise) {
        lastHass.connection.sendMessagePromise({ type: "family_hub/timers/dismiss_alarm", uid }).catch(() => {});
      }
    }
    return {
      // From a card's 1-second countdown tick: the tab that started a timer rings the moment it reaches zero (any timer it started
      check(timers, clientId, remainingSecondsFn, hass) {
        if (hass) lastHass = hass;
        const me = clientId || myClientId();
        if (!me) return;
        (timers || []).forEach((t) => {
          if (t && t.origin_client_id && t.origin_client_id === me && !dismissedUids.has(t.uid) && remainingSecondsFn(t) <= 0) {
            start(t.uid, t.title || "Timer", "", hass);
          }
        });
      },
      // The backend's ring event (and list_active_alarms on load).
      ringBroadcast(payload, hass, myUserId) {
        if (!payload || !payload.uid || dismissedUids.has(payload.uid)) return;
        const targets = payload.target_user_ids || [];
        const fromHere = !!payload.origin_client_id && payload.origin_client_id === myClientId();
        const shouldRing = !!payload.broadcast_all || fromHere || (myUserId && targets.includes(myUserId));
        if (!shouldRing) return;
        start(payload.uid, payload.timer_title || payload.title, payload.body, hass);
      },
      // Someone stopped it somewhere else.
      stopFromServer(uid) {
        if (!uid) return;
        dismissedUids.add(uid);
        if (ringing.delete(uid)) {
          if (!ringing.size && beepHandle) {
            clearInterval(beepHandle);
            beepHandle = null;
          }
          render();
        }
      },
      _ringing() {
        return Array.from(ringing.keys());
      },
    };
  })();
}

// Theme flash-of-default fix - Root cause: EVERY themed card's first paint happens with no theme CSS vars set at all
if (!window.__familyHubThemeCache) {
  window.__familyHubThemeCache = (function () {
    const STORAGE_PREFIX = "familyHubThemeVarsCache::";
    const memory = new Map(); // key -> {varName: value}

    function get(key) {
      if (memory.has(key)) return memory.get(key);
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + key);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === "object") {
            memory.set(key, parsed);
            return parsed;
          }
        }
      } catch (e) {
        // Corrupt/blocked localStorage (private browsing, etc.) - just
        // means no cache to apply this time, same as a first-ever load.
      }
      return null;
    }
    function set(key, vars) {
      memory.set(key, vars);
      try {
        localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(vars));
      } catch (e) {
        // Best-effort only - the in-memory copy above still helps every OTHER card mounted later in this same page load even if localStorage itself
      }
    }
    return { get, set };
  })();
}

class FamilyTodayCard extends HTMLElement {
  // 2026.11.1.16: this card's own e-ink styling, on top of the shared kit (FH-EINK)
  static get EINK_CSS() {
    return `
:host([eink]) .card-root { background: #fff !important; color: #000 !important; border: 2px solid #000 !important; border-radius: 8px !important; }
:host([eink]) .row .dot:not(.has-pic) { width: 14px; height: 14px; }
:host([eink]) .row.is-now { background: #000 !important; color: #fff !important; border-radius: 6px; }
:host([eink]) .row.is-now * { color: #fff !important; }
:host([eink]) .row.is-now .dot:not(.has-pic) { outline-color: #fff; }
:host([eink]) .custody-badge { color: #000 !important; border: 1.5px solid #000; }
:host([eink="bw"]) .custody-badge, :host([eink="color6"]) .custody-badge { color: #fff !important; }
`;
  }
  // Lets the card be added via the dashboard's "+ Add Card" picker with working defaults straight away
  static getStubConfig() {
    return { title: "Today" };
  }
  // Uses Home Assistant's built-in schema-based form editor rather than a hand-built custom editor element
  static _configSchema() {
    return [
      { name: "title", selector: { text: {} } },
      { name: "calendar_dashboard_path", selector: { text: {} } },
      { name: "calendar_button_label", selector: { text: {} } },
      // That's the Month Split view's day-detail panel (family-week-calendar-card.js's own _buildMonthSplitDetailHtml/.msd-* CSS)
      { name: "layout", selector: { select: { mode: "dropdown", options: [
        { value: "sectioned", label: "Sectioned (Events / Meals / Reminders) - default" },
        { value: "compact", label: "Compact (Month view's Today panel style)" },
      ] } } },
      // Off by default (like calendar_dashboard_path) so nothing
      // new appears on an existing dashboard until a household opts in.
      { name: "show_add_button", selector: { boolean: {} } },
      // the lists and weather come from the main Family Hub calendar card automatically
      {
        name: "",
        type: "expandable",
        flatten: true,
        title: "Advanced: use different lists than the calendar card",
        schema: [
          { name: "meal_plan_entity", selector: { entity: { domain: "todo" } } },
          { name: "reminders_entity", selector: { entity: { domain: "todo" } } },
          { name: "weather_entity", selector: { entity: { domain: "weather" } } },
          { name: "settings_entity", selector: { entity: { domain: "todo" } } },
        ],
      },
    ];
  }
  static _computeLabel(schema) {
    const labels = {
      title: "Title",
      settings_entity: "Old Settings to-do list (very old installs only)",
      meal_plan_entity: "Meal plan to-do list",
      reminders_entity: "Reminders to-do list",
      weather_entity: "Weather entity",
      calendar_dashboard_path: "Calendar dashboard path",
      calendar_button_label: "Calendar button label",
      theme_override: "Theme",
      layout: "Layout",
      show_add_button: "Show an Add button",
    };
    return labels[schema.name] || undefined;
  }
  static _computeHelper(schema) {
    if (schema.name === "meal_plan_entity" || schema.name === "reminders_entity" || schema.name === "weather_entity") {
      return "Leave blank to use the same one as your Family Hub calendar card.";
    }
    if (schema.name === "settings_entity") {
      return "Leave blank. Family Hub keeps its settings itself now; this is only read on installs that haven't been updated in a long time.";
    }
    if (schema.name === "calendar_dashboard_path") {
      return "Optional. Set a relative path (e.g. /lovelace-family/0) and a 'Go to Calendar' button appears at the bottom of the card, jumping straight to your full calendar dashboard/view.";
    }
    if (schema.name === "theme_override") {
      return "Pin this one card to a specific theme, or leave on \"Use device settings\" to follow the household's own Global Theme.";
    }
    if (schema.name === "layout") {
      return "Compact matches the single scrolling list style of the Month Split view's day panel (meals and events/reminders mixed together by time); Sectioned keeps today's three separate labeled lists.";
    }
    if (schema.name === "show_add_button") {
      return "Adds a button next to Go to Calendar that opens the same Add Event modal as the full calendar card, for adding a calendar event or a reminder without leaving this card.";
    }
    return undefined;
  }
  static getConfigElement() {
    return document.createElement("family-today-card-editor");
  }
  setConfig(config) {
    config = config || {};
    const palette = ["#a9c6c2", "#dba99c", "#d9bf7e", "#a8bd93", "#b9a7c9", "#cf8f6c", "#a89a83"];
    const rawPeople = Array.isArray(config.people) ? config.people : [];
    this._config = {
      title: config.title || "Today",
      people: rawPeople.map((p, i) => ({
        entity: p.entity,
        name: p.name || p.entity,
        color: p.color || palette[i % palette.length],
        badges: Array.isArray(p.badges) ? p.badges : [],
      })),
      meal_plan_entity: config.meal_plan_entity || "todo.meal_plan",
      reminders_entity: config.reminders_entity || "todo.family_reminders",
      settings_entity: config.settings_entity || "todo.family_calendar_settings",
      weather_entity: config.weather_entity || "weather.forecast_home",
      // Optional footer button that jumps straight to a full calendar dashboard/view
      calendar_dashboard_path: (config.calendar_dashboard_path || "").toString().trim(),
      calendar_button_label: (config.calendar_button_label || "").toString().trim(),
      // Accepted (and ignored) so the exact same YAML block used for the
      // full family-week-calendar-card can be pasted in here unedited.
      recipe_entity: config.recipe_entity || "todo.recipe_box",
      meal_templates_entity: config.meal_templates_entity || "todo.meal_plan_templates",
      suggestions_entity: config.suggestions_entity || "todo.meal_suggestions",
      birthdays_entity: config.birthdays_entity || "calendar.birthdays",
      theme_override: typeof config.theme_override === "string" ? config.theme_override : "",
      layout: config.layout === "compact" ? "compact" : "sectioned",
      // see _configSchema's own comment on this field.
      show_add_button: !!config.show_add_button,
    };
    // v1.168.85: what this card's own config actually says (blank = "use
    // the calendar card's") - _applySharedEntities decides the real lists.
    const explicit = (v) => (typeof v === "string" ? v.trim() : "");
    this._configExplicit = {
      meal_plan_entity: explicit(config.meal_plan_entity),
      reminders_entity: explicit(config.reminders_entity),
      weather_entity: explicit(config.weather_entity),
    };
    if (this._settingsCache === undefined) this._settingsCache = null;
    this._applySharedEntities();
    if (this._globalThemes === undefined) this._globalThemes = [];
    if (this._todayEvents === undefined) this._todayEvents = [];
    if (this._todayBadges === undefined) this._todayBadges = [];
    if (this._todayMeals === undefined) this._todayMeals = [];
    if (this._todayReminders === undefined) this._todayReminders = [];
    if (this._forecastToday === undefined) this._forecastToday = null;
    if (this._mealPlanRaw === undefined) this._mealPlanRaw = {};
    if (this._recurringMeals === undefined) this._recurringMeals = [];
    if (this._firstLoadPromise === undefined) this._firstLoadPromise = null;
    if (!this._built) this._build();
    // a full _render() (not just _renderHeader()) so toggling the new layout field live in the card editor's preview actually re-paints the body
    this._render();
  }
  set hass(hass) {
    const first = !this._hass;
    this._hass = hass;
    this._ensureTranslationsLoaded();
    if (first) {
      this._firstLoadPromise = this._initFirstLoad();
    }
  }
  _t(key, fallback, vars) {
    let str = "";
    try {
      if (this._hass && typeof this._hass.localize === "function") {
        str = this._hass.localize(`component.family_hub.fh_ui.${key}`) || "";
      }
    } catch (e) {
      str = "";
    }
    if (!str) str = fallback;
    if (vars) {
      Object.keys(vars).forEach((k) => {
        str = str.split(`%${k}%`).join(vars[k]);
      });
    }
    return str;
  }
  _baseLanguage(lang) {
    return (lang || "en").split("-")[0].toLowerCase();
  }
  _ensureTranslationsLoaded() {
    __fhUseHass(this._hass);
    if (!this._hass || typeof this._hass.loadBackendTranslation !== "function") return;
    const lang = this._baseLanguage(this._hass.language);
    if (this._i18nLoadedLang === lang) {
      // Home Assistant hands cards the hass object that actually knows the newly loaded strings a moment AFTER loadBackendTranslation resolves
      if (this._hass.localize !== this._i18nLocalize) {
        this._i18nLocalize = this._hass.localize;
        // redraw only when our strings changed - a new localize function alone made cards flicker (GitHub issue #16)
        let probe = "";
        try { probe = this._hass.localize("component.family_hub.fh_ui.nav.settings") || ""; } catch (e) { probe = ""; }
        probe = `${this._hass.language}|${probe}`;
        if (probe !== this._i18nLastProbe) {
          this._i18nLastProbe = probe;
          this._onTranslationsReady();
        }
      }
      return;
    }
    if (this._i18nLoading === lang) return;
    this._i18nLoading = lang;
    this._hass
      .loadBackendTranslation("fh_ui", "family_hub")
      .then(() => {
        this._i18nLoadedLang = lang;
        this._i18nLoading = null;
        this._i18nLocalize = this._hass.localize;
        this._onTranslationsReady();
      })
      .catch((e) => {
        this._i18nLoading = null;
        console.warn("[family_hub] failed to load \"" + lang + "\" translations - staying on English fallback text", e);
      });
  }
  // (GitHub issue #10): dates and times follow the Home Assistant user's own language and time format (Profile > Language / Time format)
  _uiLocale() {
    const h = this._hass;
    const lang = (h && h.locale && h.locale.language) || (h && h.language) || "";
    return lang || undefined;
  }
  _uiHour12() {
    const h = this._hass;
    const tf = h && h.locale && h.locale.time_format;
    if (tf === "12") return true;
    if (tf === "24") return false;
    if (tf === "system") {
      try {
        return new Intl.DateTimeFormat(undefined, { hour: "numeric" }).resolvedOptions().hour12;
      } catch (e) {
        return undefined;
      }
    }
    return undefined;
  }
  _fmtDate(d, opts) {
    try {
      return d.toLocaleDateString(this._uiLocale(), opts);
    } catch (e) {
      return d.toLocaleDateString(undefined, opts);
    }
  }
  _fmtTimeOfDay(d) {
    const opts = { hour: "numeric", minute: "2-digit" };
    const hour12 = this._uiHour12();
    if (hour12 !== undefined) opts.hour12 = hour12;
    try {
      return d.toLocaleTimeString(this._uiLocale(), opts);
    } catch (e) {
      return d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
    }
  }
  _fmtDateTime(d) {
    const opts = { year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "2-digit" };
    const hour12 = this._uiHour12();
    if (hour12 !== undefined) opts.hour12 = hour12;
    try {
      return d.toLocaleString(this._uiLocale(), opts);
    } catch (e) {
      return d.toLocaleString();
    }
  }
  // Redraws everything that shows translated text.
  _onTranslationsReady() {
    this._applyTranslations();
    this._render();
  }
  _applyTranslations() {
    __fhSweep(this._root || this.shadowRoot);
    if (!this._root) return;
    this._root.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.dataset.i18n;
      if (el.dataset.i18nFallback === undefined) el.dataset.i18nFallback = el.textContent;
      el.textContent = this._t(key, el.dataset.i18nFallback);
    });
    this._root.querySelectorAll("[data-i18n-title]").forEach((el) => {
      const key = el.dataset.i18nTitle;
      if (el.dataset.i18nTitleFallback === undefined) {
        el.dataset.i18nTitleFallback = el.getAttribute("title") || el.getAttribute("aria-label") || "";
      }
      const translated = this._t(key, el.dataset.i18nTitleFallback);
      if (el.hasAttribute("title")) el.setAttribute("title", translated);
      if (el.hasAttribute("aria-label")) el.setAttribute("aria-label", translated);
    });
  }
  async _initFirstLoad() {
    await this._fetchSettings();
    // always fetched now, not just when the household has useGlobalTheme on
    await this._fetchGlobalThemes();
    this._refreshAll();
    this._startPolling();
    // see this file's own copy of the window.__familyHubTimerAlarm singleton (below) for the full design note.
    this._subscribeAlarmEvents();
  }
  _myUserId() {
    return this._hass && this._hass.user ? this._hass.user.id : null;
  }
  async _subscribeAlarmEvents() {
    if (this._alarmUnsub || !this._hass || !this._hass.connection) return;
    const myUserId = this._myUserId();
    try {
      const unsubRing = await this._hass.connection.subscribeEvents((event) => {
        if (window.__familyHubTimerAlarm) {
          window.__familyHubTimerAlarm.ringBroadcast(event.data, this._hass, typeof this._myUserId === "function" ? this._myUserId() : myUserId);
        }
      }, "family_hub_timer_alarm_ring");
      const unsubStop = await this._hass.connection.subscribeEvents((event) => {
        if (window.__familyHubTimerAlarm && event.data) {
          window.__familyHubTimerAlarm.stopFromServer(event.data.uid);
        }
      }, "family_hub_timer_alarm_stop");
      this._alarmUnsub = () => {
        try { unsubRing(); } catch (e) { /* no-op */ }
        try { unsubStop(); } catch (e) { /* no-op */ }
      };
    } catch (e) {
      // Best-effort - a dashboard that can't subscribe (e.g. a very old frontend build) simply never gets the WIDENED alarm reach
    }
    // Catch up on anything already ringing before this tab opened
    if (this._hass.connection.sendMessagePromise) {
      try {
        const result = await this._hass.connection.sendMessagePromise({ type: "family_hub/timers/list_active_alarms" });
        for (const alarm of (result && result.alarms) || []) {
          if (window.__familyHubTimerAlarm) window.__familyHubTimerAlarm.ringBroadcast(alarm, this._hass, myUserId);
        }
      } catch (e) {
        // Best-effort catch-up only - the next re-announcement still
        // covers it.
      }
    }
  }
  _refreshAll() {
    this._loadedOnce = true;
    this._fetchTodayEvents();
    this._fetchTodayMeals();
    this._fetchTodayReminders();
    this._fetchWeather();
  }
  _startPolling() {
    if (this._interval) return;
    this._interval = setInterval(() => {
      this._fetchSettings();
      this._refreshAll();
    }, 60 * 1000);
  }
  connectedCallback() {
    if (window.__familyHubEink) window.__familyHubEink.attach(this, Object.assign({"strip": [".msd-item"], "recolor": [".dot", ".detail-chip", ".custody-badge"]}, { css: this.constructor.EINK_CSS || "" }));
    if (window.__familyHubModalScroll) window.__familyHubModalScroll.watch(this);
    if (this._hass && !this._interval) {
      if (this._firstLoadPromise) {
        this._firstLoadPromise.then(() => {
          if (this.isConnected && this._hass && !this._interval) {
            this._refreshAll();
            this._startPolling();
          }
        });
      } else {
        this._fetchSettings();
        this._refreshAll();
        this._startPolling();
      }
    }
    // Refresh at the next local midnight so a card left open overnight rolls over to the new day's events/meals/reminders on its own
    this._scheduleMidnightRefresh();
  }
  disconnectedCallback() {
    if (window.__familyHubEink) window.__familyHubEink.detach(this);
    if (window.__familyHubModalScroll) window.__familyHubModalScroll.unwatch(this);
    if (this._interval) clearInterval(this._interval);
    this._interval = null;
    if (this._midnightTimeout) clearTimeout(this._midnightTimeout);
    this._midnightTimeout = null;
  }
  _scheduleMidnightRefresh() {
    if (this._midnightTimeout) clearTimeout(this._midnightTimeout);
    const now = new Date();
    const nextMidnight = new Date(now);
    nextMidnight.setHours(24, 0, 5, 0);
    const ms = nextMidnight.getTime() - now.getTime();
    this._midnightTimeout = setTimeout(() => {
      this._renderHeader();
      this._refreshAll();
      this._scheduleMidnightRefresh();
    }, ms);
  }
  getCardSize() {
    return 4;
  }
  // Sections-view "Layout" tab sizing (current API).
  getGridOptions() {
    return {
      columns: 6,
      min_columns: 4,
      max_columns: 12,
      min_rows: 4,
    };
  }
  // Older frontends only understand the deprecated grid_* keys - kept
  // alongside getGridOptions so the card still lays out sensibly there.
  getLayoutOptions() {
    return { grid_rows: "auto", grid_columns: 6, grid_min_rows: 4 };
  }
  _dateKey(d) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }
  _toDate(part) {
    if (!part) return null;
    if (part.dateTime) return new Date(part.dateTime);
    if (part.date) return new Date(part.date + "T00:00:00");
    return null;
  }
  _defaultTheme() {
    return {
      colors: {
        bg: "#fbf7e5",
        card: "#f5f3f0",
        border: "#e6ddc4",
        text: "#423d34",
        textSecondary: "#96877a",
        accent: "#8f5a00",
        accentText: "#fff8ea",
        accent2: "#305545",
        accent3: "#b5583c",
        surfaceAlt: "#efe6cf",
        surface2: "#f2eede",
      },
      fonts: {
        dayName: 13,
        dayNumber: 22,
        wxTemp: 14,
        event: 14,
        chip: 13,
        headerTitle: 15,
        countdown: 11,
        blockLabel: 9,
        blockMeal: 13,
      },
    };
  }
  _defaultSettings() {
    return {
      blocks: ["Breakfast", "Lunch", "Dinner"],
      weekendBreakfast: false,
      people: [],
      theme: this._defaultTheme(),
      useGlobalTheme: true,
      globalThemeId: "slate",
    };
  }
  // Only reads the handful of shared-settings fields this card actually needs (blocks, weekend-breakfast, people, theme)
  _normalizeSettings(parsed) {
    const defaults = this._defaultSettings();
    if (!parsed || typeof parsed !== "object") return defaults;
    const blocks = Array.isArray(parsed.blocks) && parsed.blocks.length ? parsed.blocks.map((b) => String(b)) : defaults.blocks;
    const weekendBreakfast = typeof parsed.weekendBreakfast === "boolean" ? parsed.weekendBreakfast : defaults.weekendBreakfast;
    const people = Array.isArray(parsed.people) ? parsed.people : defaults.people;
    const defaultTheme = defaults.theme;
    const parsedTheme = parsed.theme && typeof parsed.theme === "object" ? parsed.theme : {};
    const colors = {};
    Object.keys(defaultTheme.colors).forEach((k) => {
      const v = parsedTheme.colors && parsedTheme.colors[k];
      colors[k] = typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v) ? v : defaultTheme.colors[k];
    });
    const fonts = {};
    Object.keys(defaultTheme.fonts).forEach((k) => {
      const raw = parsedTheme.fonts && parsedTheme.fonts[k];
      const n = typeof raw === "number" ? raw : parseInt(raw, 10);
      fonts[k] = Number.isFinite(n) && n >= 6 && n <= 72 ? n : defaultTheme.fonts[k];
    });
    const useGlobalTheme = typeof parsed.useGlobalTheme === "boolean" ? parsed.useGlobalTheme : defaults.useGlobalTheme;
    const globalThemeId = typeof parsed.globalThemeId === "string" ? parsed.globalThemeId : defaults.globalThemeId;
    // the lists the main calendar card uses (see _applySharedEntities) - its Settings choices
    const str = (v) => (typeof v === "string" ? v.trim() : "");
    const reg = parsed.calendarCardEntities && typeof parsed.calendarCardEntities === "object" ? parsed.calendarCardEntities : {};
    const calendarCardEntities = {};
    ["meal_plan_entity", "reminders_entity", "weather_entity"].forEach((k) => {
      if (/^(todo|weather)\.[a-z0-9_]+$/.test(str(reg[k]))) calendarCardEntities[k] = str(reg[k]);
    });
    return {
      blocks, weekendBreakfast, people, theme: { colors, fonts }, useGlobalTheme, globalThemeId,
      mealPlanEntity: str(parsed.mealPlanEntity), weatherEntity: str(parsed.weatherEntity), calendarCardEntities,
      userProfiles: parsed.userProfiles && typeof parsed.userProfiles === "object" ? parsed.userProfiles : {},
      discreetModeEnabled: parsed.discreetModeEnabled === true,
      showPersonPictures: parsed.showPersonPictures !== false,
      showNowMarker: parsed.showNowMarker !== false,
    };
  }
  // which meal plan / reminders list / weather entity this card reads.
  _applySharedEntities() {
    if (!this._config) return;
    const s = this._settingsCache || {};
    const reg = s.calendarCardEntities || {};
    const pick = (key, fromSettings, def) => {
      const own = (this._configExplicit && this._configExplicit[key]) || "";
      if (own && own !== def) return own;
      return (fromSettings || "").trim() || reg[key] || own || def;
    };
    this._config.meal_plan_entity = pick("meal_plan_entity", s.mealPlanEntity, "todo.meal_plan");
    this._config.reminders_entity = pick("reminders_entity", "", "todo.family_reminders");
    this._config.weather_entity = pick("weather_entity", s.weatherEntity, "weather.forecast_home");
  }
  _getSettings() {
    return this._settingsCache || this._defaultSettings();
  }
  _getPeople() {
    const settings = this._getSettings();
    if (Array.isArray(settings.people) && settings.people.length) {
      const palette = ["#a9c6c2", "#dba99c", "#d9bf7e", "#a8bd93", "#b9a7c9", "#cf8f6c", "#a89a83"];
      return settings.people
        .filter((p) => p && p.entity)
        .map((p, i) => ({
          entity: p.entity,
          name: p.name || p.entity,
          color: p.color || palette[i % palette.length],
          badges: Array.isArray(p.badges) ? p.badges : [],
          remindersEntity: p.remindersEntity || "",
          holiday: typeof p.holiday === "boolean" ? p.holiday : undefined,
          kind: ["holiday", "birthday", "special"].includes(p.kind) ? p.kind : undefined,
        }));
    }
    return this._config.people;
  }
  // A holiday calendar (Settings > Calendars > Holidays, or one named "holiday") shows next to the date, not as events
  _holidayIcon(summary) {
    const s = String(summary || "").toLowerCase();
    const rules = [
      [/hallowe/, "\u{1F383}"], [/christmas|xmas|weihnacht|navidad|no[eë]l|natale|kerst|natal/, "\u{1F384}"], [/thanksgiving/, "\u{1F983}"],
      [/easter|ostern|pascua|p[âa]ques|pasqua|pasen|wielkanoc|p[áa]scoa/, "\u{1F423}"], [/new year|neujahr|a[ñn]o nuevo|nouvel an|capodanno|nieuwjaar|nowy rok|ano novo/, "\u{1F386}"],
      [/valentin/, "\u2764\uFE0F"], [/patrick/, "\u2618\uFE0F"], [/independence|4th of july|fourth of july/, "\u{1F386}"], [/mother/, "\u{1F490}"], [/father/, "\u{1F454}"],
      [/memorial|veteran|remembrance/, "\u{1F396}\uFE0F"], [/labou?r day|may day/, "\u{1F6E0}\uFE0F"], [/daylight|dst|summer time|winter time/, "\u{1F552}"],
      [/hanuk|chanuk/, "\u{1F54E}"], [/diwali/, "\u{1FA94}"], [/birthday|geburtstag|cumplea/, "\u{1F382}"],
    ];
    const hit = rules.find(([re]) => re.test(s));
    return hit ? hit[1] : "\u{1F389}";
  }
  _isHolidayCalendar(person) {
    if (!person) return false;
    // 2026.11.1: Birthdays and Special days calendars show next to the date too
    if (["holiday", "birthday", "special"].includes(person.kind)) return true;
    if (typeof person.holiday === "boolean") return person.holiday;
    return /holiday|feiertag|festivo|feriado|f[ée]ri[ée]|feestdag|święt|swiet/i.test(`${person.entity || ""} ${person.name || ""}`);
  }
  _getBlocksForToday() {
    const settings = this._getSettings();
    const blocks = settings.blocks.slice();
    const dayIndex = new Date().getDay();
    const isWeekend = dayIndex === 0 || dayIndex === 6;
    if (settings.weekendBreakfast && isWeekend && !blocks.some((b) => /breakfast/i.test(b))) {
      blocks.unshift("Breakfast");
    }
    return blocks;
  }
  // Shared by both the new per-card override branch below and the existing household-global branch
  _themeFromGlobalEntry(g) {
    const defaultTheme = this._defaultTheme();
    const colors = {};
    Object.keys(defaultTheme.colors).forEach((k) => {
      const v = g.colors && g.colors[k];
      colors[k] = typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v) ? v : defaultTheme.colors[k];
    });
    const fonts = {};
    Object.keys(defaultTheme.fonts).forEach((k) => {
      const raw = g.fonts && g.fonts[k];
      const n = typeof raw === "number" ? raw : parseInt(raw, 10);
      fonts[k] = Number.isFinite(n) && n >= 6 && n <= 72 ? n : defaultTheme.fonts[k];
    });
    const cardOpacity = typeof g.cardOpacity === "number" ? g.cardOpacity : 100;
    const glassBlur = typeof g.glassBlur === "number" ? g.glassBlur : 0;
    return { colors, fonts, fontFamily: (typeof g.fontFamily === "string" && /^[\w\s,'"\-]{1,200}$/.test(g.fontFamily.trim()) ? g.fontFamily.trim() : ""), effects: g.effects || null, background: g.background || null, cardOpacity, glassBlur };
  }
  _resolveTheme(settings) {
    const local = settings.theme || this._defaultTheme();
    // a per-card-placement Theme override (set from this card's own native "Edit Card" dialog) wins over the household's own Global Theme setting
    const cardOverride = this._config && this._config.theme_override;
    if (cardOverride) {
      const list = Array.isArray(this._globalThemes) ? this._globalThemes : [];
      const g = list.find((t) => t && t.id === cardOverride);
      if (g) return this._themeFromGlobalEntry(g);
      // A stale override (theme since deleted/renamed) falls through to
      // normal resolution below rather than going blank.
    }
    // a holiday background set to change the theme wins while it's showing
    if (window.__fhHolidayTheme) {
      if (!this.__fhHolidaySub) this.__fhHolidaySub = window.__fhHolidayTheme.subscribe(() => { if (this.isConnected) this._applyThemeVars(); });
      const holidayThemeId = window.__fhHolidayTheme.themeId(this._hass);
      const hg = holidayThemeId && (this._globalThemes || []).find((t) => t && t.id === holidayThemeId);
      if (hg) return this._themeFromGlobalEntry(hg);
    }
    if (!settings.useGlobalTheme || !settings.globalThemeId) return local;
    const list = Array.isArray(this._globalThemes) ? this._globalThemes : [];
    const g = list.find((t) => t && t.id === settings.globalThemeId);
    if (!g) return local;
    return this._themeFromGlobalEntry(g);
  }
  _hexToRgba(hex, alpha) {
    const h = (hex || "#000000").replace("#", "");
    if (h.length !== 6) return "rgba(0,0,0,0)";
    const r = parseInt(h.substr(0, 2), 16);
    const g = parseInt(h.substr(2, 2), 16);
    const b = parseInt(h.substr(4, 2), 16);
    const a = Math.max(0, Math.min(1, typeof alpha === "number" ? alpha : 1));
    return `rgba(${r}, ${g}, ${b}, ${a})`;
  }
  _buildBoxShadow(effects) {
    if (!effects) return null;
    const shadow = effects.shadow || {};
    const glow = effects.glow || {};
    const layers = [];
    if (shadow.enabled !== false) {
      layers.push(
        `${shadow.offsetX || 0}px ${shadow.offsetY || 0}px ${shadow.blurRadius || 0}px ${shadow.spreadRadius || 0}px ${this._hexToRgba(shadow.color || "#000000", typeof shadow.opacity === "number" ? shadow.opacity : 0.16)}`
      );
    }
    if (glow.enabled) {
      layers.push(`0 0 ${glow.blurRadius || 0}px 0 ${this._hexToRgba(glow.color || "#ffd21a", typeof glow.opacity === "number" ? glow.opacity : 0.6)}`);
    }
    return layers.length ? layers.join(", ") : null;
  }
  // see window.__familyHubThemeCache's own comment above the class for the full "why a key, not one shared blob" reasoning.
  _familyHubThemeCacheKey() {
    const cardOverride = this._config && this._config.theme_override;
    if (cardOverride) return `card:${cardOverride}`;
    return "household";
  }
  _applyThemeVars() {
    const settings = this._getSettings();
    const theme = this._resolveTheme(settings);
    this.style.setProperty("--fc-font-family", theme.fontFamily || "");
    this.style.setProperty("--fc-bg", theme.colors.bg);
    // Liquid Glass support (cardOpacity/glassBlur): the rows and cards go translucent and blur the theme's background image, like the calendar.
    const cardOpacity = typeof theme.cardOpacity === "number" ? theme.cardOpacity : 100;
    const glassBlur = typeof theme.glassBlur === "number" ? theme.glassBlur : 0;
    this.style.setProperty("--fc-glass-blur", `${glassBlur}px`);
    this.style.setProperty("--fc-card", (cardOpacity < 100 ? this._hexToRgba(theme.colors.card, cardOpacity / 100) : theme.colors.card));
    this.style.setProperty("--fc-card-menu", (cardOpacity < 88 ? this._hexToRgba(theme.colors.card, 0.88) : cardOpacity < 100 ? this._hexToRgba(theme.colors.card, cardOpacity / 100) : theme.colors.card));
    this.style.setProperty("--fc-border", theme.colors.border);
    this.style.setProperty("--fc-text", theme.colors.text);
    this.style.setProperty("--fc-text-secondary", theme.colors.textSecondary);
    this.style.setProperty("--fc-accent", theme.colors.accent);
    this.style.setProperty("--fc-accent-text", theme.colors.accentText);
    this.style.setProperty("--fc-accent2", theme.colors.accent2);
    this.style.setProperty("--fc-accent3", theme.colors.accent3);
    this.style.setProperty("--fc-surface-alt", (cardOpacity < 100 ? this._hexToRgba(theme.colors.surfaceAlt, cardOpacity / 100) : theme.colors.surfaceAlt));
    this.style.setProperty("--fc-surface2", (cardOpacity < 100 ? this._hexToRgba(theme.colors.surface2, cardOpacity / 100) : theme.colors.surface2));
    this.style.setProperty("--fs-header-title", `${theme.fonts.headerTitle}px`);
    this.style.setProperty("--fs-event", `${theme.fonts.event}px`);
    this.style.setProperty("--fs-chip", `${theme.fonts.chip}px`);
    this.style.setProperty("--fs-wx-temp", `${theme.fonts.wxTemp}px`);
    const shadowCss = this._buildBoxShadow(theme.effects);
    if (shadowCss) this.style.setProperty("--fc-shadow", shadowCss);
    else this.style.removeProperty("--fc-shadow");
    const bg = theme.background;
    if (bg && bg.image) {
      this.style.setProperty("--fc-bg-image", `url("${bg.image.replace(/"/g, '\\"')}")`);
      this.style.setProperty("--fc-bg-size", bg.size === "repeat" ? "auto" : bg.size || "cover");
      this.style.setProperty("--fc-bg-position", bg.position || "center");
      this.style.setProperty("--fc-bg-blur", `${bg.blur || 0}px`);
      this.style.setProperty("--fc-bg-image-opacity", typeof bg.opacity === "number" ? bg.opacity : 1);
      this.style.setProperty(
        "--fc-bg-overlay-image",
        `linear-gradient(${this._hexToRgba(bg.overlayColor || "#000000", bg.overlayOpacity || 0)}, ${this._hexToRgba(bg.overlayColor || "#000000", bg.overlayOpacity || 0)})`
      );
    } else {
      this.style.removeProperty("--fc-bg-image");
      this.style.removeProperty("--fc-bg-size");
      this.style.removeProperty("--fc-bg-position");
      this.style.removeProperty("--fc-bg-blur");
      this.style.removeProperty("--fc-bg-image-opacity");
      this.style.removeProperty("--fc-bg-overlay-image");
    }
    // snapshot exactly what was just set/removed above into the shared cache under this card/placement's key
    if (window.__familyHubThemeCache) {
      const __familyHubCacheVarNames = [
      "--fc-bg",
      "--fc-card",
      "--fc-card-menu",
      "--fc-font-family",
      "--fc-border",
      "--fc-text",
      "--fc-text-secondary",
      "--fc-accent",
      "--fc-accent-text",
      "--fc-accent2",
      "--fc-accent3",
      "--fc-surface-alt",
      "--fc-surface2",
      "--fc-glass-blur",
      "--fs-header-title",
      "--fs-event",
      "--fs-chip",
      "--fs-wx-temp",
      "--fc-shadow",
      "--fc-bg-image",
      "--fc-bg-size",
      "--fc-bg-position",
      "--fc-bg-blur",
      "--fc-bg-image-opacity",
      "--fc-bg-overlay-image",
      ];
      const vars = {};
      __familyHubCacheVarNames.forEach((name) => {
        const v = this.style.getPropertyValue(name);
        if (v) vars[name] = v;
      });
      window.__familyHubThemeCache.set(this._familyHubThemeCacheKey(), vars);
    }
  }
  // applies whatever theme this device/placement last actually resolved to, SYNCHRONOUSLY
  _applyCachedThemeVarsIfAny() {
    if (!window.__familyHubThemeCache) return;
    const cached = window.__familyHubThemeCache.get(this._familyHubThemeCacheKey());
    if (!cached) return;
    Object.keys(cached).forEach((name) => {
      if (typeof cached[name] === "string") this.style.setProperty(name, cached[name]);
    });
  }
  async _fetchSettings() {
    if (!this._hass) return;
    // read Family Hub's own live settings store first - the legacy "Settings" to-do item this used to read exclusively stopped being kept in sync
    try {
      const live = await this._hass.connection.sendMessagePromise({ type: "family_hub/get_settings" });
      const liveSettings = live && live.settings && typeof live.settings === "object" ? live.settings : null;
      if (liveSettings && Object.keys(liveSettings).length) {
        this._settingsCache = this._normalizeSettings(liveSettings);
        this._afterSettingsLoaded();
        this._applyThemeVars();
        this._renderHeader();
        return;
      }
    } catch (e) {
      // fall through to the legacy copy below
    }
    try {
      const result = await this._hass.connection.sendMessagePromise({
        type: "call_service",
        domain: "todo",
        service: "get_items",
        service_data: { status: ["needs_action", "completed"] },
        target: { entity_id: this._config.settings_entity },
        return_response: true,
      });
      const items = (result && result.response && result.response[this._config.settings_entity] && result.response[this._config.settings_entity].items) || [];
      const matches = items.filter((it) => it.summary === "Settings");
      const item = matches.length ? matches[matches.length - 1] : items[0] || null;
      let parsed = null;
      if (item && item.description) {
        try {
          parsed = JSON.parse(item.description);
        } catch (e) {
          parsed = null;
        }
      }
      this._settingsCache = this._normalizeSettings(parsed);
    } catch (e) {
      if (!this._settingsCache) this._settingsCache = this._defaultSettings();
    }
    this._afterSettingsLoaded();
    this._applyThemeVars();
    this._renderHeader();
  }
  // re-pick the lists (see _applySharedEntities) and, if the calendar card's choice changed since the last load
  _afterSettingsLoaded() {
    const before = [this._config.meal_plan_entity, this._config.reminders_entity, this._config.weather_entity].join("|");
    this._applySharedEntities();
    const after = [this._config.meal_plan_entity, this._config.reminders_entity, this._config.weather_entity].join("|");
    if (before !== after && this._loadedOnce) this._refreshAll();
  }
  async _fetchGlobalThemes() {
    if (!this._hass) return;
    let custom = [];
    try {
      const result = await this._hass.connection.sendMessagePromise({ type: "theme_builder/list" });
      custom = (result && Array.isArray(result.themes)) ? result.themes : [];
    } catch (e) {
      custom = [];
    }
    // also merge in every installed native Home Assistant theme - duplicated
    this._globalThemes = custom.concat(this._nativeHaThemeEntries());
    this._applyThemeVars();
  }
  // --- Native HA theme support (duplicated from family-week-calendar-
  // card.js's identical methods - see that file's own comments) ---
  _haVarsToBuilderColors(vars) {
    const v = vars || {};
    const accent = v["primary-color"];
    return {
      bg: v["primary-background-color"],
      card: v["card-background-color"] || v["ha-card-background"],
      border: v["divider-color"],
      text: v["primary-text-color"],
      textSecondary: v["secondary-text-color"],
      accent: accent,
      accentText: v["text-primary-color"],
      accent2: v["accent-color"] || accent,
      accent3: v["warning-color"],
      surfaceAlt: v["secondary-background-color"],
      surface2: v["secondary-background-color"],
    };
  }
  _haThemeCssVars(name) {
    const themes = (this._hass && this._hass.themes && this._hass.themes.themes) || {};
    const theme = themes[name];
    if (!theme) return {};
    const vars = {};
    for (const key of Object.keys(theme)) {
      if (key === "modes") continue;
      vars[key] = theme[key];
    }
    if (theme.modes) {
      const dark = !!(this._hass && this._hass.themes && this._hass.themes.darkMode);
      const modeVars = theme.modes[dark ? "dark" : "light"] || {};
      for (const key of Object.keys(modeVars)) vars[key] = modeVars[key];
    }
    return vars;
  }
  _haDefaultCssVars() {
    try {
      if (typeof getComputedStyle !== "function" || !document || !document.documentElement) return {};
      const style = getComputedStyle(document.documentElement);
      const keys = [
        "primary-color", "text-primary-color", "primary-background-color", "secondary-background-color",
        "card-background-color", "primary-text-color", "secondary-text-color", "divider-color",
        "accent-color", "warning-color", "ha-card-background",
      ];
      const vars = {};
      keys.forEach((k) => {
        const val = style.getPropertyValue(`--${k}`);
        if (val && val.trim()) vars[k] = val.trim();
      });
      return vars;
    } catch (e) {
      return {};
    }
  }
  _nativeHaThemeEntries() {
    const defaultFonts = this._defaultTheme().fonts;
    const entries = [
      {
        id: "ha:__default__",
        name: "Default (Home Assistant)",
        colors: this._haVarsToBuilderColors(this._haDefaultCssVars()),
        fonts: defaultFonts,
        effects: null,
        background: null,
        native: true,
      },
    ];
    const themes = (this._hass && this._hass.themes && this._hass.themes.themes) || {};
    Object.keys(themes)
      .filter((name) => name.indexOf("Theme Builder - ") !== 0)
      .sort((a, b) => a.localeCompare(b))
      .forEach((name) => {
        entries.push({
          id: "ha:" + name,
          name: name,
          colors: this._haVarsToBuilderColors(this._haThemeCssVars(name)),
          fonts: defaultFonts,
          effects: null,
          background: null,
          native: true,
        });
      });
    return entries;
  }
  async _getItems(entityId) {
    const result = await this._hass.connection.sendMessagePromise({
      type: "call_service",
      domain: "todo",
      service: "get_items",
      service_data: { status: ["needs_action", "completed"] },
      target: { entity_id: entityId },
      return_response: true,
    });
    return (result && result.response && result.response[entityId] && result.response[entityId].items) || [];
  }
  _parseDishDescription(raw) {
    if (!raw) return { description: "", link: "", color: null, block: 0, recur: null };
    try {
      const parsed = JSON.parse(raw);
      return {
        description: parsed.description || "",
        link: parsed.link || "",
        color: parsed.color || null,
        block: typeof parsed.block === "number" ? parsed.block : 0,
        recur: parsed.recur || null,
      };
    } catch (e) {
      return { description: raw, link: "", color: null, block: 0, recur: null };
    }
  }
  _parseReminderRollover(raw) {
    const match = /<!--rollover:1-->/.exec(raw || "");
    // a rollover reminder can now also carry a <!--rolldays:...--> marker
    const description = (raw || "")
      .replace(/<!--rollover:1-->/, "")
      .replace(/<!--rolldays:[\d,]*-->/, "")
      .trim();
    return { description, rollover: !!match };
  }
  async _fetchTodayEvents() {
    if (!this._hass) return;
    const today = new Date();
    const dayStart = new Date(today);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart);
    dayEnd.setDate(dayStart.getDate() + 1);
    const people = this._getPeople();
    const results = [];
    const holidays = [];
    // Deduped by "text|color" so two same-badge events today don't stack duplicate bubbles next to the date
    const badgeMap = new Map();
    await Promise.all(
      people.map(async (person) => {
        if (!person.entity) return;
        const personBadges = person.badges || [];
        try {
          const events = await this._hass.callApi(
            "GET",
            `calendars/${person.entity}?start=${encodeURIComponent(dayStart.toISOString())}&end=${encodeURIComponent(dayEnd.toISOString())}`
          );
          for (const ev of events || []) {
            const start = this._toDate(ev.start);
            const end = this._toDate(ev.end);
            if (!start) continue;
            const summaryLower = (ev.summary || "").toLowerCase();
            if (this._isHolidayCalendar(person)) {
              if (ev.summary && !holidays.some((h) => h.summary.toLowerCase() === summaryLower)) holidays.push({ summary: ev.summary, color: person.color, kind: person.kind || "holiday" });
              continue;
            }
            // A per-calendar "hide when contains" keyword drops the event entirely (e.g. a background custody-schedule calendar)
            const hideMatched = personBadges.some((b) => {
              const hideMatch = (b.hideMatch || "").trim().toLowerCase();
              return hideMatch && summaryLower.includes(hideMatch);
            });
            if (hideMatched) continue;
            // A "show badge when contains" keyword swaps the full event row for a small colored bubble next to today's date instead
            let matchedBadge = false;
            for (const b of personBadges) {
              const badgeMatch = (b.match || "").trim().toLowerCase();
              if (badgeMatch && summaryLower.includes(badgeMatch)) {
                matchedBadge = true;
                if (b.text) badgeMap.set(`${b.text}|${person.color}`, { text: b.text, color: person.color });
              }
            }
            if (matchedBadge) continue;
            results.push({
              summary: ev.summary || "(untitled)",
              start,
              end,
              allDay: !ev.start || !ev.start.dateTime,
              location: ev.location || "",
              description: ev.description || "",
              color: person.color,
              personName: person.name,
              picture: this._calendarPicture(person.entity),
            });
          }
        } catch (e) {
          // One bad calendar shouldn't blank out the rest of today.
        }
      })
    );
    results.sort((a, b) => {
      if (a.allDay !== b.allDay) return a.allDay ? -1 : 1;
      return a.start - b.start;
    });
    this._todayEvents = results;
    this._todayBadges = Array.from(badgeMap.values());
    this._todayHolidays = holidays;
    this._render();
  }
  async _fetchTodayMeals() {
    if (!this._hass) return;
    try {
      const items = await this._getItems(this._config.meal_plan_entity);
      const map = {};
      const recurring = [];
      for (const it of items) {
        const dateKey = (it.due || "").slice(0, 10);
        if (!dateKey) continue;
        const parsed = this._parseDishDescription(it.description);
        const blockIndex = parsed.block || 0;
        if (!map[dateKey]) map[dateKey] = {};
        map[dateKey][blockIndex] = {
          uid: it.uid,
          name: it.summary,
          description: parsed.description,
          link: parsed.link,
          color: parsed.color,
          recur: parsed.recur,
        };
        if (parsed.recur === "weekly") {
          const anchorDate = new Date(`${dateKey}T00:00:00`);
          recurring.push({
            uid: it.uid,
            weekday: anchorDate.getDay(),
            blockIndex,
            name: it.summary,
            description: parsed.description,
            link: parsed.link,
            color: parsed.color,
            anchorDateKey: dateKey,
          });
        }
      }
      this._mealPlanRaw = map;
      this._recurringMeals = recurring;
    } catch (e) {
      this._mealPlanRaw = {};
      this._recurringMeals = [];
    }
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dateKey = this._dateKey(today);
    const blocks = this._getBlocksForToday();
    this._todayMeals = blocks
      .map((label, blockIndex) => {
        const meal = this._getMealForDay(dateKey, today, blockIndex);
        return meal ? { label, blockIndex, ...meal } : null;
      })
      .filter(Boolean);
    this._render();
  }
  // Same resolution rule as the full card's _getMealForDay: an explicit entry for this exact date always wins
  _getMealForDay(dateKey, dayDate, blockIndex) {
    const explicit = this._mealPlanRaw[dateKey] && this._mealPlanRaw[dateKey][blockIndex];
    if (explicit) return explicit;
    const weekday = dayDate.getDay();
    let best = null;
    for (const t of this._recurringMeals || []) {
      if (t.weekday !== weekday || t.blockIndex !== blockIndex) continue;
      if (dateKey < t.anchorDateKey) continue;
      if (!best || t.anchorDateKey > best.anchorDateKey) best = t;
    }
    if (!best) return null;
    return { uid: best.uid, name: best.name, description: best.description, link: best.link, color: best.color, recur: "weekly" };
  }
  // (): mirrors the full calendar card's own v130+ multi-list subscription rule
  async _fetchTodayReminders() {
    if (!this._hass) return;
    const familyEntity = this._config.reminders_entity;
    const lists = [{ entity: familyEntity, color: null, personName: null, isFamily: true }];
    try {
      const settings = this._getSettings();
      const profiles = settings.userProfiles || {};
      const myUserId = this._hass.user && this._hass.user.id;
      const myProfile = myUserId ? profiles[myUserId] : null;
      if (myProfile) {
        const people = this._getPeople();
        const subs = myProfile.remindersSubscriptions || {};
        const seenEntities = new Set([familyEntity]);
        for (const person of people) {
          if (!person.remindersEntity || seenEntities.has(person.remindersEntity)) continue;
          const isOwn = !!myProfile.primaryCalendar && person.entity === myProfile.primaryCalendar;
          const subLevel = subs[person.entity];
          const visible = isOwn || subLevel === "calendar" || subLevel === "calendar_alert";
          if (!visible) continue;
          seenEntities.add(person.remindersEntity);
          lists.push({ entity: person.remindersEntity, color: person.color, personName: person.name, isFamily: false });
        }
      }
    } catch (e) {
      // No profile/individual-list data yet (or something malformed about
      // it) - the shared family list above still works fine on its own.
    }
    const today = new Date();
    const dateKey = this._dateKey(today);
    try {
      const fetchedLists = await Promise.all(
        lists.map(async (list) => {
          try {
            const items = await this._getItems(list.entity);
            return items
              .filter((it) => it.status === "needs_action" && it.due)
              .map((it) => {
                const parsed = this._parseReminderRollover(it.description || "");
                const due = new Date(it.due);
                if (isNaN(due.getTime())) return null;
                return {
                  uid: it.uid,
                  summary: it.summary || "(untitled)",
                  due,
                  description: parsed.description,
                  rollover: parsed.rollover,
                  listEntity: list.entity,
                  color: list.color,
                  personName: list.personName,
                  isFamily: list.isFamily,
                };
              })
              .filter(Boolean);
          } catch (e) {
            // That particular list's to-do entity doesn't exist yet - skip
            // it, the other lists still show.
            return [];
          }
        })
      );
      const chores = await this._fetchTodayChoreItems();
      this._todayReminders = fetchedLists
        .flat()
        .concat(chores)
        .filter((r) => this._dateKey(r.due) === dateKey)
        .sort((a, b) => a.due - b.due);
    } catch (e) {
      this._todayReminders = [];
    }
    this._render();
  }
  // Chores with "Show on the calendar" ticked (chore.show_on_calendar), open and due, shaped like reminders - same rules as the calendar card's _fetchCalendarChoreItems
  async _fetchTodayChoreItems() {
    if (!this._hass || !this._hass.connection) return [];
    let chores = [];
    try {
      const res = await this._hass.connection.sendMessagePromise({ type: "family_hub/chores/list" });
      chores = Array.isArray(res && res.chores) ? res.chores : [];
    } catch (e) {
      return [];
    }
    const settings = this._getSettings();
    const profiles = settings.userProfiles || {};
    const people = this._getPeople() || [];
    const out = [];
    for (const c of chores) {
      if (!c || !c.show_on_calendar || !c.due_date || c.status !== "open" || c.star_request) continue;
      const raw = String(c.due_date);
      const due = /^\d{4}-\d{2}-\d{2}$/.test(raw) ? new Date(`${raw}T09:00:00`) : new Date(raw);
      if (isNaN(due.getTime())) continue;
      const uid = c.assigned_to && c.assigned_to !== "chore_bin" ? c.assigned_to : null;
      const profile = (uid && profiles[uid]) || {};
      const column = profile.primaryCalendar ? people.find((p) => p.entity === profile.primaryCalendar) : null;
      out.push({
        uid: `chore:${c.id}`,
        summary: c.title || "(untitled)",
        due,
        description: c.notes || "",
        rollover: false,
        listEntity: "",
        color: (uid && (profile.color || (column && column.color))) || null,
        personName: uid ? (column && column.name) || "" : this._t("event_info.chore_bin", "Chore Bin"),
        isFamily: !uid,
        isChore: true,
        choreId: c.id,
        choreAssignedTo: uid,
      });
    }
    return out;
  }
  async _markReminderDone(uid, listEntity) {
    if (!this._hass || !uid) return;
    if (String(uid).startsWith("chore:")) {
      try {
        await this._hass.connection.sendMessagePromise({ type: "family_hub/chores/complete", chore_id: String(uid).slice(6) });
      } catch (e) {
        window.alert(this._t("event_info.chore_done_failed", "Couldn't mark it done. Only the person it's for, or someone allowed to complete anyone's chores, can."));
      }
      this._fetchTodayReminders();
      return;
    }
    try {
      await this._hass.callService("todo", "update_item", { item: uid, status: "completed" }, { entity_id: listEntity || this._config.reminders_entity });
    } catch (e) {
    }
    this._fetchTodayReminders();
  }
  async _fetchWeather() {
    if (!this._hass || !this._config.weather_entity) {
      this._forecastToday = null;
      this._render();
      return;
    }
    try {
      const result = await this._hass.connection.sendMessagePromise({
        type: "call_service",
        domain: "weather",
        service: "get_forecasts",
        service_data: { type: "daily" },
        target: { entity_id: this._config.weather_entity },
        return_response: true,
      });
      const bucket = result && result.response && result.response[this._config.weather_entity];
      const forecasts = (bucket && bucket.forecast) || [];
      const todayKey = this._dateKey(new Date());
      const todayForecast = forecasts.find((f) => (f.datetime || "").slice(0, 10) === todayKey);
      this._forecastToday = todayForecast
        ? { condition: todayForecast.condition, high: todayForecast.temperature, low: todayForecast.templow }
        : null;
    } catch (e) {
      this._forecastToday = null;
    }
    this._render();
  }
  _wxIcon(condition) {
    const map = {
      "clear-night": "\u{1F319}",
      cloudy: "\u{2601}\u{FE0F}",
      fog: "\u{1F32B}\u{FE0F}",
      hail: "\u{1F328}\u{FE0F}",
      lightning: "\u{26C8}\u{FE0F}",
      "lightning-rainy": "\u{26C8}\u{FE0F}",
      partlycloudy: "\u{26C5}",
      pouring: "\u{1F327}\u{FE0F}",
      rainy: "\u{1F327}\u{FE0F}",
      snowy: "\u{2744}\u{FE0F}",
      "snowy-rainy": "\u{1F328}\u{FE0F}",
      sunny: "\u{2600}\u{FE0F}",
      windy: "\u{1F4A8}",
      "windy-variant": "\u{1F4A8}",
      exceptional: "\u{26A0}\u{FE0F}",
    };
    return map[condition] || "";
  }
  // -- 2026.11.1.2: profile pictures, birthday ages, "now" (same rules as the calendar card) --
  _calendarPicture(calendarEntity) {
    const settings = this._getSettings() || {};
    if (!calendarEntity || settings.showPersonPictures === false || settings.discreetModeEnabled) return "";
    const states = (this._hass && this._hass.states) || {};
    const profiles = settings.userProfiles || {};
    let ent = "";
    for (const uid of Object.keys(profiles)) {
      const p = profiles[uid];
      if (!p || p.primaryCalendar !== calendarEntity) continue;
      ent = typeof p.presenceEntity === "string" && p.presenceEntity.startsWith("person.") ? p.presenceEntity
        : (Object.keys(states).find((id) => id.startsWith("person.") && states[id] && states[id].attributes && states[id].attributes.user_id === uid) || "");
      break;
    }
    const pic = ent && states[ent] && states[ent].attributes && states[ent].attributes.entity_picture;
    if (!pic || typeof pic !== "string") return "";
    return typeof this._hass.hassUrl === "function" ? this._hass.hassUrl(pic) : pic;
  }
  _picStyle(pic) {
    return pic ? `background-image:url('${String(pic).replace(/["'()\\\s]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0"))}')` : "";
  }
  _ageSuffix(ev) {
    const settings = this._getSettings() || {};
    if (settings.discreetModeEnabled) return "";
    const m = String(ev.description || "").match(/\b(?:year|born|since|married|est\.?)\s*[=:]?\s*(\d{4})\b/i);
    if (!m) return "";
    const d = ev.start instanceof Date ? ev.start : new Date();
    const n = d.getFullYear() - parseInt(m[1], 10);
    if (!(n > 0 && n < 150)) return "";
    if (/anniversar|jahrestag|aniversario|anniversaire|anniversario|jubileum|rocznic/i.test(ev.summary || "")) return ` (${this._t("calendar.n_years", `${n} years`, { n: String(n) })})`;
    return ` (${n})`;
  }
  _nowPct(ev) {
    const settings = this._getSettings() || {};
    if (settings.showNowMarker === false || ev.allDay || !ev.start || !ev.end || typeof ev.start.getTime !== "function" || typeof ev.end.getTime !== "function") return null;
    const now = Date.now(), s0 = ev.start.getTime(), e0 = ev.end.getTime();
    if (!(s0 <= now && now < e0) || e0 <= s0) return null;
    return Math.round(((now - s0) / (e0 - s0)) * 100);
  }
  _nowTag(pct) {
    return pct === null || pct === undefined ? "" : `<span class="now-tag">${this._t("calendar.now", "Now")} &middot;</span> `;
  }
  _nowBar(pct) {
    return pct === null || pct === undefined ? "" : `<span class="ev-progress"><span style="width:${pct}%"></span></span>`;
  }
  _fmtTime(d) {
    return this._fmtTimeOfDay(d);
  }
  // Client-side navigation to another dashboard/view, the same mechanism Home Assistant's own frontend uses for a "navigate" tap action
  _goToCalendar() {
    const path = (this._config.calendar_dashboard_path || "").trim();
    if (!path) return;
    history.pushState(null, "", path);
    window.dispatchEvent(new CustomEvent("location-changed", { bubbles: true, composed: true, detail: { replace: false } }));
  }
  // Same contrast heuristic as the full card's _textColorFor, so a badge
  // bubble's text stays readable against any configured badge color.
  _textColorFor(hex) {
    if (!hex) return "#4a3800";
    const c = hex.replace("#", "");
    if (c.length !== 6) return "#4a3800";
    const r = parseInt(c.substr(0, 2), 16);
    const g = parseInt(c.substr(2, 2), 16);
    const b = parseInt(c.substr(4, 2), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.6 ? "#3a2f00" : "#ffffff";
  }
  // Ported from family-week-calendar-card.js's own Add Event modal (same class names, same fields
  _colorByName(people) {
    const map = {};
    for (const p of people) {
      const key = (p.name || p.entity || "").trim().toLowerCase();
      if (!(key in map)) map[key] = p.color;
    }
    return map;
  }
  _colorFor(person, colorMap) {
    const key = (person.name || person.entity || "").trim().toLowerCase();
    return (colorMap && colorMap[key]) || person.color;
  }
  // Same "someone else's individual/subscribed Reminders list" picker as the full card's own _addableRemindersLists
  _addableRemindersLists() {
    const familyEntity = this._config.reminders_entity;
    const lists = [{ entity: familyEntity, label: this._t("today.add_event.family_list_label", "Family"), color: null }];
    if (!this._hass) return lists;
    try {
      const settings = this._getSettings();
      const profiles = settings.userProfiles || {};
      const myUserId = this._hass.user && this._hass.user.id;
      const myProfile = myUserId ? profiles[myUserId] : null;
      if (myProfile) {
        const people = this._getPeople();
        const subs = myProfile.remindersSubscriptions || {};
        const seenEntities = new Set([familyEntity]);
        for (const person of people) {
          if (!person.remindersEntity || seenEntities.has(person.remindersEntity)) continue;
          const isOwn = !!myProfile.primaryCalendar && person.entity === myProfile.primaryCalendar;
          const subLevel = subs[person.entity];
          const canAdd = isOwn || subLevel === "calendar" || subLevel === "calendar_alert";
          if (!canAdd) continue;
          seenEntities.add(person.remindersEntity);
          lists.push({ entity: person.remindersEntity, label: isOwn ? this._t("today.add_event.my_list_label", `My list (${person.name})`, { name: person.name }) : person.name, color: person.color });
        }
      }
    } catch (e) {
      // No profile/individual-list data yet - just the family list, same picker-of-one this feature always had before individual lists existed.
    }
    return lists;
  }
  // Renders the 7 Mon-Sun toggle buttons for the reminder rollover-days picker - `selected` empty
  _rolldaysBtnsHtml(selectedDays) {
    const selected = new Set(selectedDays && selectedDays.length ? selectedDays : [0, 1, 2, 3, 4, 5, 6]);
    return REMINDER_WEEKDAY_LABELS.map(
      (label, idx) => `<button type="button" class="rolldays-btn ${selected.has(idx) ? "active" : ""}" data-day="${idx}">${this._t(`today.weekday_short_${idx}`, label)}</button>`
    ).join("");
  }
  _wireRolldaysToggle(container) {
    if (!container) return;
    container.querySelectorAll(".rolldays-btn").forEach((btn) => {
      btn.addEventListener("click", () => btn.classList.toggle("active"));
    });
  }
  _readRolldaysFromContainer(container) {
    if (!container) return [];
    return Array.from(container.querySelectorAll(".rolldays-btn.active")).map((btn) => parseInt(btn.dataset.day, 10));
  }
  // Writes a standalone reminder's rollover markers back into its description
  _buildReminderDescription(description, rollover, rolloverDays) {
    const base = (description || "").trim();
    if (!rollover) return base;
    const days = Array.isArray(rolloverDays) ? Array.from(new Set(rolloverDays)).filter((d) => d >= 0 && d <= 6) : [];
    const markers = ["<!--rollover:1-->"];
    if (days.length > 0 && days.length < 7) {
      markers.push(`<!--rolldays:${days.sort((a, b) => a - b).join(",")}-->`);
    }
    const markerBlock = markers.join("\n");
    return base ? `${base}\n\n${markerBlock}` : markerBlock;
  }
  // Same mobile-back-button/hardware-back-gesture handling as the full card's own _openModal/_setupModalBackButtonHandling/
  _openModal(el) {
    if (!el) return;
    this._setupModalBackButtonHandling();
    this._topModalZ = (this._topModalZ || 1006) + 1;
    el.style.zIndex = String(this._topModalZ);
    el.classList.add("open");
  }
  _setupModalBackButtonHandling() {
    if (this._modalBackButtonSetup || !this._root) return;
    this._modalBackButtonSetup = true;
    this._closingModalFromPopState = false;
    this._pendingProgrammaticBacks = 0;
    this._boundHandleModalPopState = this._handleModalPopState.bind(this);
    window.addEventListener("popstate", this._boundHandleModalPopState);
    this._modalHistoryObserver = new MutationObserver((mutations) => {
      let opened = 0;
      let closedNonPopstate = 0;
      const seen = new Set();
      for (const mutation of mutations) {
        const el = mutation.target;
        if (!el.classList || !el.classList.contains("modal-overlay") || seen.has(el)) continue;
        seen.add(el);
        const isOpen = el.classList.contains("open");
        if (isOpen && !el.__fhHistoryPushed) {
          el.__fhHistoryPushed = true;
          opened++;
        } else if (!isOpen && el.__fhHistoryPushed) {
          el.__fhHistoryPushed = false;
          if (!this._closingModalFromPopState) closedNonPopstate++;
        }
      }
      const delta = opened - closedNonPopstate;
      if (delta > 0) {
        for (let i = 0; i < delta; i++) window.history.pushState({ familyHubModal: true }, "");
      } else if (delta < 0) {
        for (let i = 0; i < -delta; i++) {
          this._pendingProgrammaticBacks++;
          window.history.back();
        }
      }
    });
    this._modalHistoryObserver.observe(this._root, {
      attributes: true,
      attributeFilter: ["class"],
      subtree: true,
    });
  }
  _handleModalPopState() {
    if (!this._root) return;
    if (this._pendingProgrammaticBacks > 0) {
      this._pendingProgrammaticBacks--;
      return;
    }
    const openOverlays = Array.from(this._root.querySelectorAll(".modal-overlay.open"));
    if (!openOverlays.length) return;
    let top = openOverlays[0];
    let topZ = parseInt(top.style.zIndex || "0", 10);
    for (const el of openOverlays) {
      const z = parseInt(el.style.zIndex || "0", 10);
      if (z >= topZ) {
        top = el;
        topZ = z;
      }
    }
    this._closingModalFromPopState = true;
    top.classList.remove("open");
    setTimeout(() => {
      this._closingModalFromPopState = false;
    }, 0);
  }
  _openAddEvent(tab) {
    const root = this._root;
    const select = root.querySelector(".add-event-calendar-select");
    select.innerHTML = this._getPeople()
      .map((p) => `<option value="${p.entity}">${p.name}</option>`)
      .join("");
    const remListSelect = root.querySelector(".add-event-reminder-list-select");
    if (remListSelect) {
      remListSelect.innerHTML = this._addableRemindersLists()
        .map((l) => `<option value="${l.entity}">${l.label}</option>`)
        .join("");
      remListSelect.value = this._config.reminders_entity;
    }
    root.querySelector(".add-event-title").value = "";
    root.querySelector(".add-event-location").value = "";
    root.querySelector(".add-event-description").value = "";
    root.querySelector(".add-event-reminder-rollover").checked = false;
    const addEventRolldaysFieldReset = root.querySelector(".add-event-reminder-rolldays-field");
    if (addEventRolldaysFieldReset) addEventRolldaysFieldReset.style.display = "none";
    root.querySelectorAll(".add-event-reminder-rolldays .rolldays-btn").forEach((btn) => btn.classList.add("active"));
    root.querySelectorAll(".remind-check").forEach((cb) => {
      cb.checked = cb.value === "10" || cb.value === "30";
    });
    // Always defaults to today - see this whole block's own top comment for why this card doesn't need the full card's "whichever day is
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    root.querySelector(".add-event-date").value = this._dateKey(today);
    root.querySelector(".add-event-end-date").value = "";
    root.querySelector(".add-event-reminder-date").value = this._dateKey(today);
    const now = new Date();
    const nextHour = new Date(now);
    nextHour.setMinutes(0, 0, 0);
    nextHour.setHours(nextHour.getHours() + 1);
    const afterHour = new Date(nextHour);
    afterHour.setHours(afterHour.getHours() + 1);
    const fmtTimeInput = (d) => `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
    root.querySelector(".add-event-start-time").value = fmtTimeInput(nextHour);
    root.querySelector(".add-event-end-time").value = fmtTimeInput(afterHour);
    root.querySelector(".add-event-reminder-time").value = fmtTimeInput(nextHour);
    root.querySelectorAll(".add-event-allday-btn").forEach((b) => b.classList.toggle("active", b.dataset.value === "off"));
    this._updateAddEventFieldVisibility(false);
    this._renderAddEventPeopleField();
    // Attachable checklists - always start fresh, closed, in "just for this" mode with no items
    this._addEventChecklistItems = [];
    root.querySelector(".add-event-checklist-toggle").checked = false;
    root.querySelector(".add-event-checklist-body").style.display = "none";
    root.querySelectorAll(".add-event-checklist-mode-btn").forEach((b) => b.classList.toggle("active", b.dataset.value === "custom"));
    root.querySelector(".add-event-checklist-existing-field").style.display = "none";
    root.querySelector(".add-event-checklist-custom-field").style.display = "";
    root.querySelector(".add-event-checklist-add-input").value = "";
    this._renderAddEventChecklistItems();
    this._todoListCandidates = null;
    this._setAddEventTab(tab === "reminder" ? "reminder" : "calendar");
    this._openModal(root.querySelector(".add-event-overlay"));
  }
  _renderAddEventPeopleField() {
    const root = this._root;
    const content = root.querySelector(".add-event-people-content");
    if (!content) return;
    const ownEntity = root.querySelector(".add-event-calendar-select").value;
    const people = this._getPeople();
    const others = people.filter((p) => p.entity !== ownEntity);
    if (!others.length) {
      content.innerHTML = `<div class="empty">${this._t("today.add_event.no_one_else_to_tag", "No one else in Family Hub to tag yet.")}</div>`;
      return;
    }
    const colorMap = this._colorByName(people);
    const checkboxesHtml = others
      .map((p) => {
        const color = this._colorFor(p, colorMap);
        return `<label class="remind-check-opt"><input type="checkbox" class="add-event-people-check" value="${p.entity}" /><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${color}"></span>${p.name}</label>`;
      })
      .join("");
    content.innerHTML = `<div class="remind-check-row">${checkboxesHtml}</div>`;
  }
  // Renders the "just for this" checklist-item builder inside the Add
  // Event modal from this._addEventChecklistItems.
  _renderAddEventChecklistItems() {
    const root = this._root;
    const listEl = root.querySelector(".add-event-checklist-items");
    if (!listEl) return;
    const items = this._addEventChecklistItems || [];
    listEl.innerHTML = items.length
      ? items
          .map(
            (item, i) =>
              `<div class="checklist-item-row">` +
              `<span class="checklist-item-row-text">${item.text}</span>` +
              `<button type="button" class="checklist-item-remove-btn" data-index="${i}" title="${this._t("today.add_event.remove_item_title", "Remove")}">&#10005;</button>` +
              `</div>`
          )
          .join("")
      : `<div class="remind-hint">${this._t("today.add_event.checklist_no_items_yet", "No items yet - add whatever needs to be remembered below.")}</div>`;
    listEl.querySelectorAll(".checklist-item-remove-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.dataset.index, 10);
        if (Number.isFinite(idx)) this._addEventChecklistItems.splice(idx, 1);
        this._renderAddEventChecklistItems();
      });
    });
  }
  // Populates the "use an existing list" dropdown from _fetchTodoListCandidates
  async _renderAddEventChecklistExistingSelect() {
    const root = this._root;
    const select = root.querySelector(".add-event-checklist-existing-select");
    if (!select) return;
    const candidates = await this._fetchTodoListCandidates();
    if (!candidates) return;
    const previous = select.value;
    select.innerHTML = candidates.length
      ? candidates.map((c) => `<option value="${c.entity_id}">${c.name}</option>`).join("")
      : `<option value="">${this._t("today.add_event.no_todo_lists_found", "No to-do lists found")}</option>`;
    if (previous && candidates.some((c) => c.entity_id === previous)) select.value = previous;
  }
  // Every todo.* entity in this Home Assistant instance, for the "use an existing list" picker
  async _fetchTodoListCandidates() {
    if (this._todoListCandidates) return this._todoListCandidates;
    if (!this._hass || !this._hass.connection || !this._hass.connection.sendMessagePromise) return null;
    try {
      const result = await this._hass.connection.sendMessagePromise({ type: "family_hub/checklist/list_todo_candidates" });
      this._todoListCandidates = (result && Array.isArray(result.todo_lists)) ? result.todo_lists : [];
      return this._todoListCandidates;
    } catch (e) {
      return null;
    }
  }
  _setAddEventTab(tab) {
    const root = this._root;
    this._addEventActiveTab = tab === "reminder" ? "reminder" : "calendar";
    const isReminder = this._addEventActiveTab === "reminder";
    root.querySelectorAll(".add-event-tab-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.tab === this._addEventActiveTab);
    });
    root.querySelectorAll(".add-event-tab-panel").forEach((panel) => {
      panel.style.display = panel.dataset.tabPanel === this._addEventActiveTab ? "" : "none";
    });
    const calendarField = root.querySelector(".add-event-calendar-field");
    if (calendarField) calendarField.style.display = isReminder ? "none" : "";
    const heading = root.querySelector(".add-event-heading");
    if (heading) heading.innerHTML = isReminder ? `\u{1F514} ${this._t("today.add_event.heading_reminder", "New Reminder")}` : `\u{2795} ${this._t("today.add_event.heading_event", "New Event")}`;
    this._setAddEventError("");
    this._refreshAddReminderMissingWarn();
  }
  _refreshAddReminderMissingWarn() {
    const root = this._root;
    const warn = root.querySelector(".add-event-reminder-missing-warn");
    if (!warn) return;
    const isReminder = this._addEventActiveTab === "reminder";
    const listSelect = root.querySelector(".add-event-reminder-list-select");
    const entityId = (listSelect && listSelect.value) || this._config.reminders_entity;
    const missing = isReminder && this._hass && entityId && !this._hass.states[entityId];
    if (missing) {
      warn.textContent = this._t(
        "today.add_event.reminder_list_missing_warn",
        `⚠️ "${entityId}" doesn't exist in Home Assistant yet, so reminders can't be saved until it does. Create a to-do list with that entity id (Settings → Devices & Services → Add Integration → Local To-do), or point this card's reminders_entity config at a to-do list you already have.`,
        { entity: entityId }
      );
      warn.style.display = "";
    } else {
      warn.style.display = "none";
    }
  }
  _setAddEventError(message) {
    const box = this._root && this._root.querySelector(".add-event-error");
    if (!box) return;
    if (message) {
      box.textContent = message;
      box.style.display = "";
    } else {
      box.textContent = "";
      box.style.display = "none";
    }
  }
  _closeAddEvent() {
    this._root.querySelector(".add-event-overlay").classList.remove("open");
    this._setAddEventError("");
  }
  _updateAddEventFieldVisibility(allDay) {
    const field = this._root.querySelector(".add-event-time-field");
    if (field) field.style.display = allDay ? "none" : "";
    const remindField = this._root.querySelector(".add-event-remind-field");
    if (remindField) {
      remindField.style.display = allDay ? "none" : "";
      if (allDay) {
        this._root.querySelectorAll(".remind-check").forEach((cb) => {
          cb.checked = false;
        });
      }
    }
  }
  // Shared by both _saveAddEvent's calendar branch and _saveAddReminder below - reads whatever's currently set in the checklist section and
  async _saveAddEventChecklistIfAny(targetParams) {
    const root = this._root;
    const toggle = root.querySelector(".add-event-checklist-toggle");
    if (!toggle || !toggle.checked) return;
    const isExisting = root.querySelector(".add-event-checklist-mode-btn.active").dataset.value === "existing";
    let checklist;
    if (isExisting) {
      const entityId = root.querySelector(".add-event-checklist-existing-select").value;
      if (!entityId) return;
      checklist = { mode: "existing", entity_id: entityId };
    } else {
      const items = (this._addEventChecklistItems || []).map((item) => ({ text: item.text }));
      if (!items.length) return;
      checklist = { mode: "custom", items };
    }
    try {
      await this._hass.connection.sendMessagePromise({
        type: "family_hub/set_event_checklist",
        ...targetParams,
        checklist,
      });
    } catch (e) {
      // best-effort - see comment above
    }
  }
  async _saveAddEvent() {
    if (this._addEventActiveTab === "reminder") {
      await this._saveAddReminder();
      return;
    }
    const root = this._root;
    this._setAddEventError("");
    const entity = root.querySelector(".add-event-calendar-select").value;
    const title = root.querySelector(".add-event-title").value.trim();
    if (!entity || !title) return;
    if (this._hass && !this._hass.states[entity]) {
      this._setAddEventError(this._t(
        "today.add_event.calendar_missing_error",
        `⚠️ "${entity}" doesn't exist in Home Assistant. Check the calendars configured under Settings.`,
        { entity }
      ));
      return;
    }
    const allDayBtn = root.querySelector(".add-event-allday-btn.active");
    const allDay = allDayBtn ? allDayBtn.dataset.value === "on" : false;
    const dateVal = root.querySelector(".add-event-date").value;
    if (!dateVal) return;
    const location = root.querySelector(".add-event-location").value.trim();
    let description = root.querySelector(".add-event-description").value.trim();
    const remindMinutesList = allDay
      ? []
      : Array.from(root.querySelectorAll(".remind-check:checked"))
          .map((cb) => parseInt(cb.value, 10))
          .filter((n) => Number.isFinite(n) && n > 0)
          .sort((a, b) => a - b);
    if (remindMinutesList.length) {
      const marker = `<!--reminder:${remindMinutesList.join(",")}-->`;
      description = description ? `${description}\n\n${marker}` : marker;
    }
    const endDateInputVal = root.querySelector(".add-event-end-date").value;
    const endDateVal = endDateInputVal && endDateInputVal >= dateVal ? endDateInputVal : dateVal;
    const data = { summary: title };
    if (location) data.location = location;
    if (description) data.description = description;
    if (allDay) {
      const end = new Date(endDateVal + "T00:00:00");
      end.setDate(end.getDate() + 1);
      data.start_date = dateVal;
      data.end_date = this._dateKey(end);
    } else {
      const startTime = root.querySelector(".add-event-start-time").value || "09:00";
      let endTime = root.querySelector(".add-event-end-time").value || "10:00";
      if (endDateVal === dateVal && endTime <= startTime) {
        const [h, m] = startTime.split(":").map((n) => parseInt(n, 10));
        const endDate = new Date();
        endDate.setHours(h + 1, m, 0, 0);
        endTime = `${String(endDate.getHours()).padStart(2, "0")}:${String(endDate.getMinutes()).padStart(2, "0")}`;
      }
      data.start_date_time = `${dateVal} ${startTime}:00`;
      data.end_date_time = `${endDateVal} ${endTime}:00`;
    }
    try {
      await this._hass.callService("calendar", "create_event", data, { entity_id: entity });
    } catch (e) {
      const errMsg = e && e.message ? e.message : e;
      this._setAddEventError(this._t(
        "today.add_event.save_event_error",
        `⚠️ Couldn't save this event: ${errMsg}`,
        { error: errMsg }
      ));
      return;
    }
    const startDate = allDay ? new Date(dateVal + "T00:00:00") : new Date(data.start_date_time.replace(" ", "T"));
    const startTs = Math.floor(startDate.getTime() / 1000);
    const peopleEntities = Array.from(root.querySelectorAll(".add-event-people-check:checked")).map((c) => c.value);
    if (peopleEntities.length) {
      try {
        await this._hass.connection.sendMessagePromise({
          type: "family_hub/set_event_people_override",
          calendar_entity: entity,
          start: startTs,
          summary: title,
          people: peopleEntities,
        });
      } catch (e) {
        // best-effort - see comment above
      }
    }
    await this._saveAddEventChecklistIfAny({ calendar_entity: entity, start: startTs, summary: title });
    this._closeAddEvent();
    this._fetchTodayEvents();
  }
  async _saveAddReminder() {
    const root = this._root;
    this._setAddEventError("");
    const title = root.querySelector(".add-event-title").value.trim();
    if (!title) return;
    const dateVal = root.querySelector(".add-event-reminder-date").value;
    if (!dateVal) return;
    const listSelect = root.querySelector(".add-event-reminder-list-select");
    const entityId = (listSelect && listSelect.value) || this._config.reminders_entity;
    if (this._hass && entityId && !this._hass.states[entityId]) {
      this._setAddEventError(this._t(
        "today.add_event.reminder_list_missing_error",
        `⚠️ "${entityId}" doesn't exist in Home Assistant, so this reminder wasn't saved. Create a to-do list with that entity id (Settings → Devices & Services → Add Integration → Local To-do), or point the right list's config at a to-do list you already have.`,
        { entity: entityId }
      ));
      return;
    }
    const notifyTime = root.querySelector(".add-event-reminder-time").value || "09:00";
    const description = root.querySelector(".add-event-description").value.trim();
    const rollover = root.querySelector(".add-event-reminder-rollover").checked;
    const rolloverDays = this._readRolldaysFromContainer(root.querySelector(".add-event-reminder-rolldays"));
    const fullDescription = this._buildReminderDescription(description, rollover, rolloverDays);
    const data = {
      item: title,
      due_datetime: `${dateVal}T${notifyTime}:00`,
    };
    if (fullDescription) data.description = fullDescription;
    try {
      await this._hass.callService("todo", "add_item", data, { entity_id: entityId });
    } catch (e) {
      const errMsg = e && e.message ? e.message : e;
      this._setAddEventError(this._t(
        "today.add_event.save_reminder_error",
        `⚠️ Couldn't save this reminder: ${errMsg}`,
        { error: errMsg }
      ));
      return;
    }
    const toggle = root.querySelector(".add-event-checklist-toggle");
    if (toggle && toggle.checked) {
      const newItemUid = await this._findJustAddedReminderUid(entityId, title, data.due_datetime);
      if (newItemUid) {
        await this._saveAddEventChecklistIfAny({ todo_entity: entityId, item_uid: newItemUid });
      }
    }
    this._closeAddEvent();
    this._fetchTodayReminders();
  }
  // Best-effort lookup for the uid of the to-do item _saveAddReminder just created via the plain
  async _findJustAddedReminderUid(entityId, title, dueDatetime) {
    try {
      const result = await this._hass.connection.sendMessagePromise({
        type: "call_service",
        domain: "todo",
        service: "get_items",
        service_data: {},
        target: { entity_id: entityId },
        return_response: true,
      });
      const forEntity = result && result.response && result.response[entityId];
      const items = (forEntity && forEntity.items) || [];
      const match = items.find((it) => it.summary === title && it.due && it.due.startsWith(dueDatetime.slice(0, 16)));
      return match ? match.uid : null;
    } catch (e) {
      return null;
    }
  }
  // All the Add Event modal's own event listeners, wired once from _build() right after its markup is created - kept as its own method
  _wireAddEventModal(root) {
    root.querySelector(".add-event-close").addEventListener("click", () => this._closeAddEvent());
    root.querySelector(".add-event-cancel").addEventListener("click", () => this._closeAddEvent());
    root.querySelector(".add-event-overlay").addEventListener("click", (e) => {
      if (e.target === root.querySelector(".add-event-overlay")) this._closeAddEvent();
    });
    root.querySelector(".add-event-save").addEventListener("click", () => this._saveAddEvent());
    root.querySelector(".add-event-checklist-toggle").addEventListener("change", (e) => {
      root.querySelector(".add-event-checklist-body").style.display = e.target.checked ? "" : "none";
      if (e.target.checked && root.querySelector(".add-event-checklist-mode-btn.active").dataset.value === "existing") {
        this._renderAddEventChecklistExistingSelect();
      }
    });
    root.querySelectorAll(".add-event-checklist-mode-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        root.querySelectorAll(".add-event-checklist-mode-btn").forEach((b) => b.classList.toggle("active", b === btn));
        const isExisting = btn.dataset.value === "existing";
        root.querySelector(".add-event-checklist-existing-field").style.display = isExisting ? "" : "none";
        root.querySelector(".add-event-checklist-custom-field").style.display = isExisting ? "none" : "";
        if (isExisting) this._renderAddEventChecklistExistingSelect();
      });
    });
    const addChecklistItem = () => {
      const input = root.querySelector(".add-event-checklist-add-input");
      const text = (input.value || "").trim();
      if (!text) return;
      this._addEventChecklistItems = this._addEventChecklistItems || [];
      this._addEventChecklistItems.push({ text: text.slice(0, 200) });
      input.value = "";
      this._renderAddEventChecklistItems();
      input.focus();
    };
    root.querySelector(".add-event-checklist-add-btn").addEventListener("click", addChecklistItem);
    root.querySelector(".add-event-checklist-add-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addChecklistItem();
      }
    });
    const wireDatePickerBtn = (btnSelector, inputSelector) => {
      root.querySelector(btnSelector).addEventListener("click", () => {
        const input = root.querySelector(inputSelector);
        if (input.showPicker) {
          try {
            input.showPicker();
          } catch (e) {
            input.focus();
          }
        } else {
          input.focus();
        }
      });
    };
    wireDatePickerBtn(".add-event-date-btn", ".add-event-date");
    wireDatePickerBtn(".add-event-end-date-btn", ".add-event-end-date");
    wireDatePickerBtn(".add-event-reminder-date-btn", ".add-event-reminder-date");
    root.querySelectorAll(".add-event-tab-btn").forEach((btn) => {
      btn.addEventListener("click", () => this._setAddEventTab(btn.dataset.tab));
    });
    const remListSelectEl = root.querySelector(".add-event-reminder-list-select");
    if (remListSelectEl) {
      remListSelectEl.addEventListener("change", () => this._refreshAddReminderMissingWarn());
    }
    const addEventCalendarSelectEl = root.querySelector(".add-event-calendar-select");
    if (addEventCalendarSelectEl) {
      addEventCalendarSelectEl.addEventListener("change", () => this._renderAddEventPeopleField());
    }
    root.querySelectorAll(".add-event-allday-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        root.querySelectorAll(".add-event-allday-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        this._updateAddEventFieldVisibility(btn.dataset.value === "on");
      });
    });
    const addEventRolloverCb = root.querySelector(".add-event-reminder-rollover");
    const addEventRolldaysField = root.querySelector(".add-event-reminder-rolldays-field");
    if (addEventRolloverCb && addEventRolldaysField) {
      addEventRolloverCb.addEventListener("change", () => {
        addEventRolldaysField.style.display = addEventRolloverCb.checked ? "block" : "none";
      });
    }
    this._wireRolldaysToggle(root.querySelector(".add-event-reminder-rolldays"));
  }
  _build() {
    this._built = true;
    // applied BEFORE attachShadow/the first innerHTML paint - see _applyCachedThemeVarsIfAny's own comment and window.__familyHub ThemeCache's
    this._applyCachedThemeVarsIfAny();
    const root = this.attachShadow ? this.attachShadow({ mode: "open" }) : this;
    this._root = root;
    root.innerHTML = `
<style>
:host {
display: block;
height: 100%;
min-height: 0;
font-family: var(--fc-font-family, "Arial Rounded MT Std", "Arial Rounded MT", "Varela Round", -apple-system, "Segoe UI Rounded", "Segoe UI", Roboto, sans-serif);
--fc-shadow: 0 2px 8px rgba(58,53,44,0.12);
}
.card-root {
position: relative;
box-sizing: border-box;
height: 100%;
min-height: 0;
display: flex;
flex-direction: column;
padding: 16px;
border-radius: 16px;
overflow: hidden;
background: var(--fc-bg);
background-image: var(--fc-bg-image, none);
background-size: var(--fc-bg-size, cover);
background-position: var(--fc-bg-position, center);
color: var(--fc-text);
box-shadow: var(--fc-shadow);
}
.card-root::after {
content: "";
position: absolute;
inset: 0;
border-radius: 16px;
pointer-events: none;
background-image: var(--fc-bg-overlay-image, none);
}
.header { flex: 0 0 auto; display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; position: relative; }
.body-scroll { flex: 1 1 auto; min-height: 0; overflow-y: auto; overflow-x: hidden; margin-right: -8px; padding-right: 8px; }
.date-title { display: flex; align-items: center; gap: 6px; font-size: var(--fs-header-title, 15px); font-weight: 800; color: var(--fc-text); }
.header-badges { display: inline-flex; align-items: center; gap: 4px; flex-wrap: wrap; min-width: 0; }
.holiday-chip { display: inline-flex; align-items: center; gap: 4px; max-width: 220px; padding: 2px 8px; border-radius: 8px; background: color-mix(in srgb, var(--holiday-color, #c9c2b3) 30%, var(--fc-card-opaque, var(--fc-card))); border: 1px solid color-mix(in srgb, var(--holiday-color, #c9c2b3) 70%, transparent); color: var(--fc-text); font-size: 12px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.custody-badge { display: inline-flex; align-items: center; justify-content: center; min-width: 20px; height: 20px; padding: 0 5px; border-radius: 10px; font-size: 11px; font-weight: 800; box-shadow: var(--fc-shadow); }
.date-sub { font-size: var(--fs-chip, 13px); color: var(--fc-text-secondary); font-weight: 600; margin-top: 2px; }
.wx { display: flex; align-items: center; gap: 6px; font-size: var(--fs-wx-temp, 14px); color: var(--fc-text-secondary); font-weight: 700; }
.section { margin-bottom: 14px; position: relative; }
.section:last-child { margin-bottom: 0; }
.section-title { font-size: 11px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--fc-text-secondary); font-weight: 800; margin-bottom: 6px; }
.row { display: flex; align-items: center; gap: 10px; padding: 9px 11px; border-radius: 10px; background: var(--fc-surface-alt); margin-bottom: 6px; cursor: pointer; box-sizing: border-box; }
.row:last-child { margin-bottom: 0; }
.row { backdrop-filter: blur(var(--fc-glass-blur, 0px)); -webkit-backdrop-filter: blur(var(--fc-glass-blur, 0px)); }
.row .dot { width: 10px; height: 10px; border-radius: 50%; flex: 0 0 auto; }
.row .dot.has-pic { width: 28px; height: 28px; background-size: cover !important; background-position: center; box-shadow: 0 0 0 2px var(--fc-card, #fff), 0 0 0 3.5px rgba(0,0,0,0.08); }
.msd-pic { width: 18px; height: 18px; border-radius: 50%; flex: 0 0 auto; align-self: center; background-size: cover; background-position: center; box-shadow: 0 0 0 1.5px rgba(255,255,255,0.85); }
.now-tag { font-weight: 800; color: var(--fc-now-text, #17803d); }
.row.is-now { box-shadow: inset 0 0 0 2px var(--fc-now, #2fbf71); }
.ev-progress { display: block; height: 3px; border-radius: 2px; background: rgba(0,0,0,0.12); margin-top: 4px; overflow: hidden; }
.ev-progress > span { display: block; height: 100%; background: var(--fc-now, #2fbf71); border-radius: 2px; }
.row .label { flex: 1 1 auto; font-size: var(--fs-event, 14px); color: var(--fc-text); min-width: 0; overflow-wrap: break-word; }
.row .meta { font-size: var(--fs-chip, 13px); color: var(--fc-text-secondary); flex: 0 0 auto; white-space: nowrap; }
.reminder-owner { font-size: 0.85em; color: var(--fc-text-secondary); font-weight: 400; }
.row .done-btn { flex: 0 0 auto; border: none; border-radius: 8px; background: var(--fc-accent); color: var(--fc-accent-text); font-size: 11px; font-weight: 700; padding: 6px 10px; cursor: pointer; }
.empty { font-size: var(--fs-event, 14px); color: var(--fc-text-secondary); font-style: italic; padding: 4px 2px; }
/* compact layout - same .msd-* class names/rules as the full
   Family Week Calendar card's Month Split view day panel (see that
   file's own copy for the "why" - kept visually identical on purpose, so
   this really is "the same style", not just a similar one). This card's
   own .header (date/weather/badges) stays as-is either way; only
   .body-scroll's content differs between layouts. */
.msd-items { display: flex; flex-direction: column; gap: 6px; }
.msd-item { border-radius: 8px; padding: 6px 8px; color: #3a352c; cursor: pointer; display: flex; align-items: baseline; gap: 8px; }
.msd-item.mc-meal-pill { font-weight: 700; }
.msd-item-time { font-size: 10px; font-weight: 700; opacity: 0.8; flex: 0 0 auto; }
.msd-item-summary { font-size: 12px; overflow-wrap: anywhere; }
.msd-empty { font-size: 12px; color: var(--fc-text-secondary); font-style: italic; padding: 4px 0; }
.footer-actions { flex: 0 0 auto; }
.footer-actions:empty { display: none; }
/* the "Go to Calendar" button and the new opt-in "+ Add"
   button share one row (see _renderFooterActions) rather than each being
   its own full-width block - flex: 1 1 auto splits the row evenly between
   whichever of the two are actually present. */
.footer-actions-row { display: flex; gap: 8px; margin-top: 4px; }
.go-to-calendar-btn, .footer-add-btn { flex: 1 1 auto; box-sizing: border-box; border: none; border-radius: 10px; background: var(--fc-accent); color: var(--fc-accent-text); font-size: var(--fs-event, 14px); font-weight: 700; padding: 11px 12px; cursor: pointer; box-shadow: var(--fc-shadow); font-family: inherit; }
.modal-overlay { display: none; position: fixed; inset: 0; background: rgba(40,34,20,0.45); z-index: 1000; align-items: center; justify-content: center; }
.modal-overlay.open { display: flex; }
.modal-box { position: relative; background: var(--fc-card-menu, var(--fc-card)); color: var(--fc-text); border-radius: 14px; padding: 20px 20px 16px; width: min(92vw, 380px); max-height: 80vh; overflow-y: auto; box-shadow: 0 8px 30px rgba(58,53,44,0.3); }
.modal-close { position: absolute; top: 10px; right: 10px; border: none; background: var(--fc-surface-alt); color: var(--fc-text); width: 30px; height: 30px; border-radius: 8px; font-size: 14px; cursor: pointer; }
.modal-box h2 { margin: 0 26px 14px 0; font-size: 1.2em; color: var(--fc-text); }
.detail-title { font-size: 17px; font-weight: 800; margin: 0 24px 8px 0; }
.detail-chip { display: inline-block; padding: 3px 9px; border-radius: 12px; font-size: 12px; font-weight: 700; margin-bottom: 8px; }
.detail-row { font-size: 14px; color: var(--fc-text); margin-bottom: 6px; }
.detail-row.secondary { color: var(--fc-text-secondary); }
.detail-actions { margin-top: 12px; display: flex; gap: 8px; }
.detail-open-link-btn, .detail-done-btn { flex: 1 1 auto; border: none; border-radius: 10px; background: var(--fc-accent); color: var(--fc-accent-text); font-size: 13px; font-weight: 700; padding: 9px 12px; cursor: pointer; }
/* the Add Event modal, ported from family-week-calendar-card.js
   (same class names on purpose - see that file's own copies of these
   rules) so it's visually identical to the full card's own modal, not
   just similar. .add-event-box only overrides the sizing that differs
   from this card's smaller detail-popup .modal-box (wider, taller, more
   padding - it has a lot more fields to fit). */
.add-event-box { padding: 24px 22px 18px; width: min(92vw, 420px); max-height: 85vh; }
.add-event-tabs { display: flex; gap: 8px; margin-bottom: 4px; }
.add-event-tab-btn { flex: 1 1 0; min-height: 40px; padding: 8px 10px; border-radius: 10px; border: 2px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: var(--fc-shadow); }
.add-event-tab-btn.active { background: var(--fc-accent); color: var(--fc-accent-text); border-color: var(--fc-accent); }
.add-event-tab-panel { display: flex; flex-direction: column; gap: 12px; }
.field { margin-bottom: 14px; }
.field label { display: block; font-size: 13px; font-weight: 600; color: var(--fc-text-secondary); margin-bottom: 5px; }
.field input, .field textarea { width: 100%; box-sizing: border-box; font-size: 16px; padding: 10px 12px; border-radius: 8px; border: 1px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); font-family: inherit; }
.field textarea { resize: vertical; min-height: 60px; }
.size-btn-row { display: flex; gap: 8px; }
.size-btn { flex: 1 1 auto; min-height: 44px; border-radius: 10px; border: 2px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); font-size: 14px; font-weight: 700; cursor: pointer; box-shadow: var(--fc-shadow); }
.size-btn.active { background: var(--fc-accent); color: var(--fc-accent-text); border-color: var(--fc-accent); }
.hour-select { flex: 1 1 auto; min-height: 44px; border-radius: 10px; border: 2px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); font-size: 14px; font-weight: 700; padding: 0 8px; box-shadow: var(--fc-shadow); }
.range-sep { display: flex; align-items: center; font-size: 13px; font-weight: 700; color: var(--fc-text-secondary); }
.date-picker-row { display: flex; align-items: center; gap: 8px; }
.date-picker-row input { flex: 1 1 auto; }
.add-event-date-btn, .add-event-reminder-date-btn, .add-event-end-date-btn { flex: 0 0 auto; width: 44px; height: 44px; border-radius: 10px; border: 2px solid var(--fc-border); background: var(--fc-card); font-size: 18px; cursor: pointer; box-shadow: var(--fc-shadow); }
.remind-check-row { display: flex; flex-wrap: wrap; gap: 6px; }
.remind-check-opt { display: flex; align-items: center; gap: 4px; padding: 5px 9px; border-radius: 12px; background: var(--fc-surface-alt); color: var(--fc-text); font-size: 12px; font-weight: 600; cursor: pointer; user-select: none; }
.remind-check-opt input { margin: 0; }
.remind-hint { font-size: 11px; color: var(--fc-text-secondary); margin: 5px 0 0; font-style: italic; }
.add-event-error { font-size: 12px; color: #b91c1c; background: rgba(185,28,28,0.1); border: 1px solid rgba(185,28,28,0.3); border-radius: 8px; padding: 8px 10px; margin: 4px 0 0; line-height: 1.4; }
.add-event-warn { font-size: 11px; color: #b45309; margin: 5px 0 0; font-style: italic; }
.rolldays-field { display: none; margin: 6px 0 0 0; }
.rolldays-hint { font-size: 11px; color: var(--fc-text-secondary); font-style: italic; margin: 0 0 4px; }
.rolldays-btn-row { display: flex; gap: 4px; flex-wrap: wrap; }
.rolldays-btn { border: 1px solid var(--fc-border); border-radius: 8px; padding: 6px 8px; font-size: 12px; font-weight: 700; background: var(--fc-card); color: var(--fc-text); cursor: pointer; }
.rolldays-btn.active { background: var(--fc-accent); color: var(--fc-accent-text); border-color: var(--fc-accent); }
.checklist-mode-btn-row { display: flex; gap: 8px; margin-bottom: 8px; }
.checklist-item-row { display: flex; align-items: center; gap: 8px; padding: 6px 0; }
.checklist-item-row-text { flex: 1; }
.checklist-add-row { display: flex; gap: 8px; margin-top: 6px; }
.checklist-add-row input { flex: 1; min-height: 40px; border-radius: 10px; border: 2px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); font-size: 13px; padding: 0 10px; box-shadow: var(--fc-shadow); }
.checklist-item-remove-btn { min-width: 32px; min-height: 32px; border-radius: 8px; border: 2px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); font-size: 14px; font-weight: 700; cursor: pointer; box-shadow: var(--fc-shadow); }
.modal-actions { display: flex; gap: 10px; margin-top: 6px; flex-wrap: wrap; }
.modal-actions button { flex: 1 1 auto; min-height: 44px; border: none; border-radius: 10px; font-size: 15px; font-weight: 600; cursor: pointer; box-shadow: var(--fc-shadow); }
.btn-save { background: var(--fc-accent); color: var(--fc-accent-text); }
.btn-cancel { background: var(--fc-surface-alt); color: var(--fc-text); }
</style>
<div class="card-root">
<div class="header">
<div>
<div class="date-title"><span class="date-title-text"></span><span class="header-badges"></span></div>
<div class="date-sub"></div>
</div>
<div class="wx"></div>
</div>
<div class="body-scroll">
<div class="section">
<div class="section-title" data-i18n="today.section.events">Today's Events</div>
<div class="events-list"></div>
</div>
<div class="section">
<div class="section-title" data-i18n="today.section.meals">Today's Meals</div>
<div class="meals-list"></div>
</div>
<div class="section">
<div class="section-title" data-i18n="today.section.due_today">Due Today</div>
<div class="reminders-list"></div>
</div>
<div class="msd-items today-compact-items" style="display:none"></div>
</div>
<div class="footer-actions"></div>
</div>
<div class="modal-overlay detail-overlay">
<div class="modal-box">
<button type="button" class="modal-close" aria-label="Close" data-i18n-title="common.close">&#10005;</button>
<div class="detail-chip" style="display:none;"></div>
<div class="detail-title"></div>
<div class="detail-body"></div>
<div class="detail-actions"></div>
</div>
</div>
<div class="modal-overlay add-event-overlay">
<div class="modal-box add-event-box">
<button type="button" class="modal-close add-event-close" aria-label="Close" data-i18n-title="common.close">&#10005;</button>
<h2 class="add-event-heading" data-i18n="today.add_event.heading_event">&#10133; New Event</h2>
<div class="add-event-tabs">
<button type="button" class="add-event-tab-btn active" data-tab="calendar" data-i18n="today.add_event.tab_calendar">&#128197; Calendar Event</button>
<button type="button" class="add-event-tab-btn" data-tab="reminder" data-i18n="today.add_event.tab_reminder">&#128276; Reminder</button>
</div>
<div class="field add-event-calendar-field">
<label data-i18n="today.add_event.calendar_label">Calendar</label>
<select class="hour-select add-event-calendar-select"></select>
</div>
<div class="field">
<label data-i18n="today.add_event.title_label">Title</label>
<input data-fh-placeholder="text.e_g_dentist_appointment" type="text" class="add-event-title" placeholder="${__fhT("text.e_g_dentist_appointment", "e.g. Dentist appointment", null, "h")}" maxlength="120" />
</div>
<div class="add-event-tab-panel" data-tab-panel="calendar">
<div class="field">
<label data-i18n="today.add_event.all_day_label">All day</label>
<div class="size-btn-row">
<button type="button" class="size-btn add-event-allday-btn" data-value="off" data-i18n="today.add_event.timed_option">Timed</button>
<button type="button" class="size-btn add-event-allday-btn" data-value="on" data-i18n="today.add_event.all_day_option">All day</button>
</div>
</div>
<div class="field">
<label data-i18n="today.add_event.date_label">Date</label>
<div class="date-picker-row">
<input type="date" class="add-event-date" />
<button type="button" class="add-event-date-btn" title="Pick a date" data-i18n-title="today.add_event.pick_date_title">&#128197;</button>
</div>
</div>
<div class="field add-event-enddate-field">
<label data-i18n="today.add_event.end_date_label">End date (optional - for multi-day events)</label>
<div class="date-picker-row">
<input type="date" class="add-event-end-date" />
<button type="button" class="add-event-end-date-btn" title="Pick a date" data-i18n-title="today.add_event.pick_date_title">&#128197;</button>
</div>
</div>
<div class="field add-event-time-field">
<label data-i18n="today.add_event.start_end_time_label">Start / End time</label>
<div class="size-btn-row">
<input type="time" class="hour-select add-event-start-time" />
<div class="range-sep" data-i18n="today.add_event.time_range_sep">to</div>
<input type="time" class="hour-select add-event-end-time" />
</div>
</div>
<div class="field">
<label data-i18n="today.add_event.location_label">Location (optional)</label>
<input data-fh-placeholder="text.optional" type="text" class="add-event-location" placeholder="${__fhT("text.optional", "Optional", null, "h")}" maxlength="120" />
</div>
<div class="field add-event-remind-field">
<label data-i18n="today.add_event.remind_me_label">Remind me</label>
<div class="remind-check-row">
<label class="remind-check-opt"><input type="checkbox" class="remind-check" value="5" />5m</label>
<label class="remind-check-opt"><input type="checkbox" class="remind-check" value="10" />10m</label>
<label class="remind-check-opt"><input type="checkbox" class="remind-check" value="15" />15m</label>
<label class="remind-check-opt"><input type="checkbox" class="remind-check" value="30" />30m</label>
<label class="remind-check-opt"><input type="checkbox" class="remind-check" value="60" />1h</label>
<label class="remind-check-opt"><input type="checkbox" class="remind-check" value="120" />2h</label>
<label class="remind-check-opt"><input type="checkbox" class="remind-check" value="1440" />1d</label>
</div>

</div>
<div class="field add-event-people-field">
<label data-i18n="today.add_event.also_for_label">Also for</label>
<div class="add-event-people-content"></div>
</div>
</div>
<div class="add-event-tab-panel" data-tab-panel="reminder" style="display:none">
<div class="field add-event-reminder-list-field">
<label data-i18n="today.add_event.list_label">List</label>
<select class="hour-select add-event-reminder-list-select"></select>
</div>
<div class="field">
<label data-i18n="today.add_event.date_label">Date</label>
<div class="date-picker-row">
<input type="date" class="add-event-reminder-date" />
<button type="button" class="add-event-reminder-date-btn" title="Pick a date" data-i18n-title="today.add_event.pick_date_title">&#128197;</button>
</div>
</div>
<div class="field">
<label data-i18n="today.add_event.notify_at_label">Notify at</label>
<input type="time" class="hour-select add-event-reminder-time" />
</div>
<div class="field">
<label class="remind-check-opt"><input type="checkbox" class="add-event-reminder-rollover" />&#128257; <span data-i18n="today.add_event.rollover_label">Roll over to next day if not completed</span></label>
<div class="field rolldays-field add-event-reminder-rolldays-field">
<div class="rolldays-hint" data-i18n="today.add_event.rolldays_hint">Applies only on these days (leave every day selected to roll over daily, same as before)</div>
<div class="rolldays-btn-row add-event-reminder-rolldays">${this._rolldaysBtnsHtml([])}</div>
</div>
</div>
<div class="remind-hint" data-i18n="today.add_event.reminder_hint">Saved as a to-do in Home Assistant, not an event on your calendar - fires once at this exact time, and you can mark it done or reschedule it anytime from Home Assistant's own To-do UI. Who gets notified is set per person under Settings > Users.</div>
<div class="add-event-warn add-event-reminder-missing-warn" style="display:none"></div>
</div>
<div class="field add-event-checklist-field">
<label class="remind-check-opt"><input type="checkbox" class="add-event-checklist-toggle" />&#128203; <span data-i18n="today.add_event.attach_checklist_label">Attach a checklist</span></label>
<div class="add-event-checklist-body" style="display:none">
<div class="checklist-mode-btn-row">
<button type="button" class="size-btn add-event-checklist-mode-btn active" data-value="custom" data-i18n="today.add_event.checklist_mode_custom">Just for this</button>
<button type="button" class="size-btn add-event-checklist-mode-btn" data-value="existing" data-i18n="today.add_event.checklist_mode_existing">Use an existing list</button>
</div>
<div class="field add-event-checklist-existing-field" style="display:none">
<select class="hour-select add-event-checklist-existing-select"></select>
</div>
<div class="add-event-checklist-custom-field">
<div class="add-event-checklist-items"></div>
<div class="checklist-add-row">
<input data-fh-placeholder="text.e_g_cleats" type="text" class="add-event-checklist-add-input" placeholder="${__fhT("text.e_g_cleats", "e.g. Cleats", null, "h")}" maxlength="200" />
<button type="button" class="btn-cancel add-event-checklist-add-btn" data-i18n="common.add">Add</button>
</div>
</div>
<div class="remind-hint" data-i18n="today.add_event.checklist_lifecycle_hint">A "just for this" list is deleted automatically once this happens (plus a grace window) - an existing list you attach is only ever unlinked, never touched or deleted itself.</div>
</div>
</div>
<div class="field">
<label data-i18n="today.add_event.notes_label">Notes (optional)</label>
<textarea data-fh-placeholder="text.optional_details" class="add-event-description" placeholder="${__fhT("text.optional_details", "Optional details", null, "h")}" maxlength="255"></textarea>
</div>
<div class="add-event-error" style="display:none"></div>
<div class="modal-actions">
<button type="button" class="btn-cancel add-event-cancel" data-i18n="common.cancel">Cancel</button>
<button type="button" class="btn-save add-event-save" data-i18n="common.save">Save</button>
</div>
</div>
</div>
`;
    root.querySelector(".modal-close").addEventListener("click", () => this._closeDetail());
    root.querySelector(".detail-overlay").addEventListener("click", (e) => {
      if (e.target === root.querySelector(".detail-overlay")) this._closeDetail();
    });
    this._wireAddEventModal(root);
  }
  _closeDetail() {
    if (!this._root) return;
    this._root.querySelector(".detail-overlay").classList.remove("open");
  }
  _openDetail({ chip, chipColor, title, rows, actionLabel, actionHandler }) {
    const root = this._root;
    const chipEl = root.querySelector(".detail-chip");
    if (chip) {
      chipEl.style.display = "";
      chipEl.style.background = chipColor || "var(--fc-accent)";
      chipEl.style.color = "#fff";
      chipEl.textContent = chip;
    } else {
      chipEl.style.display = "none";
    }
    root.querySelector(".detail-title").textContent = title || "";
    const body = root.querySelector(".detail-body");
    body.innerHTML = (rows || [])
      .map((r) => `<div class="detail-row${r.secondary ? " secondary" : ""}">${r.text}</div>`)
      .join("");
    const actions = root.querySelector(".detail-actions");
    if (actionLabel && actionHandler) {
      actions.innerHTML = `<button type="button" class="detail-open-link-btn">${actionLabel}</button>`;
      actions.querySelector("button").addEventListener("click", actionHandler);
    } else {
      actions.innerHTML = "";
    }
    root.querySelector(".detail-overlay").classList.add("open");
  }
  _renderHeader() {
    if (!this._root) return;
    const now = new Date();
    this._root.querySelector(".date-title-text").textContent = this._config.title || __fhT("text.today", "Today");
    this._root.querySelector(".date-sub").textContent = this._fmtDate(now, {
      weekday: "long",
      month: "long",
      day: "numeric",
    });
    // Per-calendar custody/status badges (Settings -> Calendars -> Add badge) that matched one of today's events
    const badgesEl = this._root.querySelector(".header-badges");
    if (badgesEl) {
      badgesEl.innerHTML =
        (this._todayBadges || [])
          .map((b) => `<span class="custody-badge" style="background:${b.color};color:${this._textColorFor(b.color)}">${b.text}</span>`)
          .join("") +
        (this._todayHolidays || [])
          .map((h) => `<span class="holiday-chip" style="--holiday-color:${h.color}" title="${String(h.summary).replace(/"/g, "&quot;").replace(/</g, "&lt;")}">${h.kind === "birthday" ? "\u{1F382}" : h.kind === "special" && /anniversar|wedding|hochzeit|boda|mariage|matrimonio|bruiloft|ślub|casamento/i.test(h.summary) ? "\u{1F48D}" : this._holidayIcon(h.summary)} ${String(h.summary).replace(/&/g, "&amp;").replace(/</g, "&lt;")}</span>`)
          .join("");
    }
    this._renderFooterActions();
  }
  // extracted out of _render()'s old inline click handlers so both layouts
  _openEventDetail(ev) {
    const rows = [];
    rows.push({ text: ev.allDay ? this._t("today.detail.all_day", "All day") : `${this._fmtTime(ev.start)}${ev.end ? " - " + this._fmtTime(ev.end) : ""}` });
    if (ev.location) rows.push({ text: `\u{1F4CD} ${ev.location}`, secondary: true });
    if (ev.description) rows.push({ text: ev.description, secondary: true });
    this._openDetail({ chip: ev.personName, chipColor: ev.color, title: ev.summary, rows });
  }
  _openMealDetail(m) {
    const rows = [{ text: m.description || this._t("today.detail.no_notes_added", "No notes added."), secondary: !m.description }];
    this._openDetail({
      chip: m.label,
      chipColor: m.color || null,
      title: m.name,
      rows,
      actionLabel: m.link ? `\u{1F517} ${this._t("today.detail.open_recipe_link", "Open recipe link")}` : null,
      actionHandler: m.link ? () => window.open(m.link, "_blank", "noopener") : null,
    });
  }
  _openChoreDetail(r) {
    const dueTime = this._fmtTime(r.due);
    const rows = [{ text: this._t("today.detail.due_x", `Due ${dueTime}`, { time: dueTime }) }];
    if (r.description) rows.push({ text: __fhEsc(r.description), secondary: true });
    if (!r.choreAssignedTo) rows.push({ text: this._t("event_info.chore_bin_hint", "This chore is in the Chore Bin. Grab it on the Chores card."), secondary: true });
    this._openDetail({
      chip: `\u{1F9F9} ${r.personName ? `${this._t("event_info.chore", "Chore")} • ${r.personName}` : this._t("event_info.chore", "Chore")}`,
      chipColor: r.color || TODAY_REMINDER_COLOR,
      title: r.summary,
      rows,
      actionLabel: r.choreAssignedTo ? `✓ ${this._t("today.detail.mark_done", "Mark done")}` : null,
      actionHandler: r.choreAssignedTo
        ? () => {
            this._markReminderDone(r.uid, "");
            this._closeDetail();
          }
        : null,
    });
  }
  _openReminderDetail(r) {
    if (r.isChore) return this._openChoreDetail(r);
    const dueTime = this._fmtTime(r.due);
    const rows = [{ text: this._t("today.detail.due_x", `Due ${dueTime}`, { time: dueTime }) }];
    if (r.description) rows.push({ text: r.description, secondary: true });
    this._openDetail({
      chip: r.personName
        ? this._t("today.detail.reminder_person_chip", `Reminder • ${r.personName}`, { name: r.personName })
        : this._t("today.detail.reminder_chip", "Reminder"),
      chipColor: r.color || TODAY_REMINDER_COLOR,
      title: r.summary,
      rows,
      actionLabel: `✓ ${this._t("today.detail.mark_done", "Mark done")}`,
      actionHandler: () => {
        this._markReminderDone(r.uid, r.listEntity);
        this._closeDetail();
      },
    });
  }
  _render() {
    if (!this._root) return;
    this._renderHeader();
    const wxEl = this._root.querySelector(".wx");
    if (this._forecastToday) {
      const f = this._forecastToday;
      const high = typeof f.high === "number" ? Math.round(f.high) : "-";
      const low = typeof f.low === "number" ? Math.round(f.low) : "-";
      wxEl.textContent = `${this._wxIcon(f.condition)} ${high}°/${low}°`;
    } else {
      wxEl.textContent = "";
    }

    if (this._config.layout === "compact") {
      this._renderCompactBody();
    } else {
      this._renderSectionedBody();
    }

    this._renderFooterActions();
  }
  // The card's original layout - three separately labeled, independently
  // rendered lists. Unchanged from before the "compact" layout existed.
  _renderSectionedBody() {
    const root = this._root;
    root.querySelectorAll(".section").forEach((el) => (el.style.display = ""));
    const compactEl = root.querySelector(".today-compact-items");
    if (compactEl) compactEl.style.display = "none";

    const eventsEl = root.querySelector(".events-list");
    if (!this._todayEvents.length) {
      eventsEl.innerHTML = `<div class="empty">${this._t("today.sectioned.events_empty", "Nothing on the calendar today.")}</div>`;
    } else {
      eventsEl.innerHTML = this._todayEvents
        .map((ev, idx) => {
          const pct = this._nowPct(ev);
          const meta = ev.allDay ? this._t("today.detail.all_day", "All day") : `${this._nowTag(pct)}${this._fmtTime(ev.start)}`;
          const pic = ev.picture;
          return `<div class="row${pct !== null ? " is-now" : ""}" data-idx="${idx}"><span class="dot${pic ? " has-pic" : ""}" style="background:${ev.color};${this._picStyle(pic)}"></span><span class="label">${ev.summary}${this._ageSuffix(ev)}${this._nowBar(pct)}</span><span class="meta">${meta}</span></div>`;
        })
        .join("");
      eventsEl.querySelectorAll(".row").forEach((row) => {
        row.addEventListener("click", () => {
          const ev = this._todayEvents[parseInt(row.dataset.idx, 10)];
          if (ev) this._openEventDetail(ev);
        });
      });
    }

    const mealsEl = root.querySelector(".meals-list");
    if (!this._todayMeals.length) {
      mealsEl.innerHTML = `<div class="empty">${this._t("today.sectioned.meals_empty", "Nothing planned yet.")}</div>`;
    } else {
      mealsEl.innerHTML = this._todayMeals
        .map((m, idx) => `<div class="row" data-idx="${idx}"><span class="dot" style="background:${m.color || "var(--fc-accent2)"}"></span><span class="label">${m.name}</span><span class="meta">${m.label}</span></div>`)
        .join("");
      mealsEl.querySelectorAll(".row").forEach((row) => {
        row.addEventListener("click", () => {
          const m = this._todayMeals[parseInt(row.dataset.idx, 10)];
          if (m) this._openMealDetail(m);
        });
      });
    }

    const remindersEl = root.querySelector(".reminders-list");
    if (!this._todayReminders.length) {
      remindersEl.innerHTML = `<div class="empty">${this._t("today.sectioned.reminders_empty", "No reminders due today.")}</div>`;
    } else {
      const doneLabel = this._t("common.done", "Done");
      remindersEl.innerHTML = this._todayReminders
        .map(
          (r, idx) =>
            `<div class="row" data-idx="${idx}"><span class="dot" style="background:${r.color || TODAY_REMINDER_COLOR}"></span><span class="label">${r.isChore ? "&#129529;" : "&#128276;"} ${r.isChore ? __fhEsc(r.summary) : r.summary}${r.personName ? ` <span class="reminder-owner">(${r.isChore ? __fhEsc(r.personName) : r.personName})</span>` : ""}</span><span class="meta">${this._fmtTime(r.due)}</span>${r.isChore && !r.choreAssignedTo ? "" : `<button type="button" class="done-btn" data-uid="${r.uid}" data-list-entity="${r.listEntity}">${doneLabel}</button>`}</div>`
        )
        .join("");
      remindersEl.querySelectorAll(".done-btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          btn.disabled = true;
          this._markReminderDone(btn.dataset.uid, btn.dataset.listEntity);
        });
      });
      remindersEl.querySelectorAll(".row").forEach((row) => {
        row.addEventListener("click", (e) => {
          if (e.target.closest(".done-btn")) return;
          const r = this._todayReminders[parseInt(row.dataset.idx, 10)];
          if (r) this._openReminderDetail(r);
        });
      });
    }
  }
  // Mirrors family-week-calendar-card.js's own _buildMonthSplitDetailHtml as closely as this card's own already- fetched data allows: meal
  _renderCompactBody() {
    const root = this._root;
    root.querySelectorAll(".section").forEach((el) => (el.style.display = "none"));
    const compactEl = root.querySelector(".today-compact-items");
    if (!compactEl) return;
    compactEl.style.display = "";

    const mealsHtml = (this._todayMeals || [])
      .map(
        (m, idx) =>
          `<div class="msd-item mc-meal-pill" data-kind="meal" data-idx="${idx}" style="background:${m.color || "#f0e6c4"}">\u{1F37D}\u{FE0F} ${m.name}</div>`
      )
      .join("");

    const combined = [];
    (this._todayEvents || []).forEach((ev, idx) => {
      combined.push({ kind: "event", idx, start: ev.start, end: ev.end, allDay: !!ev.allDay, color: ev.color, isReminder: false, summary: ev.summary + this._ageSuffix(ev), picture: ev.picture, nowPct: this._nowPct(ev) });
    });
    (this._todayReminders || []).forEach((r, idx) => {
      combined.push({ kind: "reminder", idx, start: r.due, allDay: false, color: r.color || TODAY_REMINDER_COLOR, isReminder: true, isChore: !!r.isChore, summary: r.isChore ? __fhEsc(r.summary) : r.summary });
    });
    combined.sort((a, b) => (a.allDay === b.allDay ? a.start - b.start : a.allDay ? -1 : 1));

    const itemsHtml = combined.length
      ? combined
          .map(
            (it) =>
              `<div class="msd-item" data-kind="${it.kind}" data-idx="${it.idx}" style="background:${it.color};color:${this._textColorFor(it.color)}">` +
              (it.picture ? `<span class="msd-pic" style="${this._picStyle(it.picture)}"></span>` : "") +
              `<span class="msd-item-time">${it.allDay ? this._t("today.detail.all_day", "All day") : `${this._nowTag(it.nowPct)}${this._fmtTime(it.start)}`}</span>` +
              `<span class="msd-item-summary">${it.isReminder ? (it.isChore ? "&#129529; " : "&#128276; ") : ""}${it.summary}${this._nowBar(it.nowPct)}</span>` +
              `</div>`
          )
          .join("")
      : `<div class="msd-empty">${this._t("today.compact.nothing_scheduled", "Nothing scheduled")}</div>`;

    compactEl.innerHTML = mealsHtml + itemsHtml;
    compactEl.querySelectorAll(".msd-item[data-kind]").forEach((el) => {
      el.addEventListener("click", () => {
        const idx = parseInt(el.dataset.idx, 10);
        if (el.dataset.kind === "meal") {
          const m = this._todayMeals[idx];
          if (m) this._openMealDetail(m);
        } else if (el.dataset.kind === "event") {
          const ev = this._todayEvents[idx];
          if (ev) this._openEventDetail(ev);
        } else if (el.dataset.kind === "reminder") {
          const r = this._todayReminders[idx];
          if (r) this._openReminderDetail(r);
        }
      });
    });
  }
  // Optional footer button - only rendered when a dashboard path is actually configured, so cards that don't want it look unchanged.
  _renderFooterActions() {
    if (!this._root) return;
    const footerEl = this._root.querySelector(".footer-actions");
    if (!footerEl) return;
    const calendarPath = (this._config.calendar_dashboard_path || "").trim();
    // Both buttons (either, neither, or both may be present depending on config) live in one flex row rather than each being its own full-width
    const buttonsHtml = [];
    if (this._config.show_add_button) {
      buttonsHtml.push(`<button type="button" class="footer-add-btn">&#10133; ${this._t("common.add", "Add")}</button>`);
    }
    if (calendarPath) {
      const label = this._config.calendar_button_label || `\u{1F4C5} ${this._t("today.footer.go_to_calendar", "Go to Calendar")}`;
      buttonsHtml.push(`<button type="button" class="go-to-calendar-btn">${label}</button>`);
    }
    if (buttonsHtml.length) {
      footerEl.innerHTML = `<div class="footer-actions-row">${buttonsHtml.join("")}</div>`;
      const addBtn = footerEl.querySelector(".footer-add-btn");
      if (addBtn) addBtn.addEventListener("click", () => this._openAddEvent("calendar"));
      const calBtn = footerEl.querySelector(".go-to-calendar-btn");
      if (calBtn) calBtn.addEventListener("click", () => this._goToCalendar());
    } else {
      footerEl.innerHTML = "";
    }
  }
}

if (!customElements.get("family-today-card")) {
  customElements.define("family-today-card", FamilyTodayCard);
}

// native "Edit Card" config editor - a thin wrapper around Home Assistant's own <ha-form>
class FamilyTodayCardEditor extends HTMLElement {
  setConfig(config) {
    this._config = config || {};
    this._render();
  }
  set hass(hass) {
    this._hass = hass;
    if (!this._themeOptions) this._fetchThemeOptions();
    else this._render();
  }
  async _fetchThemeOptions() {
    this._themeOptions = [{ value: "", label: "Use device settings (default)" }];
    if (!this._hass) {
      this._render();
      return;
    }
    try {
      const result = await this._hass.connection.sendMessagePromise({ type: "theme_builder/list" });
      const custom = (result && Array.isArray(result.themes)) ? result.themes : [];
      custom.forEach((t) => {
        if (t && t.id) this._themeOptions.push({ value: t.id, label: "Theme Builder: " + (t.name || t.id) });
      });
    } catch (e) {
    }
    this._themeOptions.push({ value: "ha:__default__", label: "Home Assistant: Default" });
    const themes = (this._hass && this._hass.themes && this._hass.themes.themes) || {};
    Object.keys(themes)
      .filter((name) => name.indexOf("Theme Builder - ") !== 0)
      .sort((a, b) => a.localeCompare(b))
      .forEach((name) => this._themeOptions.push({ value: "ha:" + name, label: "Home Assistant: " + name }));
    this._render();
  }
  _schema() {
    return FamilyTodayCard._configSchema().concat([
      { name: "theme_override", selector: { select: { mode: "dropdown", options: this._themeOptions || [{ value: "", label: "Use device settings (default)" }] } } },
    ]);
  }
  _render() {
    if (!this._form) {
      this._form = document.createElement("ha-form");
      this._form.addEventListener("value-changed", (e) => {
        e.stopPropagation();
        this._config = e.detail.value;
        this.dispatchEvent(new CustomEvent("config-changed", { detail: { config: this._config }, bubbles: true, composed: true }));
      });
      this.appendChild(this._form);
    }
    this._form.hass = this._hass;
    this._form.data = this._config || {};
    this._form.schema = this._schema();
    this._form.computeLabel = FamilyTodayCard._computeLabel;
    this._form.computeHelper = FamilyTodayCard._computeHelper;
  }
}
if (!customElements.get("family-today-card-editor")) {
  customElements.define("family-today-card-editor", FamilyTodayCardEditor);
}

window.customCards = window.customCards || [];
if (!window.customCards.some((c) => c.type === "family-today-card")) {
  window.customCards.push({
    type: "family-today-card",
    name: "Family Hub Today",
    description: "A compact single-day companion to the Family Week Calendar card - today's events, meals, and due reminders at a glance.",
  });
}
