// FH-EINK START - source: tools/eink_kit.js, copied into each card by tools/sync_eink_kit.py
// 2026.11.1.16: E-ink screen and Accessibility for every card. Each card attaches with the bits that show a person's
// colour (dots, pills, avatars, tiles) and a little CSS of its own; this does the rest.
//  - E-ink screen (per device, from the calendar's Settings or ?fh_eink=...): black on white with outlines, no
//    shadows/blur/motion, each person's colour turned into the same pattern (black & white) or real ink (6 ink) the
//    calendar gives them, or a stronger version of it (Kaleido).
//  - Accessibility (household setting, settings.accessibility, with per-device overrides, like the rest of Settings):
//    Color vision (a shape and a pattern per person, not just a colour), High contrast (the black & white e-ink look on
//    any screen), Text size, Font (Atkinson Hyperlegible / Lexend, bundled), Reduce motion, Bigger buttons.
(function () {
if (window.__familyHubEink) return;
const MODES = ["bw", "color6", "kaleido"];
const PATTERNS = [
"linear-gradient(#000,#000)",
"repeating-linear-gradient(45deg,#000 0 3px,#fff 3px 6px)",
"radial-gradient(circle,#000 1.6px,#fff 1.9px) 0 0/6px 6px",
"repeating-linear-gradient(0deg,#000 0 2px,#fff 2px 5px)",
"repeating-linear-gradient(90deg,#000 0 2px,#fff 2px 4px)",
"repeating-linear-gradient(45deg,#000 0 1.5px,transparent 1.5px 5px),repeating-linear-gradient(-45deg,#000 0 1.5px,#fff 1.5px 5px)",
"repeating-conic-gradient(#000 0 25%,#fff 0 50%) 0 0/6px 6px",
"repeating-linear-gradient(-45deg,#000 0 6px,#fff 6px 10px)",
];
// Color vision: one shape per person, in the household's order (circle, square, diamond, hexagon, triangle, star,
// pentagon, cross) - used as a clip-path on their avatar/dot
const SHAPES = [
"circle(50% at 50% 50%)",
"inset(6% round 3px)",
"polygon(50% 0,100% 50%,50% 100%,0 50%)",
"polygon(25% 3%,75% 3%,100% 50%,75% 97%,25% 97%,0 50%)",
"polygon(50% 0,100% 95%,0 95%)",
"polygon(50% 0,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%)",
"polygon(50% 0,100% 38%,82% 100%,18% 100%,0 38%)",
"polygon(33% 0,67% 0,67% 33%,100% 33%,100% 67%,67% 67%,67% 100%,33% 100%,33% 67%,0 67%,0 33%,33% 33%)",
];
const SHAPE_NAMES = ["circle", "square", "diamond", "hexagon", "triangle", "star", "pentagon", "cross"];
const INKS = [["red", "#d0201a", 0], ["yellow", "#f0c400", 50], ["green", "#1d8a3a", 130], ["blue", "#1a4fc0", 220]];
// a dashboard link can switch E-ink screen on for the device that opens it: ?fh_eink=bw|color6|kaleido|off
// (&fh_eink_tap=off) - for a frame showing only Today or Chores, where there's no calendar Settings to do it from
function fromUrl() {
try {
const q = new URLSearchParams(window.location.search);
const m = q.get("fh_eink");
if (m && (MODES.includes(m) || m === "off")) localStorage.setItem("familyHubEinkModeLocal", m);
const t = q.get("fh_eink_tap");
if (t === "on" || t === "off") localStorage.setItem("familyHubEinkTappableLocal", t);
} catch (e) {
}
}
fromUrl();
// ---- Accessibility ----
const A11Y = {
colorVision: ["familyHubA11yColorVisionLocal", ["off", "shapes"], "off"],
highContrast: ["familyHubA11yHighContrastLocal", ["off", "on"], "off"],
textScale: ["familyHubA11yTextScaleLocal", ["100", "125", "150", "175", "200"], "100"],
font: ["familyHubA11yFontLocal", ["theme", "legible", "dyslexia"], "theme"],
motion: ["familyHubA11yMotionLocal", ["device", "always", "off"], "device"],
bigButtons: ["familyHubA11yBigButtonsLocal", ["off", "on"], "off"],
};
function a11yClean(obj) {
const out = {};
Object.keys(A11Y).forEach((k) => {
const [, ok, def] = A11Y[k];
const v = obj && obj[k] !== undefined && obj[k] !== null ? String(obj[k]) : def;
out[k] = ok.includes(v) ? v : def;
});
return out;
}
function a11yHousehold() {
try {
const v = JSON.parse(localStorage.getItem("familyHubA11yHouseholdLocal") || "{}");
return a11yClean(v && typeof v === "object" ? v : {});
} catch (e) {
return a11yClean({});
}
}
// this device's own choices ("household" or nothing = follow the household)
function a11yDevice() {
const out = {};
Object.keys(A11Y).forEach((k) => {
try {
const v = localStorage.getItem(A11Y[k][0]);
if (v && v !== "household" && A11Y[k][1].includes(v)) out[k] = v;
} catch (e) {
}
});
return out;
}
function a11y() {
const v = Object.assign(a11yHousehold(), a11yDevice());
let reduce = v.motion === "always";
if (v.motion === "device") {
try {
reduce = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
} catch (e) {
}
}
v.reduceMotion = reduce;
return v;
}
function setHousehold(obj) {
const next = JSON.stringify(a11yClean(obj || {}));
let before = null;
try {
before = localStorage.getItem("familyHubA11yHouseholdLocal");
} catch (e) {
}
if (before === next) return;
try {
localStorage.setItem("familyHubA11yHouseholdLocal", next);
} catch (e) {
}
refreshAll();
}
// 2026.11.2.11: "Card background: See-through" (household settings.seeThroughBackground): the cards leave their own
// background empty so the dashboard's (an animated background, a wallpaper) shows through; never in e-ink/high contrast,
// nor while a card shows a photo of its own (the calendar's full-screen holiday photo sets fh-own-bg)
function seeThrough() {
try {
return localStorage.getItem("familyHubSeeThroughLocal") === "1";
} catch (e) {
return false;
}
}
function setSeeThrough(on) {
const next = on ? "1" : "";
let before = "";
try {
before = localStorage.getItem("familyHubSeeThroughLocal") || "";
} catch (e) {
}
if (before === next) return;
try {
localStorage.setItem("familyHubSeeThroughLocal", next);
} catch (e) {
}
refreshAll();
}
const SEE_THROUGH_CSS = `
:host([fh-see-through]:not([fh-own-bg])) ha-card { background-color: transparent !important; background-image: none !important; box-shadow: none !important; }
:host([fh-see-through]:not([fh-own-bg])) ha-card::before { display: none !important; }
`;
function applySeeThrough(host) {
const on = seeThrough() && mode() === "off";
if (on) host.setAttribute("fh-see-through", "");
else host.removeAttribute("fh-see-through");
const root = host.shadowRoot;
if (on && root && !root.querySelector("style[data-fh-see-through]")) {
const s = document.createElement("style");
s.setAttribute("data-fh-see-through", "");
s.textContent = SEE_THROUGH_CSS;
root.appendChild(s);
}
}
// every card loads the household settings itself; this reads the Accessibility part of them, at most every 5 minutes
let householdFetch = null, householdAt = 0;
function loadHousehold(hass) {
if (!hass || !hass.connection || householdFetch || Date.now() - householdAt < 5 * 60 * 1000) return;
householdFetch = hass.connection.sendMessagePromise({ type: "family_hub/get_settings" })
.then((r) => {
const s = r && r.settings;
if (s && typeof s === "object") {
setHousehold(s.accessibility || {});
setSeeThrough(s.seeThroughBackground === true);
}
})
.catch(() => {})
.then(() => {
householdFetch = null;
householdAt = Date.now();
});
}
let fontsAdded = false;
function ensureFonts() {
if (fontsAdded || !document.head) return;
fontsAdded = true;
const face = (family, file, weight, range) => `@font-face { font-family: "${family}"; font-style: normal; font-display: swap; font-weight: ${weight}; src: url("/family_hub_fonts/${file}.woff2") format("woff2"); unicode-range: ${range}; }`;
const LATIN = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD";
const EXT = "U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF";
const css = [];
[["FH Atkinson Hyperlegible", "atkinson-hyperlegible"], ["FH Lexend", "lexend"]].forEach(([family, file]) => {
[400, 700].forEach((w) => {
css.push(face(family, `${file}-latin-${w}-normal`, w, LATIN));
css.push(face(family, `${file}-latin-ext-${w}-normal`, w, EXT));
});
});
const st = document.createElement("style");
st.id = "family-hub-a11y-fonts";
st.textContent = css.join("\n");
document.head.appendChild(st);
}
// ---- E-ink ----
// the real E-ink screen setting of this device
function deviceMode() {
try {
const v = localStorage.getItem("familyHubEinkModeLocal");
return MODES.includes(v) ? v : "off";
} catch (e) {
return "off";
}
}
// the look: the device's E-ink screen, or High contrast (the black & white e-ink look on a normal screen)
function mode() {
const m = deviceMode();
if (m !== "off") return m;
return a11y().highContrast === "on" ? "bw" : "off";
}
function tappable() {
try {
return localStorage.getItem("familyHubEinkTappableLocal") !== "off";
} catch (e) {
return true;
}
}
function toHex(color) {
const c = String(color || "").trim().toLowerCase();
let m = c.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/);
if (m) return m[1].length === 3 ? "#" + m[1].split("").map((x) => x + x).join("") : c;
m = c.match(/^rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)(?:[ ,/]+([\d.]+))?/);
if (!m) return null;
if (m[4] !== undefined && parseFloat(m[4]) < 0.5) return null;
return "#" + [m[1], m[2], m[3]].map((n) => (+n).toString(16).padStart(2, "0")).join("");
}
function hsl(hex) {
const r = parseInt(hex.slice(1, 3), 16) / 255, g = parseInt(hex.slice(3, 5), 16) / 255, b = parseInt(hex.slice(5, 7), 16) / 255;
const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2;
let h = 0, s = 0;
if (max !== min) {
const d = max - min;
s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
h *= 60;
}
return { h, s, l };
}
// the household's people colours in order, as the calendar last worked them out on this device
function household() {
try {
const v = JSON.parse(localStorage.getItem("familyHubEinkPeopleLocal") || "[]");
return Array.isArray(v) ? v.map((x) => toHex(x)).filter(Boolean) : [];
} catch (e) {
return [];
}
}
const seen = [];
let cache = { sig: "", map: {} };
function order() {
const list = household();
seen.forEach((c) => { if (!list.includes(c)) list.push(c); });
return list;
}
// where a colour sits in the household's order (new colours join the end, in the order they're seen)
function personIndex(hex) {
let list = order();
if (!list.includes(hex)) {
seen.push(hex);
list = order();
}
return list.indexOf(hex);
}
function mapFor(m) {
const list = order();
const sig = m + "|" + list.join(",");
if (cache.sig === sig) return cache.map;
const map = {};
const used = new Set();
list.forEach((c, i) => {
if (m === "bw") {
map[c] = PATTERNS[i % PATTERNS.length];
return;
}
const x = hsl(c);
const ranked = x.s < 0.12 ? [["black", "#000", 0]] : INKS.slice().sort((a, b) => {
const d = (k) => Math.min(Math.abs(x.h - k[2]), 360 - Math.abs(x.h - k[2]));
return d(a) - d(b);
}).concat([["black", "#000", 0]]);
const free = ranked.find((ink) => !used.has(ink[0]));
if (free) {
used.add(free[0]);
map[c] = `linear-gradient(${free[1]},${free[1]})`;
} else {
map[c] = `repeating-linear-gradient(45deg,${ranked[0][1]} 0 3px,#fff 3px 6px)`;
}
});
cache = { sig, map };
return map;
}
// the background a person's colour gets on this e-ink screen; null to leave it as it is
function background(color, m) {
m = m || mode();
if (m === "off") return null;
const hex = toHex(color);
if (!hex) return null;
const x = hsl(hex);
if (x.l > 0.94) return null; // white-ish: already fine
if (m === "kaleido") return `hsl(${Math.round(x.h)} ${Math.round(Math.min(1, Math.max(0.6, x.s * 1.6 + 0.15)) * 100)}% 58%)`;
if (!household().includes(hex) && !seen.includes(hex)) seen.push(hex);
return mapFor(m)[hex];
}
// Color vision: a person's shape, a darker shade of their colour (for the shape and the pattern) and their pattern in it
function darker(hex) {
const n = (i) => Math.round(parseInt(hex.slice(i, i + 2), 16) * 0.42);
return `rgb(${n(1)}, ${n(3)}, ${n(5)})`;
}
function cvFor(color) {
const hex = toHex(color);
if (!hex || hsl(hex).l > 0.94) return null;
const i = personIndex(hex);
const dark = darker(hex);
const pattern = PATTERNS[i % PATTERNS.length].replace(/#000/g, dark).replace(/#fff/g, "transparent");
return { shape: SHAPES[i % SHAPES.length], shapeName: SHAPE_NAMES[i % SHAPE_NAMES.length], dark, pattern, index: i };
}
const BASE_CSS = `
:host([eink]) > * { --fc-bg: #fff; --fc-card: #fff; --fc-card-opaque: #fff; --fc-card-menu: #fff; --fc-surface-alt: #fff; --fc-surface2: #fff; --fc-text: #000; --fc-text-secondary: #222; --fc-text-muted: #333; --fc-border: #000; --fc-accent: #000; --fc-accent-text: #fff; --fc-accent2: #000; --fc-accent3: #000; --fc-accent-soft: #fff; --fc-shadow: none; --fc-now: #000; --fc-now-text: #fff; --fc-glass-blur: 0px; --fc-bg-blur: 0px; --fc-bg-image: none; --fc-bg-overlay-image: none; --fc-danger: #000; }
:host([eink]) *, :host([eink]) *::before, :host([eink]) *::after { transition: none !important; animation: none !important; box-shadow: none !important; text-shadow: none !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }
:host([eink]) ha-card { background: #fff !important; color: #000 !important; border: 2px solid #000 !important; border-radius: 8px !important; }
:host([eink]) button:not([data-fh-eink-dot]), :host([eink]) select, :host([eink]) input { border-color: #000 !important; }
:host([eink]) [data-fh-eink-dot] { outline: 1.5px solid #000; outline-offset: -1.5px; }
:host([eink="kaleido"]) [data-fh-eink-dot] { outline: none; }
:host([eink]) .confetti, :host([eink]) .confetti-piece, :host([eink]) .fh-confetti, :host([eink]) [class*="confetti"] { display: none !important; }
:host([eink]) .person-pill, :host([eink]) .pill { color: #000 !important; border: 2px solid #000 !important; }
:host([eink]) .person-pill *, :host([eink]) .pill * { color: #000 !important; }
:host([eink="bw"]) [data-fh-eink-strip], :host([eink="color6"]) [data-fh-eink-strip] { background: linear-gradient(90deg, transparent 0 10px, #fff 10px), var(--fh-eink-strip) !important; padding-left: 15px !important; color: #000 !important; border: 2px solid #000 !important; }
:host([eink="kaleido"]) [data-fh-eink-strip] { color: #000 !important; }
:host([eink]) button:disabled, :host([eink]) button[disabled] { background: #fff !important; color: #444 !important; border: 2px dashed #000 !important; opacity: 1 !important; }
:host([eink]) .person-pill.active-filter, :host([eink]) .pill.active { outline: 3px solid #000; outline-offset: 1px; }
:host([eink]) .person-pill.dimmed { opacity: 1 !important; border-style: dashed !important; }
:host([eink="bw"]) img, :host([eink="bw"]) .has-pic { filter: grayscale(1) contrast(1.3); }
:host([eink-static]) [class$="-fab"], :host([eink-static]) [class*="-fab "], :host([eink-static]) .fab { display: none !important; }
`;
// Accessibility styling every card shares (the calendar has the same rules for its own parts)
const A11Y_CSS = `
:host([a11y-cv]) [data-fh-cv-fill] { clip-path: var(--fh-cv-shape); border-radius: 0 !important; outline: none !important; min-width: 14px; min-height: 14px; }
:host([a11y-cv]) [data-fh-cv-strip] { background: linear-gradient(90deg, transparent 0 10px, var(--fh-cv-base) 10px), var(--fh-cv-pattern), var(--fh-cv-base) !important; padding-left: 15px !important; }
:host([a11y-cv]) [data-fh-cv-strip-avatar] .avatar:not(.has-pic), :host([a11y-cv]) [data-fh-cv-strip-avatar] .person-pill-avatar:not(.has-pic) { clip-path: var(--fh-cv-shape); border-radius: 0 !important; background: var(--fh-cv-dark) !important; color: #fff !important; }
:host([a11y-cv][eink]) [data-fh-cv-strip-avatar] .avatar:not(.has-pic), :host([a11y-cv][eink]) [data-fh-cv-strip-avatar] .person-pill-avatar:not(.has-pic) { background: #000 !important; border: none !important; }
:host([a11y-motion]) *, :host([a11y-motion]) *::before, :host([a11y-motion]) *::after { animation: none !important; transition: none !important; scroll-behavior: auto !important; }
:host([a11y-motion]) .confetti, :host([a11y-motion]) .confetti-piece, :host([a11y-motion]) [class*="confetti"] { display: none !important; }
:host([a11y-font="legible"]) > * { --fc-font-family: "FH Atkinson Hyperlegible", Verdana, sans-serif; font-family: "FH Atkinson Hyperlegible", Verdana, sans-serif !important; }
:host([a11y-font="dyslexia"]) > * { --fc-font-family: "FH Lexend", Verdana, sans-serif; font-family: "FH Lexend", Verdana, sans-serif !important; letter-spacing: 0.02em; word-spacing: 0.08em; }
:host([a11y-font]) button, :host([a11y-font]) input, :host([a11y-font]) select, :host([a11y-font]) textarea { font-family: inherit !important; letter-spacing: inherit; }
:host([a11y-scale]) > :not(style) { zoom: var(--fh-text-scale, 1); }
:host([a11y-scale]) * { -webkit-hyphens: auto; hyphens: auto; word-break: normal !important; overflow-wrap: break-word; }
:host([a11y-big]) button, :host([a11y-big]) select, :host([a11y-big]) [role="button"] { min-height: 46px; min-width: 46px; }
:host([a11y-big]) input[type="checkbox"], :host([a11y-big]) input[type="radio"] { width: 24px !important; height: 24px !important; }
:host([a11y-big]) [class$="-fab"], :host([a11y-big]) .fab { width: 72px !important; height: 72px !important; font-size: 34px !important; }
`;
const attached = new Map();
// what the kit changed on an element, so it can put it back when it's turned off
function restore(el) {
if (el.dataset.fhEinkSet === undefined) return;
el.dataset.fhEinkSet.split(",").filter(Boolean).forEach((prop) => el.style.removeProperty(prop));
if (el.dataset.fhEinkOrigBg) el.style.backgroundColor = el.dataset.fhEinkOrigBg;
const from = el.dataset.fhEinkFrom;
if (from && el.dataset.fhEinkOrig) {
if (from === "border") el.style.borderColor = el.dataset.fhEinkOrig;
else if (from.startsWith("--")) el.style.setProperty(from, el.dataset.fhEinkOrig);
}
["fhEinkFrom", "fhEinkMode", "fhEinkSet", "fhEinkOrig", "fhEinkOrigBg", "fhEinkStrip", "fhEinkDot", "fhCvFill", "fhCvStrip", "fhCvStripAvatar"].forEach((k) => delete el.dataset[k]);
}
function setProps(el, props) {
const names = [];
Object.keys(props).forEach((prop) => {
el.style.setProperty(prop, props[prop], prop.startsWith("--") ? "" : "important");
names.push(prop);
});
el.dataset.fhEinkSet = names.join(",");
}
// where a person's colour sits on an element: its background, its border, or a CSS variable (--person-color)
function colorOf(el, from) {
if (!from || from === "background") return el.style.backgroundColor;
if (from === "border") return el.style.borderTopColor || el.style.borderColor;
return el.style.getPropertyValue(from);
}
function recolor(host, st) {
const root = host.shadowRoot;
if (!root) return;
const m = mode();
const cv = a11y().colorVision === "shapes";
const key = m + (cv ? "+cv" : "");
const groups = [];
(st.opts.strip || []).forEach((sel) => groups.push([sel, "background", "strip"]));
(st.opts.stripFrom || []).forEach(([sel, from]) => groups.push([sel, from, "strip"]));
(st.opts.recolor || []).forEach((sel) => groups.push([sel, "background", "fill"]));
(st.opts.shapes || []).forEach((sel) => groups.push([sel, "background", "shape"]));
groups.forEach(([sel, from, kind]) => root.querySelectorAll(sel).forEach((el) => {
if (m === "off" && !cv) return restore(el);
if (kind !== "strip" && (el.classList.contains("has-pic") || /url\(/.test(el.style.backgroundImage || ""))) return;
const orig = el.dataset.fhEinkOrig !== undefined ? el.dataset.fhEinkOrig : colorOf(el, from);
if (!orig) return;
if (el.dataset.fhEinkOrig === orig && el.dataset.fhEinkMode === key) return;
const bg = m !== "off" && kind !== "shape" ? background(orig, m) : null;
const c = cv ? cvFor(orig) : null;
if (!bg && !c) {
if (el.dataset.fhEinkSet !== undefined) restore(el);
return;
}
if (el.dataset.fhEinkSet !== undefined) restore(el);
el.dataset.fhEinkOrig = orig;
el.dataset.fhEinkMode = key;
el.dataset.fhEinkFrom = from;
if (from === "background") el.dataset.fhEinkOrigBg = orig;
const props = {};
if (c) {
props["--fh-cv-shape"] = c.shape;
props["--fh-cv-dark"] = c.dark;
}
if (bg) {
if (kind === "fill") {
el.dataset.fhEinkDot = "1";
props.background = bg;
} else if (m === "kaleido") {
// a colour tablet keeps the person's colour, stronger: as the fill it was, or as the border/variable it came from
el.dataset.fhEinkStrip = "1";
if (from === "background") props.background = bg;
else if (from === "border") props["border-color"] = bg;
else props[from] = bg;
} else {
el.dataset.fhEinkStrip = "1";
props["--fh-eink-strip"] = bg;
}
}
if (c && (kind === "fill" || kind === "shape")) el.dataset.fhCvFill = "1";
if (c && kind === "strip" && !bg) {
// a strip down the left in the person's own pattern, over the colour the element already had
el.dataset.fhCvStrip = "1";
props["--fh-cv-pattern"] = c.pattern;
props["--fh-cv-base"] = from === "background" ? orig : `color-mix(in srgb, ${orig} 16%, white)`;
}
if (c && kind === "strip") el.dataset.fhCvStripAvatar = "1";
setProps(el, props);
}));
}
function applyA11y(host) {
const v = a11y();
const set = (name, on, value) => (on ? host.setAttribute(name, value === undefined ? "" : value) : host.removeAttribute(name));
set("a11y-cv", v.colorVision === "shapes");
set("a11y-motion", v.reduceMotion || deviceMode() !== "off");
set("a11y-big", v.bigButtons === "on");
set("a11y-font", v.font !== "theme", v.font);
set("a11y-scale", v.textScale !== "100");
if (v.textScale !== "100") host.style.setProperty("--fh-text-scale", String(parseInt(v.textScale, 10) / 100));
else host.style.removeProperty("--fh-text-scale");
if (v.font !== "theme") ensureFonts();
return v;
}
function anyA11y(v) {
return v.colorVision !== "off" || v.reduceMotion || v.bigButtons !== "off" || v.font !== "theme" || v.textScale !== "100";
}
function apply(host) {
const st = attached.get(host);
if (!st) return;
// the calendar loads the household settings itself (and hands the Accessibility part over with setHousehold)
if (!st.opts.a11yOnly) loadHousehold(host._hass || host.hass);
const v = applyA11y(host);
applySeeThrough(host);
const root = host.shadowRoot;
if (st.opts.a11yOnly) {
// the calendar draws its own e-ink and colour vision; this just gives it the shared accessibility attributes
if (root && !root.querySelector("style[data-fh-a11y]")) {
const s = document.createElement("style");
s.setAttribute("data-fh-a11y", "");
s.textContent = A11Y_CSS;
root.appendChild(s);
}
return;
}
const m = mode();
if (m !== "off") host.setAttribute("eink", m);
else host.removeAttribute("eink");
if (deviceMode() !== "off" && !tappable()) host.setAttribute("eink-static", "");
else host.removeAttribute("eink-static");
if (!root) return;
const on = m !== "off" || anyA11y(v);
let styleEl = root.querySelector("style[data-fh-eink]");
if (on && !styleEl) {
styleEl = document.createElement("style");
styleEl.setAttribute("data-fh-eink", "");
styleEl.textContent = BASE_CSS + A11Y_CSS + (st.opts.css || "");
root.appendChild(styleEl);
} else if (!on && styleEl) {
styleEl.remove();
}
recolor(host, st);
}
function attach(host, opts, tries) {
let st = attached.get(host);
if (!st) {
st = { opts: opts || {}, obs: null, timer: null, queued: false };
attached.set(host, st);
}
if (st.obs) return;
if (!host.shadowRoot) {
if ((tries || 0) < 120) st.timer = setTimeout(() => attach(host, opts, (tries || 0) + 1), 250);
apply(host);
return;
}
st.obs = new MutationObserver(() => {
if (st.queued) return;
st.queued = true;
Promise.resolve().then(() => {
st.queued = false;
if (mode() !== "off" || anyA11y(a11y()) || host.shadowRoot.querySelector("[data-fh-eink-orig],style[data-fh-eink],style[data-fh-a11y]")) apply(host);
else if (!st.opts.a11yOnly) loadHousehold(host._hass || host.hass);
});
});
st.obs.observe(host.shadowRoot, { childList: true, subtree: true });
apply(host);
}
function detach(host) {
const st = attached.get(host);
if (!st) return;
if (st.obs) st.obs.disconnect();
clearTimeout(st.timer);
attached.delete(host);
}
const refreshAll = () => attached.forEach((st, host) => apply(host));
window.addEventListener("family-hub-eink-changed", refreshAll);
window.addEventListener("storage", (e) => { if (!e.key || /^familyHub(Eink|A11y|SeeThrough)/.test(e.key)) refreshAll(); });
try {
if (window.matchMedia) {
const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
if (mq && mq.addEventListener) mq.addEventListener("change", refreshAll);
}
} catch (e) {
}
window.__familyHubEink = {
mode, deviceMode, tappable, background, cvFor, a11y, a11yClean, setHousehold, seeThrough, setSeeThrough, ensureFonts, A11Y_KEYS: A11Y, SHAPES, SHAPE_NAMES,
attach: (host, opts) => {
if (window.__familyHubKeepAlive) window.__familyHubKeepAlive.connected(host);
attach(host, opts, 0);
},
detach: (host) => {
detach(host);
if (window.__familyHubKeepAlive) window.__familyHubKeepAlive.disconnected(host);
},
refreshAll, BASE_CSS, A11Y_CSS,
};
})();
// 2026.11.2: keep an open pop-up open when you switch away from Home Assistant and come back. When the app comes back
// and reconnects, Home Assistant reloads the dashboard and builds every card again, so a card that had a pop-up open
// lost it. Now: when the page is hidden, each card notes whether it has a pop-up open; if Home Assistant then replaces
// that card (within a minute of coming back), the new copy steps aside for the old one, pop-up and all, and passes
// Home Assistant's updates on to it.
(function () {
if (window.__familyHubKeepAlive) return;
const live = new Set();
const parked = [];
let visibleAt = 0;
const WINDOW_MS = 60000;
const ADOPT_MS = 20000;
const keyOf = (host) => {
if (host.__fhKeepKey === undefined) {
let cfg = "";
try { cfg = JSON.stringify(host._config || null); } catch (e) { cfg = ""; }
host.__fhKeepKey = host.tagName + "|" + cfg;
}
return host.__fhKeepKey;
};
// a pop-up: something fixed on screen, showing, and covering a good part of it
function modalOpen(host) {
const root = host.shadowRoot;
if (!root) return false;
const min = (window.innerWidth || 0) * (window.innerHeight || 0) * 0.2;
const els = root.querySelectorAll('[class*="modal"],[class*="overlay"],[class*="dialog"],[class*="sheet"],[class*="popup"],[class*="picker"],[class*="viewer"]');
for (let i = 0; i < els.length; i++) {
const cs = getComputedStyle(els[i]);
if (cs.position !== "fixed" || cs.display === "none" || cs.visibility === "hidden" || Number(cs.opacity) < 0.05) continue;
const r = els[i].getBoundingClientRect();
if (r.width * r.height >= min && min > 0) return true;
}
return false;
}
document.addEventListener("visibilitychange", () => {
if (document.visibilityState === "hidden") {
live.forEach((host) => {
try { host.__fhKeepModal = modalOpen(host); } catch (e) { host.__fhKeepModal = false; }
});
} else {
visibleAt = Date.now();
}
});
const recent = () => document.visibilityState === "hidden" || Date.now() - visibleAt < WINDOW_MS;
function disconnected(host) {
live.delete(host);
if (host.__fhKeepModal && recent()) parked.push({ host, key: keyOf(host), at: Date.now() });
}
let connected = function (host) {
live.add(host);
keyOf(host);
// after this card's own connectedCallback has run
setTimeout(() => {
const now = Date.now();
for (let i = parked.length - 1; i >= 0; i--) {
if (now - parked[i].at > ADOPT_MS || parked[i].host.isConnected) parked.splice(i, 1);
}
if (!host.isConnected || host.__fhAdopted) return;
const idx = parked.findIndex((p) => p.key === keyOf(host) && p.host !== host);
if (idx < 0) return;
const old = parked.splice(idx, 1)[0].host;
old.__fhKeepModal = false;
const latest = host._hass || host.hass;
try { host.replaceWith(old); } catch (e) { return; }
host.__fhAdopted = old;
// the card is back as it was, so nothing needs putting back from what was saved
try { localStorage.removeItem("familyHubResume:" + keyOf(old)); } catch (e) {}
// Home Assistant keeps talking to the card it made; pass it all on
Object.defineProperty(host, "hass", { configurable: true, get() { return old.hass; }, set(v) { old.hass = v; } });
host.setConfig = (c) => old.setConfig(c);
if (latest) old.hass = latest;
}, 0);
}
// --- after a full page reload (the iPhone app reloads the whole page after a while away) -------------------------
// Each card's pop-up openers are watched: what was opened, with what. When the page is hidden with a pop-up open, that
// list and what's typed in each open pop-up are saved on this device; when the same card loads again within 15
// minutes, the pop-ups are opened again, in order, and the typing put back.
const RESUME_MS = 15 * 60000;
const ready = {
calendar: (c) => !!c._settingsCache,
users: (c) => Array.isArray(c._notifyProfileUsersCache),
};
// per card: the pop-up openers to watch, what each needs before it can open again, and how to save/find its argument
const OPENERS = {
"FAMILY-WEEK-CALENDAR-CARD": {
__view: { ready: (c) => !!(c._settingsCache && c._viewMode) },
_openSettings: { ready: ready.calendar },
_setSettingsTab: { ready: ready.calendar, follows: true },
_openNotifyProfileModal: { ready: ready.users },
_openAddEvent: { ready: ready.calendar },
_openQuickAdd: { ready: ready.calendar },
_openEventInfo: {
save: (c, id) => { const d = (c._eventDetails || {})[id]; return d ? { uid: d.uid || "", start: d.start ? new Date(d.start).getTime() : 0, cal: d.calendarEntity || "", title: d.summary || "" } : null; },
find: (c, w) => {
const all = c._eventDetails || {};
return Object.keys(all).find((id) => { const d = all[id]; return d && (d.calendarEntity || "") === w.cal && (d.start ? new Date(d.start).getTime() : 0) === w.start && ((w.uid && d.uid === w.uid) || (!w.uid && d.summary === w.title)); });
},
},
_openEventInfoForEdit: { alias: "_openEventInfo" },
},
"FAMILY-HUB-CHORES-CARD": { _openCreateModal: {}, _openEditModal: {}, _openChoreDetailModal: {}, _openRoutineManageModal: {} },
"FAMILY-HUB-REWARDS-CARD": {
_openCreateRewardModal: {
save: (c, item) => (item && item.id ? { id: item.id } : null),
find: (c, w) => (c._catalog || []).find((it) => it.id === w.id),
optional: true,
},
_openGiftStarsModal: {}, _openManageStarsModal: {}, _openStarHistoryModal: {},
},
"FAMILY-HUB-TODO-CARD": { _openCreateModal: {}, _openItemDetailModal: {} },
};
const openOverlays = (host) => {
const root = host.shadowRoot;
if (!root) return [];
const out = [];
const min = (window.innerWidth || 0) * (window.innerHeight || 0) * 0.2;
root.querySelectorAll('[class*="modal"],[class*="overlay"],[class*="dialog"],[class*="sheet"],[class*="popup"],[class*="picker"],[class*="viewer"]').forEach((el) => {
const cs = getComputedStyle(el);
if (cs.position !== "fixed" || cs.display === "none" || cs.visibility === "hidden" || Number(cs.opacity) < 0.05) return;
const r = el.getBoundingClientRect();
if (min > 0 && r.width * r.height >= min) out.push(el);
});
return out;
};
const FIELD = "input:not([type=file]):not([type=password]):not([type=hidden]):not([type=button]):not([type=submit]),textarea,select";
const sig = (el) => el.tagName + ":" + (el.type || "") + ":" + (el.className || "");
const readFields = (ov) => Array.prototype.map.call(ov.querySelectorAll(FIELD), (el) => [sig(el), el.type === "checkbox" || el.type === "radio" ? !!el.checked : el.value]);
function writeFields(ov, saved) {
if (!ov || !Array.isArray(saved)) return;
const els = ov.querySelectorAll(FIELD);
const touched = [];
saved.forEach((f, i) => {
const el = els[i];
if (!el || sig(el) !== f[0]) return;
if (el.type === "checkbox" || el.type === "radio") { if (el.checked !== !!f[1]) { el.checked = !!f[1]; touched.push([el, "change"]); } }
else if (el.value !== f[1]) { el.value = f[1]; touched.push([el, el.tagName === "SELECT" ? "change" : "input"]); }
});
touched.forEach((t) => { try { t[0].dispatchEvent(new Event(t[1], { bubbles: true })); } catch (e) {} });
}
const resumeKey = (host) => "familyHubResume:" + keyOf(host);
function track(host) {
const table = OPENERS[host.tagName];
if (!table || host.__fhTracked) return;
host.__fhTracked = true;
host.__fhCalls = [];
Object.keys(table).forEach((name) => {
if (name === "__view") return;
const orig = host[name];
if (typeof orig !== "function") return;
const spec = table[name];
const fn = spec.alias || name;
const fspec = table[fn] || spec;
host[name] = function () {
const args = Array.prototype.slice.call(arguments);
const outer = !host.__fhInOpener;
// (pop-ups opened again after a reload are watched too, so leaving again keeps them)
if (outer) {
const before = openOverlays(host);
if (!before.length && !fspec.follows) host.__fhCalls = [];
let saved = args;
if (fspec.save) { const w = fspec.save(host, args[0]); saved = w ? [{ __w: w }].concat(args.slice(1)) : (fspec.optional ? [] : null); }
if (saved) {
const call = { fn, args: saved, ov: null, edit: name === "_openEventInfoForEdit" };
host.__fhCalls.push(call);
// some open after loading something, so look a few times
[0, 300, 1200].forEach((ms) => setTimeout(() => { if (!call.ov) call.ov = openOverlays(host).find((o) => before.indexOf(o) < 0) || null; }, ms));
}
}
host.__fhInOpener = true;
try { return orig.apply(this, arguments); } finally { if (outer) host.__fhInOpener = false; }
};
});
}
function snapshot(host) {
const calls = host.__fhCalls || [];
const open = openOverlays(host);
// where the card was (the calendar's week, say), pop-up or not
let view = null;
try { view = typeof host._fhViewState === "function" ? host._fhViewState() : null; } catch (e) { view = null; }
if ((!open.length || !calls.length) && !view) { try { localStorage.removeItem(resumeKey(host)); } catch (e) {} return; }
let parentOpen = false;
const keep = [];
(open.length ? calls : []).forEach((c) => {
const isOpen = c.ov ? open.indexOf(c.ov) >= 0 : parentOpen;
if (c.ov) parentOpen = isOpen;
if (isOpen) keep.push({ fn: c.fn, args: c.args, edit: c.edit, fields: c.ov ? readFields(c.ov) : null });
});
try {
if (keep.length || view) localStorage.setItem(resumeKey(host), JSON.stringify({ at: Date.now(), calls: keep, view }));
else localStorage.removeItem(resumeKey(host));
} catch (e) {}
}
const waitFor = (test, ms) => new Promise((resolve) => {
const end = Date.now() + ms;
const tick = () => { let v = null; try { v = test(); } catch (e) { v = null; } if (v) resolve(v); else if (Date.now() > end) resolve(null); else setTimeout(tick, 200); };
tick();
});
async function resume(host) {
let saved = null;
try { saved = JSON.parse(localStorage.getItem(resumeKey(host)) || "null"); localStorage.removeItem(resumeKey(host)); } catch (e) { saved = null; }
if (!saved || !Array.isArray(saved.calls) || Date.now() - (saved.at || 0) > RESUME_MS) return;
const table = OPENERS[host.tagName] || {};
host.__fhReplaying = true;
try {
if (saved.view && typeof host._fhRestoreViewState === "function") {
const vready = (table.__view || {}).ready;
if (await waitFor(() => host._hass && (!vready || vready(host)), 10000)) {
try { host._fhRestoreViewState(saved.view); } catch (e) {}
}
}
for (const c of saved.calls) {
const spec = table[c.fn] || {};
if (!host.isConnected) return;
if (!(await waitFor(() => host._hass && (!spec.ready || spec.ready(host)), 10000))) return;
let args = c.args || [];
if (args[0] && args[0].__w && spec.find) {
const found = await waitFor(() => spec.find(host, args[0].__w), 10000);
if (!found) return;
args = [found].concat(args.slice(1));
}
const before = openOverlays(host);
const name = c.edit && typeof host._openEventInfoForEdit === "function" ? "_openEventInfoForEdit" : c.fn;
try { await host[name].apply(host, args); } catch (e) { return; }
if (c.fields) {
const ov = await waitFor(() => openOverlays(host).find((o) => before.indexOf(o) < 0), 3000);
await new Promise((r) => setTimeout(r, 150));
writeFields(ov, c.fields);
}
}
} finally {
host.__fhReplaying = false;
}
}
const snapAll = () => live.forEach((host) => { try { snapshot(host); } catch (e) {} });
document.addEventListener("visibilitychange", () => {
if (document.visibilityState === "hidden") { snapAll(); return; }
// back without a reload or a rebuild: what was saved isn't needed (a card loading later shouldn't jump back to it)
setTimeout(() => {
if (document.visibilityState !== "visible") return;
live.forEach((host) => { try { localStorage.removeItem(resumeKey(host)); } catch (e) {} });
}, WINDOW_MS);
});
window.addEventListener("pagehide", snapAll);
const _connected = connected;
connected = function (host) {
_connected(host);
track(host);
if (!host.__fhResumeChecked) {
host.__fhResumeChecked = true;
setTimeout(() => { if (host.isConnected && !host.__fhAdopted) resume(host); }, 300);
}
};
window.__familyHubKeepAlive = { connected: (h) => connected(h), disconnected, modalOpen, parked, snapshot, resume, track };
})();
// FH-EINK END
// FH-MODAL-SCROLL START - source: tools/modal_scroll_guard.js, copied into each card by tools/sync_modal_scroll_guard.py
// 2026.11.1.13: the page behind a card's open popup doesn't scroll. Home Assistant's dashboard layout can make a card's
// "fixed" popups move with the card instead of staying on screen, so scrolling under one carried the popup (and its
// buttons) away. While a popup (.modal-overlay.open) is open the page is locked, and anything that still scrolls it -
// a phone ignoring the lock, a dashboard scrolling its own container - is put straight back.
(function () {
if (window.__familyHubModalScroll) return;
if (!window.__familyCalendarSetScrollLock) {
const holders = new Set();
const render = () => {
let styleEl = document.getElementById("family-calendar-scroll-lock-style");
if (!styleEl) {
styleEl = document.createElement("style");
styleEl.id = "family-calendar-scroll-lock-style";
document.head.appendChild(styleEl);
}
styleEl.textContent = holders.size
? `html, body { overflow: hidden !important; height: 100% !important; height: 100dvh !important; overscroll-behavior: none; }`
: "";
};
window.__familyCalendarSetScrollLock = (holder, locked) => {
if (locked) holders.add(holder);
else holders.delete(holder);
render();
};
window.__familyCalendarApplyScrollLock = (locked) => window.__familyCalendarSetScrollLock(window, !!locked);
}
const watched = new Map();
const composedParent = (n) => {
const pn = n.parentNode;
return pn && pn.nodeType === 11 && pn.host ? pn.host : n.parentElement || null;
};
function sync(host) {
const st = watched.get(host);
if (!st) return;
st.queued = false;
const root = host.shadowRoot;
const open = host.isConnected && !!(root && root.querySelector(".modal-overlay.open"));
window.__familyCalendarSetScrollLock(st.key, open);
if (open && !st.guard) {
const spots = [];
for (let n = composedParent(host); n; n = composedParent(n)) {
if (n.nodeType === 1 && (n.scrollHeight > n.clientHeight + 1 || n.scrollTop)) spots.push([n, n.scrollTop]);
}
const winY = window.scrollY || 0;
st.guard = () => {
if ((window.scrollY || 0) !== winY) window.scrollTo(window.scrollX || 0, winY);
for (const [el, top] of spots) if (el.scrollTop !== top) el.scrollTop = top;
};
window.addEventListener("scroll", st.guard, { capture: true, passive: true });
} else if (!open && st.guard) {
window.removeEventListener("scroll", st.guard, { capture: true });
st.guard = null;
}
}
function attach(host, tries) {
const st = watched.get(host);
if (!st || st.obs) return;
const root = host.shadowRoot;
if (!root) {
if (tries < 120) st.timer = setTimeout(() => attach(host, tries + 1), 250);
return;
}
st.obs = new MutationObserver(() => {
if (st.queued) return;
st.queued = true;
Promise.resolve().then(() => sync(host));
});
st.obs.observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ["class"] });
sync(host);
}
window.__familyHubModalScroll = {
watch(host) {
if (watched.has(host)) return;
watched.set(host, { key: { modalOf: host }, obs: null, guard: null, timer: null, queued: false });
attach(host, 0);
},
unwatch(host) {
const st = watched.get(host);
if (!st) return;
if (st.obs) st.obs.disconnect();
clearTimeout(st.timer);
if (st.guard) window.removeEventListener("scroll", st.guard, { capture: true });
window.__familyCalendarSetScrollLock(st.key, false);
watched.delete(host);
},
};
})();
// FH-MODAL-SCROLL END
// Holiday themes, shared by every Family Hub card: a holiday background can switch the theme
// while it's showing. The backend works out the dates (family_hub/holiday_themes/get); this
// checks today against them, refreshes every 30 minutes, and tells cards to re-theme when the
// answer changes (including at midnight).
if (!window.__fhHolidayTheme) {
  window.__fhHolidayTheme = (function () {
    let schedule = null;
    let fetchedAt = 0;
    let loading = null;
    let midnightTimer = null;
    let lastId = null;
    const listeners = new Set();
    const todayKey = () => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    };
    const span = (s) => (Date.parse(s.end) - Date.parse(s.start)) || 0;
    function current() {
      if (!Array.isArray(schedule)) return "";
      const k = todayKey();
      // the most specific wins: a day beats a week, a week beats a month (same rule as the backgrounds)
      const hits = schedule.filter((s) => s && s.theme_id && s.start <= k && k <= s.end).sort((a, b) => span(a) - span(b));
      return hits.length ? hits[0].theme_id : "";
    }
    function notify() {
      const id = current();
      if (id === lastId) return;
      lastId = id;
      listeners.forEach((cb) => {
        try {
          cb();
        } catch (e) {
          // one card's error never stops the others
        }
      });
    }
    function armMidnight() {
      clearTimeout(midnightTimer);
      const now = new Date();
      const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 5);
      midnightTimer = setTimeout(() => {
        notify();
        armMidnight();
      }, next.getTime() - now.getTime());
    }
    function refresh(hass) {
      if (!hass || !hass.connection) return Promise.resolve();
      if (loading) return loading;
      loading = hass.connection
        .sendMessagePromise({ type: "family_hub/holiday_themes/get" })
        .then((r) => {
          schedule = (r && Array.isArray(r.schedule) && r.schedule) || [];
        })
        .catch(() => {
          schedule = schedule || [];
        })
        .then(() => {
          fetchedAt = Date.now();
          loading = null;
          armMidnight();
          notify();
        });
      return loading;
    }
    return {
      themeId(hass) {
        if (hass && !loading && Date.now() - fetchedAt > 30 * 60 * 1000) refresh(hass);
        return current();
      },
      subscribe(cb) {
        listeners.add(cb);
        return () => listeners.delete(cb);
      },
      invalidate(hass) {
        fetchedAt = 0;
        return refresh(hass);
      },
    };
  })();
}
// Family Hub Recipe Box card - "Create a card for the menu box in case people want to see it as its own tab of the dashboard

// ------------------------------------------------------------------------ Recipe Box ("Loved Dishes") shared logic
var __fhI18n = (window.__familyHubI18n = window.__familyHubI18n || { hass: null, fb: {}, loading: null, loaded: null });
var __fhEsc = function (s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
};
var __fhT = function (key, fb, vars, mode) {
  var g = window.__familyHubI18n || __fhI18n;
  if (g.fb[key] === undefined) g.fb[key] = fb;
  var str = "";
  try {
    if (g.hass && typeof g.hass.localize === "function") str = g.hass.localize("component.family_hub.fh_ui." + key) || "";
  } catch (e) {
    str = "";
  }
  if (!str) str = fb;
  if (mode === "h") str = __fhEsc(str);
  if (vars) {
    Object.keys(vars).forEach(function (k) {
      var v = vars[k];
      str = str.split("%" + k + "%").join(v === null || v === undefined ? "" : String(v));
    });
  }
  return str;
};
var __fhUseHass = function (hass) {
  if (hass && typeof hass.localize === "function") (window.__familyHubI18n || __fhI18n).hass = hass;
};
var __fhSweep = function (root) {
  if (!root || typeof root.querySelectorAll !== "function") return;
  var g = window.__familyHubI18n || __fhI18n;
  root.querySelectorAll("[data-fh-t]").forEach(function (el) {
    var key = el.getAttribute("data-fh-t");
    var fb = g.fb[key];
    if (fb === undefined) return;
    var cur = (el.textContent || "").trim();
    if (cur !== fb && cur !== el.__fhShown) return;
    var next = __fhT(key, fb);
    if (cur !== next) el.textContent = next;
    el.__fhShown = next;
  });
  [["data-fh-title", "title"], ["data-fh-placeholder", "placeholder"], ["data-fh-aria", "aria-label"], ["data-fh-alt", "alt"]].forEach(function (pair) {
    root.querySelectorAll("[" + pair[0] + "]").forEach(function (el) {
      var key = el.getAttribute(pair[0]);
      var fb = g.fb[key];
      if (fb === undefined) return;
      var cur = el.getAttribute(pair[1]);
      var shownKey = "__fhShown_" + pair[1];
      if (cur !== fb && cur !== el[shownKey]) return;
      var next = __fhT(key, fb);
      if (cur !== next) el.setAttribute(pair[1], next);
      el[shownKey] = next;
    });
  });
};
// -------------------------------------------------------------------------

if (!window.__familyHubRecipeBoxShared) {
window.__familyHubRecipeBoxShared = {
_genId() {
return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
},
_parseDishDescription(raw) {
if (!raw) return { description: "", link: "", rating: null, color: null, block: 0, recur: null, grocyRecipeId: null, servings: null, category: "", image: "", additionalRecipes: [], leftoverDates: [] };
try {
const parsed = JSON.parse(raw);
return {
description: parsed.description || "",
link: parsed.link || "",
rating: parsed.rating || null,
color: parsed.color || null,
// Recipe Box-only fields (see _upsertDish) - harmlessly blank on every other kind of item this same parser also handles (a planned meal
category: parsed.category || "",
image: parsed.image || "",
block: typeof parsed.block === "number" ? parsed.block : 0,
recur: parsed.recur || null,
// Set only for suggestions added via "Add from Grocy" - lets the suggestions list open the in-card Recipe Viewer
grocyRecipeId: parsed.grocyRecipeId || null,
// How many people this specific planned meal is meant to feed - only meaningful alongside grocyRecipeId.
servings: typeof parsed.servings === "number" ? parsed.servings : null,
// leftovers - how many EXTRA days (beyond the day it's actually entered on) this same meal should keep showing for, same block
spanDays: typeof parsed.spanDays === "number" && parsed.spanDays > 1 ? parsed.spanDays : 1,
leftoverDates: Array.isArray(parsed.leftoverDates) ? parsed.leftoverDates.filter((d) => typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d)) : [],
additionalRecipes: Array.isArray(parsed.additionalRecipes)
? parsed.additionalRecipes
.filter((r) => r && typeof r.name === "string" && r.name.trim())
.map((r) => ({ name: r.name, link: r.link || "", grocyRecipeId: r.grocyRecipeId || null }))
: [],
};
} catch (e) {
return { description: raw, link: "", rating: null, color: null, block: 0, recur: null, grocyRecipeId: null, servings: null, category: "", image: "", spanDays: 1, additionalRecipes: [], leftoverDates: [] };
}
},
async _getItems(entityId) {
const result = await this._hass.connection.sendMessagePromise({
type: "call_service",
domain: "todo",
service: "get_items",
service_data: { status: ["needs_action", "completed"] },
target: { entity_id: entityId },
return_response: true,
});
return (result && result.response && result.response[entityId] && result.response[entityId].items) || [];
},
_normalizeForDuplicateCheck(name) {
return (name || "")
.toString()
.normalize("NFKD")
.replace(/[̀-ͯ]/g, "")
.toLowerCase()
.replace(/[^a-z0-9]+/g, " ")
.trim()
.replace(/\s+/g, " ");
},
_levenshteinDistance(a, b) {
if (a === b) return 0;
if (!a.length) return b.length;
if (!b.length) return a.length;
let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
for (let i = 1; i <= a.length; i++) {
const cur = [i];
for (let j = 1; j <= b.length; j++) {
cur[j] =
a[i - 1] === b[j - 1]
? prev[j - 1]
: 1 + Math.min(prev[j - 1], prev[j], cur[j - 1]);
}
prev = cur;
}
return prev[b.length];
},
_findFuzzyDuplicate(name, list, getName) {
const norm = this._normalizeForDuplicateCheck(name);
if (!norm) return null;
let best = null;
let bestDistance = Infinity;
for (const item of list || []) {
const otherNorm = this._normalizeForDuplicateCheck(getName(item));
if (!otherNorm) continue;
const distance = otherNorm === norm ? 0 : this._levenshteinDistance(norm, otherNorm);
const threshold = otherNorm === norm ? 0 : Math.max(1, Math.round(Math.max(norm.length, otherNorm.length) * 0.2));
if (distance <= threshold && distance < bestDistance) {
best = item;
bestDistance = distance;
}
}
return best;
},
async _fetchRecipes() {
if (!this._hass) return;
try {
const result = await this._hass.connection.sendMessagePromise({ type: "family_hub/get_recipes" });
if (!result.migrated) {
const items = this._config.recipe_entity ? await this._getItems(this._config.recipe_entity) : [];
this._recipes = items.map((it) => {
const parsed = this._parseDishDescription(it.description);
return {
uid: it.uid,
name: it.summary,
description: parsed.description,
link: parsed.link,
rating: parsed.rating,
grocyRecipeId: parsed.grocyRecipeId,
category: parsed.category,
image: parsed.image,
};
});
await this._persistRecipes();
} else {
this._recipes = result.recipes || [];
}
} catch (e) {
// 2026.11.1.10: a failed load keeps what's already showing - an empty list here could be saved back over the whole Recipe Box
if (!Array.isArray(this._recipes)) this._recipes = [];
}
this._renderLoved();
this._renderGrid();
},
async _persistRecipes() {
if (!this._hass) return;
try {
// removed_grocy_ids: Grocy recipes deleted here on purpose, so the backend doesn't keep them as "just synced" (see _ws_set_recipes)
await this._hass.connection.sendMessagePromise({ type: "family_hub/set_recipes", recipes: this._recipes, removed_grocy_ids: Array.from(this._removedGrocyIds || []) });
} catch (e) {
}
},
async _fetchSuggestions() {
if (!this._hass) return;
try {
const result = await this._hass.connection.sendMessagePromise({ type: "family_hub/get_suggestions" });
if (!result.migrated) {
const items = this._config.suggestions_entity ? await this._getItems(this._config.suggestions_entity) : [];
this._suggestions = items.map((it) => {
const parsed = this._parseDishDescription(it.description);
return { uid: it.uid, name: it.summary, description: parsed.description, link: parsed.link, grocyRecipeId: parsed.grocyRecipeId };
});
await this._persistSuggestions();
} else {
this._suggestions = result.suggestions || [];
}
} catch (e) {
this._suggestions = [];
}
// No standalone Suggestions modal to re-render into anymore - "viewing suggestions" is just the Recipe Box's own "💡 Suggested" filter now
},
async _persistSuggestions() {
if (!this._hass) return;
try {
await this._hass.connection.sendMessagePromise({ type: "family_hub/set_suggestions", suggestions: this._suggestions });
} catch (e) {
}
},
async _addSuggestion(name, description, link, grocyRecipeId) {
if (!name) return;
const dupe = this._findFuzzyDuplicate(name, this._suggestions, (s) => s.name);
if (dupe) {
const isExact = this._normalizeForDuplicateCheck(dupe.name) === this._normalizeForDuplicateCheck(name);
if (isExact) return;
if (!window.confirm(this._t("recipe_box.confirm_dupe_suggestion", `"${dupe.name}" is already suggested and looks very similar. Add "${name}" as a separate suggestion anyway?`, { dupe: dupe.name, name }))) {
return;
}
}
this._suggestions.push({ uid: this._genId(), name, description: description || "", link: link || "", grocyRecipeId: grocyRecipeId || null });
await this._persistSuggestions();
},
async _removeSuggestion(uid) {
if (!uid) return;
this._suggestions = this._suggestions.filter((s) => s.uid !== uid);
await this._persistSuggestions();
},
_isAdmin() {
return !!(this._hass && this._hass.user && this._hass.user.is_admin);
},
_myUserId() {
return this._hass && this._hass.user ? this._hass.user.id : null;
},
_hasPermission(key) {
// Admin first, so this answers correctly on the very first paint, before _fetchMyPermissions has resolved
if (this._isAdmin()) return true;
return !!(this._myPermissions && this._myPermissions[key]);
},
_canEditMenu() {
return this._hasPermission("can_edit_menu");
},
async _fetchMyPermissions() {
if (!this._hass) return;
try {
const result = await this._hass.connection.sendMessagePromise({ type: "family_hub/permissions/get_mine" });
this._myPermissions = (result && result.permissions) || {};
} catch (e) {
// An older backend (or a transient failure) means "no extra grants" -
// never "everything allowed". An admin still passes via _isAdmin().
this._myPermissions = {};
}
},
async _upsertDish(name, description, link, rating, uidOverride, grocyRecipeId, category, image, checkDuplicates, steps) {
if (!name) return;
const existing = uidOverride
? this._recipes.find((r) => r.uid === uidOverride)
: this._recipes.find((r) => r.name.toLowerCase() === name.toLowerCase());
// Only worth asking about when this is about to become a genuinely new Recipe Box entry - an exact-name match above already merges in place
if (!existing && checkDuplicates) {
const dupe = this._findFuzzyDuplicate(name, this._recipes, (r) => r.name);
if (dupe && !window.confirm(this._t("recipe_box.confirm_dupe_recipe", `"${dupe.name}" is already in your Recipe Box and looks very similar. Add "${name}" as a separate recipe anyway?`, { dupe: dupe.name, name }))) {
return;
}
}
// category/image are Recipe Box-only fields that not every caller knows about - the day/menu editor's "also save this as a loved dish" path
const finalCategory = category !== undefined ? category : (existing ? existing.category || "" : "");
const finalImage = image !== undefined ? image : (existing ? existing.image || "" : "");
// steps is a local (non-Grocy) recipe's own ordered step- block array (see _fhOpenStepEditor)
const finalSteps = steps !== undefined ? steps : (existing ? existing.steps || [] : []);
const record = {
uid: existing ? existing.uid : this._genId(),
name,
description: description || "",
link: link || "",
rating: rating || null,
grocyRecipeId: grocyRecipeId || null,
category: finalCategory,
image: finalImage,
steps: finalSteps,
};
if (existing) {
this._recipes[this._recipes.indexOf(existing)] = record;
} else {
this._recipes.push(record);
}
await this._persistRecipes();
this._renderLoved();
this._renderGrid();
},
async _deleteDish(uid, grocyRecipeId) {
if (!uid) return;
if (grocyRecipeId) {
try {
await this._hass.connection.sendMessagePromise({
type: "family_hub/delete_grocy_recipe",
recipe_id: grocyRecipeId,
});
} catch (e) {
}
}
if (grocyRecipeId) (this._removedGrocyIds = this._removedGrocyIds || new Set()).add(grocyRecipeId);
this._recipes = this._recipes.filter((r) => r.uid !== uid);
await this._persistRecipes();
this._renderLoved();
this._renderGrid();
},
async _suggestDish(recipe) {
const name = (recipe.name || "").trim().toLowerCase();
const existing = (this._suggestions || []).find((s) => (s.name || "").trim().toLowerCase() === name);
if (existing) {
await this._removeSuggestion(existing.uid);
} else {
await this._addSuggestion(recipe.name, recipe.description, recipe.link, recipe.grocyRecipeId);
}
// _addSuggestion/_removeSuggestion (Store-backed - see _fetchSuggestions) update this._suggestions in memory before persisting
this._renderLoved();
},
_openLoved(pickerMode) {
// pickerMode is now also allowed to be the string "additional" (the day/menu editor's "+ From Recipe Box" additional-recipe button
this._pickerMode = pickerMode === "additional" ? "additional" : !!pickerMode;
this._lovedSearchTerm = "";
this._recipeBoxCategory = "All";
this._recipeBoxSort = "default";
this._recipeBoxSelectMode = false;
this._recipeBoxSelectedUids.clear();
this._root.querySelector(".loved-search").value = "";
this._root.querySelector(".recipe-sort-select").value = "default";
this._fetchRecipes();
// Picker mode (opened from the day/menu editor's single "Pick a Recipe" button
this._root.querySelector(".loved-title").textContent =
this._pickerMode === "additional"
? this._t("recipe_box.title_add_additional", "\u{1F37D}\u{FE0F} Add Additional Recipe")
: this._pickerMode
? this._t("recipe_box.title_pick_recipe", "\u{1F37D}\u{FE0F} Pick a Recipe")
: this._t("recipe_box.title_recipe_box", "\u{1F37D}\u{FE0F} Recipe Box");
this._root.querySelector(".loved-hint").style.display = this._pickerMode ? "block" : "none";
this._root.querySelector(".recipe-box-select-btn").style.display = this._pickerMode ? "none" : "";
this._openModal(this._root.querySelector(".loved-overlay"));
},
_closeLoved() {
this._root.querySelector(".loved-overlay").classList.remove("open");
},
_openSuggestedRecipes() {
this._openLoved(false);
this._recipeBoxCategory = "💡 Suggested";
this._renderLoved();
},
_renderLoved() {
if (!this._root) return;
const list = this._root.querySelector(".loved-list");
const viewMode = this._getRecipeBoxViewMode();
list.classList.toggle("recipe-grid", viewMode !== "list");
list.classList.toggle("recipe-list", viewMode === "list");
this._updateRecipeBoxViewButtons();
this._renderRecipeBoxCategoryChips();
this._updateRecipeBoxSelectBar();
// Fire-and-forget: fills in photos for Grocy-imported dishes that don't have one yet
this._hydrateGrocyRecipeImages();
let recipes = this._recipes.slice();
// Matches a Recipe Box entry to a Meal Suggestions entry by name (case-insensitive) since the two aren't otherwise linked records
const suggestedNameSet = new Set((this._suggestions || []).map((s) => (s.name || "").trim().toLowerCase()));
const term = (this._lovedSearchTerm || "").trim().toLowerCase();
if (term) {
recipes = recipes.filter(
(r) =>
(r.name || "").toLowerCase().includes(term) ||
(r.description || "").toLowerCase().includes(term) ||
(r.category || "").toLowerCase().includes(term)
);
}
const activeCategory = this._recipeBoxCategory || "All";
if (activeCategory === "❤️ Loved") {
recipes = recipes.filter((r) => r.rating === "up");
} else if (activeCategory === "💡 Suggested") {
recipes = recipes.filter((r) => suggestedNameSet.has((r.name || "").trim().toLowerCase()));
} else if (activeCategory !== "All") {
recipes = recipes.filter((r) => (r.category || "Uncategorized") === activeCategory);
}
recipes = this._sortRecipeBoxList(recipes);
if (!recipes.length) {
list.innerHTML = `<div class="loved-empty">${
term || activeCategory !== "All"
? this._t("recipe_box.empty_no_match", "No recipes match this search/filter.")
: this._t("recipe_box.empty_recipe_box", "Your Recipe Box is empty - tap “+ Add Recipe” or “\u{1F517} Import from a link” above to get started.")
}</div>`;
return;
}
const isListView = viewMode === "list";
const selectMode = this._recipeBoxSelectMode && !this._pickerMode;
list.innerHTML = recipes
.map((r, idx) => {
const isLoved = r.rating === "up";
const isSuggested = suggestedNameSet.has((r.name || "").trim().toLowerCase());
const isSelected = selectMode && this._recipeBoxSelectedUids.has(r.uid);
const initial = (r.name || "?").trim().charAt(0).toUpperCase();
if (isListView) {
const media = r.image
? `<div class="recipe-row-media" style="background-image:url('${String(r.image).replace(/'/g, "%27")}')"></div>`
: `<div class="recipe-row-media recipe-row-media-placeholder"><span>${initial}</span></div>`;
const category = r.category ? `<span class="recipe-row-category">${r.category}</span>` : "";
const trailing = selectMode
? `<div class="recipe-row-select-badge">${isSelected ? "&#10003;" : ""}</div>`
: `<div class="recipe-row-actions">
<button type="button" class="recipe-row-heart ${isLoved ? "is-loved" : ""}" data-idx="${idx}" title="${isLoved ? this._t("recipe_box.remove_from_loved", "Remove from loved") : this._t("recipe_box.love_this_dish", "Love this dish")}">${isLoved ? "&#10084;&#65039;" : "&#129293;"}</button>
<button type="button" class="recipe-row-suggest ${isSuggested ? "is-suggested" : ""}" data-idx="${idx}" title="${isSuggested ? this._t("recipe_box.remove_from_suggestions", "Remove from Suggestions") : this._t("recipe_box.suggest_for_meal", "Suggest this for a meal")}">&#128161;</button>
</div>`;
return `<div class="recipe-row ${isSelected ? "is-selected" : ""}" data-idx="${idx}">
${media}
<div class="recipe-row-body">
<div class="recipe-row-name">${r.name}</div>
${category}
</div>
${trailing}
</div>`;
}
const media = r.image
? `<div class="recipe-card-media" style="background-image:url('${String(r.image).replace(/'/g, "%27")}')"></div>`
: `<div class="recipe-card-media recipe-card-media-placeholder"><span>${initial}</span></div>`;
const category = r.category ? `<span class="recipe-card-category">${r.category}</span>` : "";
const overlay = selectMode
? `<div class="recipe-card-select-badge">${isSelected ? "&#10003;" : ""}</div>`
: `<button type="button" class="recipe-card-heart ${isLoved ? "is-loved" : ""}" data-idx="${idx}" title="${isLoved ? this._t("recipe_box.remove_from_loved", "Remove from loved") : this._t("recipe_box.love_this_dish", "Love this dish")}">${isLoved ? "&#10084;&#65039;" : "&#129293;"}</button>
<button type="button" class="recipe-card-suggest ${isSuggested ? "is-suggested" : ""}" data-idx="${idx}" title="${isSuggested ? this._t("recipe_box.remove_from_suggestions", "Remove from Suggestions") : this._t("recipe_box.suggest_for_meal", "Suggest this for a meal")}">&#128161;</button>`;
return `<div class="recipe-card ${isSelected ? "is-selected" : ""}" data-idx="${idx}">
${media}
${overlay}
<div class="recipe-card-body">
<div class="recipe-card-name">${r.name}</div>
${category}
</div>
</div>`;
})
.join("");
const cardSelector = isListView ? ".recipe-row" : ".recipe-card";
list.querySelectorAll(cardSelector).forEach((el) => {
el.addEventListener("click", () => {
const idx = parseInt(el.dataset.idx, 10);
const recipe = recipes[idx];
if (selectMode) {
this._toggleRecipeBoxSelected(recipe.uid);
} else if (this._pickerMode === "additional") {
this._addAdditionalRecipeFromLoved(recipe);
} else if (this._pickerMode) {
this._selectLovedDish(recipe);
} else if (recipe.grocyRecipeId) {
// Root cause: browsing the Recipe Box always opened the small `.dish-detail-overlay` "menu" first
this._openGrocyRecipeViewer(recipe.grocyRecipeId, recipe.name, recipe.link, false, null, recipe);
} else {
this._openDishDetail(recipe);
}
});
});
if (!selectMode) {
const heartSelector = isListView ? ".recipe-row-heart" : ".recipe-card-heart";
const suggestSelector = isListView ? ".recipe-row-suggest" : ".recipe-card-suggest";
list.querySelectorAll(heartSelector).forEach((el) => {
el.addEventListener("click", (e) => {
e.stopPropagation();
const idx = parseInt(el.dataset.idx, 10);
this._toggleDishLoved(recipes[idx]);
});
});
list.querySelectorAll(suggestSelector).forEach((el) => {
el.addEventListener("click", (e) => {
e.stopPropagation();
const idx = parseInt(el.dataset.idx, 10);
this._suggestDish(recipes[idx]);
});
});
}
},
_sortRecipeBoxList(recipes) {
const mode = this._recipeBoxSort || "default";
if (mode === "name") {
return recipes.slice().sort((a, b) => (a.name || "").localeCompare(b.name || ""));
}
if (mode === "suggested") {
const suggestedNames = new Set((this._suggestions || []).map((s) => (s.name || "").trim().toLowerCase()));
return recipes
.map((r, i) => ({ r, i, suggested: suggestedNames.has((r.name || "").trim().toLowerCase()) }))
.sort((a, b) => {
if (a.suggested !== b.suggested) return a.suggested ? -1 : 1;
return a.i - b.i;
})
.map((x) => x.r);
}
return recipes;
},
_getRecipeBoxViewMode() {
return window.localStorage.getItem("familyHubRecipeBoxView") === "list" ? "list" : "grid";
},
_setRecipeBoxViewMode(mode) {
window.localStorage.setItem("familyHubRecipeBoxView", mode === "list" ? "list" : "grid");
this._renderLoved();
},
_updateRecipeBoxViewButtons() {
const root = this._root;
if (!root) return;
const mode = this._getRecipeBoxViewMode();
root.querySelectorAll(".recipe-view-btn").forEach((btn) => {
btn.classList.toggle("active", btn.dataset.view === mode);
});
},
_toggleRecipeBoxSelectMode(active) {
this._recipeBoxSelectMode = !!active;
if (!this._recipeBoxSelectMode) this._recipeBoxSelectedUids.clear();
this._renderLoved();
},
_toggleRecipeBoxSelected(uid) {
if (this._recipeBoxSelectedUids.has(uid)) {
this._recipeBoxSelectedUids.delete(uid);
} else {
this._recipeBoxSelectedUids.add(uid);
}
this._renderLoved();
},
_updateRecipeBoxSelectBar() {
const root = this._root;
if (!root) return;
const active = this._recipeBoxSelectMode && !this._pickerMode;
const bar = root.querySelector(".recipe-box-select-bar");
const actions = root.querySelector(".recipe-box-actions");
if (bar) bar.style.display = active ? "flex" : "none";
if (actions) actions.style.display = active ? "none" : "";
const countEl = root.querySelector(".recipe-box-select-count");
if (countEl) {
const n = this._recipeBoxSelectedUids.size;
countEl.textContent = this._t("recipe_box.n_selected", `${n} selected`, { n: String(n) });
}
},
async _deleteSelectedRecipeBoxItems() {
const uids = Array.from(this._recipeBoxSelectedUids);
if (!uids.length) return;
const recipesToDelete = uids.map((uid) => this._recipes.find((r) => r.uid === uid)).filter(Boolean);
if (!recipesToDelete.length) return;
const hasGrocy = recipesToDelete.some((r) => r.grocyRecipeId);
const label = recipesToDelete.length === 1 ? `"${recipesToDelete[0].name}"` : this._t("recipe_box.these_n_recipes", `these ${recipesToDelete.length} recipes`, { n: String(recipesToDelete.length) });
const grocyNote = hasGrocy ? this._t("recipe_box.note_delete_grocy_linked", " This will also delete the linked recipe(s) from Grocy.") : "";
if (!window.confirm(this._t("recipe_box.confirm_delete_items", "Delete %label% from the Recipe Box?%note%", { label, note: grocyNote }))) return;
for (const recipe of recipesToDelete) {
await this._deleteDish(recipe.uid, recipe.grocyRecipeId);
}
this._recipeBoxSelectMode = false;
this._recipeBoxSelectedUids.clear();
this._renderLoved();
},
async _hydrateGrocyRecipeImages() {
if (!this._hass) return;
// _fetchRecipes() replaces this._recipes wholesale from the Store on every load, reconnect, AND the 60s poll (see _refreshAllData)
let reapplied = false;
(this._recipes || []).forEach((r) => {
if (r.grocyRecipeId && !r.image && this._grocyImageCache[r.grocyRecipeId]) {
r.image = this._grocyImageCache[r.grocyRecipeId];
reapplied = true;
}
});
const targets = (this._recipes || []).filter(
(r) =>
r.grocyRecipeId &&
!r.image &&
!(r.grocyRecipeId in this._grocyImageCache) &&
!this._grocyImageFetching.has(r.grocyRecipeId)
);
if (!targets.length) {
if (
reapplied &&
this._root &&
this._root.querySelector(".loved-overlay") &&
this._root.querySelector(".loved-overlay").classList.contains("open") &&
!this._pickerMode
) {
this._renderLoved();
}
return;
}
targets.forEach((r) => this._grocyImageFetching.add(r.grocyRecipeId));
const results = await Promise.all(
targets.map(async (r) => {
let image = null;
try {
const result = await this._hass.connection.sendMessagePromise({
type: "family_hub/get_grocy_recipe_detail",
recipe_id: r.grocyRecipeId,
});
image = (result && result.recipe && result.recipe.image) || null;
} catch (e) {
image = null;
} finally {
this._grocyImageFetching.delete(r.grocyRecipeId);
}
return { id: r.grocyRecipeId, image };
})
);
let changed = false;
results.forEach(({ id, image }) => {
this._grocyImageCache[id] = image;
if (image) changed = true;
});
if (!changed && !reapplied) return;
(this._recipes || []).forEach((r) => {
if (r.grocyRecipeId && !r.image && this._grocyImageCache[r.grocyRecipeId]) {
r.image = this._grocyImageCache[r.grocyRecipeId];
}
});
// Guard against re-entering the picker's plain list or a since-closed modal
if (
this._root &&
this._root.querySelector(".loved-overlay") &&
this._root.querySelector(".loved-overlay").classList.contains("open") &&
!this._pickerMode
) {
this._renderLoved();
}
},
_toggleDishLoved(recipe) {
const newRating = recipe.rating === "up" ? null : "up";
this._upsertDish(recipe.name, recipe.description, recipe.link, newRating, recipe.uid, recipe.grocyRecipeId);
},
_renderRecipeBoxCategoryChips() {
const root = this._root;
if (!root) return;
const container = root.querySelector(".recipe-box-categories");
if (!container) return;
const categories = Array.from(
new Set((this._recipes || []).map((r) => (r.category || "").trim()).filter(Boolean))
).sort((a, b) => a.localeCompare(b));
const chips = ["All", "❤️ Loved", "💡 Suggested", ...categories];
if (!this._recipeBoxCategory || !chips.includes(this._recipeBoxCategory)) {
this._recipeBoxCategory = "All";
}
container.innerHTML = chips
.map((c) => {
const label =
c === "All" ? this._t("recipe_box.chip_all", "All")
: c === "❤️ Loved" ? this._t("recipe_box.chip_loved", "❤️ Loved")
: c === "💡 Suggested" ? this._t("recipe_box.chip_suggested", "💡 Suggested")
: c;
return `<button type="button" class="recipe-chip ${c === this._recipeBoxCategory ? "active" : ""}" data-category="${c.replace(/"/g, "&quot;")}">${label}</button>`;
})
.join("");
container.querySelectorAll(".recipe-chip").forEach((el) => {
el.addEventListener("click", () => {
this._recipeBoxCategory = el.dataset.category;
this._renderLoved();
});
});
},
_openDishDetail(recipe) {
const root = this._root;
this._dishDetailRecipe = recipe;
root.querySelector(".dish-detail-title").textContent = recipe.name || "(untitled)";
const photo = root.querySelector(".dish-detail-photo");
if (photo) {
if (recipe.image) {
photo.src = recipe.image;
photo.style.display = "block";
} else {
photo.src = "";
photo.style.display = "none";
}
}
const ratingHtml =
(recipe.rating === "up"
? `<span data-fh-t="text.loved" class="event-info-chip" style="background:#f2ddd4">${__fhT("text.loved", "❤️ Loved", null, "h")}</span>`
: recipe.rating === "down"
? `<span data-fh-t="text.not_a_fan" class="event-info-chip" style="background:#d8e3e0">${__fhT("text.not_a_fan", "👎 Not a fan", null, "h")}</span>`
: "") + (recipe.category ? `<span class="event-info-chip">${recipe.category}</span>` : "");
root.querySelector(".dish-detail-rating").innerHTML = ratingHtml;
root.querySelector(".dish-detail-desc").textContent = recipe.description || __fhT("text.no_notes_added", "No notes added.");
const stepsEl = root.querySelector(".dish-detail-steps");
if (stepsEl) {
this._dishDetailCheckedSteps = new Set();
stepsEl.innerHTML = this._fhRenderStepBlocksHtml(recipe.steps || [], this._dishDetailCheckedSteps);
stepsEl.querySelectorAll(".grocy-recipe-instruction-row").forEach((row) => {
row.querySelector(".grocy-recipe-instruction-check").addEventListener("change", () => {
const idx = Number(row.dataset.idx);
if (row.querySelector(".grocy-recipe-instruction-check").checked) this._dishDetailCheckedSteps.add(idx);
else this._dishDetailCheckedSteps.delete(idx);
row.classList.toggle("checked-off", row.querySelector(".grocy-recipe-instruction-check").checked);
});
});
}
const suggestBtn = root.querySelector(".dish-detail-suggest-btn");
if (suggestBtn) {
suggestBtn.textContent = __fhT("text.suggest_this", "💡 Suggest this");
suggestBtn.onclick = () => {
this._suggestDish(recipe);
suggestBtn.textContent = __fhT("text.added_to_suggestions", "✅ Added to Suggestions");
setTimeout(() => {
suggestBtn.textContent = __fhT("text.suggest_this", "💡 Suggest this");
}, 1600);
};
}
const linkRow = root.querySelector(".dish-detail-link-row");
if (recipe.link) {
const label = recipe.grocyRecipeId ? __fhT("text.n128279_view_recipe", "&#128279; View recipe") : __fhT("text.n128279_open_recipe_link", "&#128279; Open recipe link");
linkRow.innerHTML = `<button type="button" class="pick-loved-btn dish-detail-open-link">${label}</button>`;
linkRow.querySelector(".dish-detail-open-link").addEventListener("click", () => {
if (recipe.grocyRecipeId) {
this._openGrocyRecipeViewer(recipe.grocyRecipeId, recipe.name, recipe.link);
} else {
window.open(recipe.link, "_blank", "noopener");
}
});
} else {
linkRow.innerHTML = "";
}
this._openModal(root.querySelector(".dish-detail-overlay"));
// Re-evaluate the screensaver idle timer now that a recipe detail view is open - when "Disable while a recipe is open" is on
this._resetScreenSaverIdleTimer();
},
_closeDishDetail() {
this._root.querySelector(".dish-detail-overlay").classList.remove("open");
// Mirror of the open-side call above: closing the recipe detail view means _screenSaverApplicable can be true again
this._resetScreenSaverIdleTimer();
},
_populateDishCategoryOptions() {
const root = this._root;
if (!root) return;
const datalist = root.querySelector("#dish-category-options");
if (!datalist) return;
const categories = Array.from(
new Set((this._recipes || []).map((r) => (r.category || "").trim()).filter(Boolean))
).sort((a, b) => a.localeCompare(b));
datalist.innerHTML = categories.map((c) => `<option value="${c.replace(/"/g, "&quot;")}"></option>`).join("");
},
// new recipe step-block editor (household request: "add an editor that allows you to add pictures at any step and edited recipe.
_fhEscapeHtml(s) {
return String(s == null ? "" : s)
.replace(/&/g, "&amp;")
.replace(/</g, "&lt;")
.replace(/>/g, "&gt;");
},
_fhParsePreparationBlocks(inner) {
const blocks = [];
const re = /<h4>([\s\S]*?)<\/h4>|<hr\s*\/?>|<p>([\s\S]*?)<\/p>/gi;
let m;
while ((m = re.exec(inner || ""))) {
if (m[1] !== undefined) {
const text = m[1].trim();
if (text) blocks.push({ type: "header", text });
} else if (/^<hr/i.test(m[0])) {
blocks.push({ type: "divider" });
} else if (m[2] !== undefined) {
const content = m[2].trim();
const imgMatch = content.match(/^<img[^>]*\bsrc=["']([^"']+)["'][^>]*>$/i);
if (imgMatch) {
blocks.push({ type: "image", url: imgMatch[1] });
} else if (content) {
blocks.push({ type: "step", text: content });
}
}
}
return blocks;
},
_fhBlocksToPreparationHtml(blocks) {
return (blocks || [])
.map((b) => {
if (b.type === "header") return `<h4>${b.text || ""}</h4>`;
if (b.type === "divider") return "<hr>";
if (b.type === "image") return `<p><img src="${(b.url || "").replace(/"/g, "&quot;")}"></p>`;
return `<p>${b.text || ""}</p>`;
})
.join("");
},
_fhRenderStepBlocksHtml(blocks, checkedSteps) {
if (!blocks || !blocks.length) return "";
checkedSteps = checkedSteps || new Set();
let stepNum = 0;
const rows = blocks.map((b, idx) => {
if (b.type === "header") {
return `<div class="grocy-recipe-step-header">${b.text || ""}</div>`;
}
if (b.type === "divider") {
return `<hr class="grocy-recipe-step-divider" />`;
}
if (b.type === "image") {
return `<div class="grocy-recipe-step-image-wrap"><img class="grocy-recipe-step-image" src="${b.url || ""}" /></div>`;
}
stepNum++;
const checked = checkedSteps.has(idx) ? " checked-off" : "";
return `<label class="grocy-recipe-instruction-row${checked}" data-idx="${idx}"><input type="checkbox" class="grocy-recipe-instruction-check"${checked ? " checked" : ""} /><span class="grocy-recipe-instruction-badge">${stepNum}</span><span class="grocy-recipe-instruction-text">${b.text || ""}</span></label>`;
});
return `<div data-fh-t="text.instructions" class="grocy-recipe-instructions-title">${__fhT("text.instructions", "Instructions", null, "h")}</div>` + rows.join("");
},
async _fhBlobToUploadFromFile(file) {
let blob = file;
let name = (file && file.name) || "photo.jpg";
try {
const rawDataUrl = await new Promise((resolve, reject) => {
const reader = new FileReader();
reader.onload = () => resolve(reader.result);
reader.onerror = () => reject(reader.error || new Error("Couldn't read that file."));
reader.readAsDataURL(file);
});
const img = await new Promise((resolve, reject) => {
const el = new Image();
el.onload = () => resolve(el);
el.onerror = () => reject(new Error("Couldn't decode that image."));
el.src = rawDataUrl;
setTimeout(() => reject(new Error("timed out decoding image")), 1500);
});
const maxDim = 1600;
const width = img.width || maxDim;
const height = img.height || maxDim;
const scale = Math.min(1, maxDim / Math.max(width, height));
const canvas = document.createElement("canvas");
canvas.width = Math.max(1, Math.round(width * scale));
canvas.height = Math.max(1, Math.round(height * scale));
const ctx = canvas.getContext && canvas.getContext("2d");
if (ctx) {
ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
const reEncoded = await new Promise((resolve) => {
if (typeof canvas.toBlob === "function") {
canvas.toBlob((b) => resolve(b), "image/jpeg", 0.85);
} else {
resolve(null);
}
});
if (reEncoded) {
blob = reEncoded;
name = "photo.jpg";
}
}
} catch (e) {
// Best-effort only - falls through to uploading the original file.
}
return { blob, name };
},
async _fhFetchWithAuth(path, opts) {
if (this._hass && typeof this._hass.fetchWithAuth === "function") {
return this._hass.fetchWithAuth(path, opts);
}
const token = this._hass && this._hass.auth && this._hass.auth.data && this._hass.auth.data.access_token;
const headers = Object.assign({}, opts && opts.headers, token ? { authorization: `Bearer ${token}` } : {});
return fetch(path, Object.assign({}, opts, { headers }));
},
async _fhUploadImage(file) {
if (!file) return null;
const { blob, name } = await this._fhBlobToUploadFromFile(file);
const formData = new FormData();
formData.append("file", blob, name);
const response = await this._fhFetchWithAuth("/api/image/upload", { method: "POST", body: formData });
if (!response || !response.ok) {
throw new Error(`image upload failed (${response && response.status})`);
}
const result = await response.json();
if (!result || !result.id) throw new Error("image upload response had no id");
return `/api/image/serve/${result.id}/original`;
},
_fhOpenStepEditor(blocks, onSave, onCancel) {
const root = this._root;
if (!root) return;
this._fhStepEditorBlocks = (blocks || []).map((b) => Object.assign({}, b));
this._fhStepEditorOnSave = onSave;
this._fhStepEditorOnCancel = onCancel;
this._renderFhStepEditorList();
this._openModal(this._fhStepEditorOverlay());
},
_closeFhStepEditor() {
const root = this._root;
if (!root) return;
this._closeModal(this._fhStepEditorOverlay());
},
_fhMoveStepBlock(idx, dir) {
const blocks = this._fhStepEditorBlocks;
if (!blocks) return;
const newIdx = idx + dir;
if (newIdx < 0 || newIdx >= blocks.length) return;
const [item] = blocks.splice(idx, 1);
blocks.splice(newIdx, 0, item);
this._renderFhStepEditorList();
},
_renderFhStepEditorList() {
const root = this._root;
if (!root) return;
const listEl = this._fhStepEditorOverlay().querySelector(".fh-step-editor-list");
if (!listEl) return;
const blocks = this._fhStepEditorBlocks || [];
if (!blocks.length) {
listEl.innerHTML = `<div data-fh-t="text.no_steps_yet_use_the_buttons_below_to" class="loved-empty">${__fhT("text.no_steps_yet_use_the_buttons_below_to", "No steps yet - use the buttons below to add some.", null, "h")}</div>`;
return;
}
const dragHandle = `<span data-fh-title="text.drag_to_reorder" class="fh-step-editor-drag-handle" title="${__fhT("text.drag_to_reorder", "Drag to reorder", null, "h")}">&#9776;</span>`;
listEl.innerHTML = blocks
.map((b, idx) => {
const controls =
`<div class="fh-step-editor-row-controls">` +
`<button type="button" class="fh-step-editor-up-btn" data-idx="${idx}"${idx === 0 ? " disabled" : ""}>&#8593;</button>` +
`<button type="button" class="fh-step-editor-down-btn" data-idx="${idx}"${idx === blocks.length - 1 ? " disabled" : ""}>&#8595;</button>` +
`<button type="button" class="fh-step-editor-del-btn" data-idx="${idx}">&#128465;&#65039;</button>` +
`</div>`;
if (b.type === "header") {
return (
`<div class="fh-step-editor-row fh-step-editor-header-row" data-idx="${idx}">` +
dragHandle +
`<input data-fh-placeholder="text.section_header" type="text" class="fh-step-editor-header-input" data-idx="${idx}" value="${this._fhEscapeHtml(b.text || "")}" placeholder="${__fhT("text.section_header", "Section header", null, "h")}" />` +
controls +
`</div>`
);
}
if (b.type === "divider") {
return `<div class="fh-step-editor-row fh-step-editor-divider-row" data-idx="${idx}">${dragHandle}<span class="fh-step-editor-divider-label">&mdash; divider &mdash;</span>${controls}</div>`;
}
if (b.type === "image") {
return `<div class="fh-step-editor-row fh-step-editor-image-row" data-idx="${idx}">${dragHandle}<img class="fh-step-editor-image-preview" src="${b.url || ""}" />${controls}</div>`;
}
return (
`<div class="fh-step-editor-row fh-step-editor-step-row" data-idx="${idx}">` +
dragHandle +
`<span class="fh-step-editor-step-num">${idx + 1}</span>` +
`<textarea data-fh-placeholder="text.step_text" class="fh-step-editor-text-input" data-idx="${idx}" placeholder="${__fhT("text.step_text", "Step text", null, "h")}">${b.text || ""}</textarea>` +
controls +
`</div>`
);
})
.join("");
this._fhStepEditorAttachDrag(listEl);
listEl.querySelectorAll(".fh-step-editor-text-input, .fh-step-editor-header-input").forEach((el) => {
el.addEventListener("input", () => {
const idx = Number(el.dataset.idx);
if (this._fhStepEditorBlocks[idx]) this._fhStepEditorBlocks[idx].text = el.value;
});
});
listEl.querySelectorAll(".fh-step-editor-up-btn").forEach((btn) => {
btn.addEventListener("click", () => this._fhMoveStepBlock(Number(btn.dataset.idx), -1));
});
listEl.querySelectorAll(".fh-step-editor-down-btn").forEach((btn) => {
btn.addEventListener("click", () => this._fhMoveStepBlock(Number(btn.dataset.idx), 1));
});
listEl.querySelectorAll(".fh-step-editor-del-btn").forEach((btn) => {
btn.addEventListener("click", () => {
const idx = Number(btn.dataset.idx);
this._fhStepEditorBlocks.splice(idx, 1);
this._renderFhStepEditorList();
});
});
},
_fhStepEditorAttachDrag(listEl) {
const blocks = this._fhStepEditorBlocks || [];
const rows = Array.from(listEl.querySelectorAll(".fh-step-editor-row"));
rows.forEach((row, i) => {
row.__fhBlock = blocks[i];
const handle = row.querySelector(".fh-step-editor-drag-handle");
if (!handle) return;
handle.addEventListener("pointerdown", (e) => {
e.preventDefault();
const draggedRow = row;
draggedRow.classList.add("fh-step-editor-dragging");
let captured = false;
try {
handle.setPointerCapture(e.pointerId);
captured = true;
} catch (err) {}
const onMove = (ev) => {
const target = document.elementFromPoint(ev.clientX, ev.clientY);
const overRow = target && target.closest && target.closest(".fh-step-editor-row");
if (!overRow || overRow === draggedRow || overRow.parentElement !== listEl) return;
const rect = overRow.getBoundingClientRect();
const before = ev.clientY < rect.top + rect.height / 2;
listEl.insertBefore(draggedRow, before ? overRow : overRow.nextSibling);
};
const onUp = (ev) => {
draggedRow.classList.remove("fh-step-editor-dragging");
handle.removeEventListener("pointermove", onMove);
handle.removeEventListener("pointerup", onUp);
handle.removeEventListener("pointercancel", onUp);
if (captured) {
try {
handle.releasePointerCapture(ev.pointerId);
} catch (err) {}
}
this._fhStepEditorBlocks = Array.from(listEl.querySelectorAll(".fh-step-editor-row")).map((r) => r.__fhBlock);
this._renderFhStepEditorList();
};
handle.addEventListener("pointermove", onMove);
handle.addEventListener("pointerup", onUp);
handle.addEventListener("pointercancel", onUp);
});
});
},
// the full in-card Grocy Recipe Viewer, moved here from being a FamilyWeekCalendarCard-only set of methods so this card can open the exact
_grocyViewerOverlay() {
if (!this._grocyRecipeViewerOverlayEl) {
const root = this._root;
this._grocyRecipeViewerOverlayEl = root && root.querySelector(".grocy-recipe-viewer-overlay");
}
const overlay = this._grocyRecipeViewerOverlayEl;
if (overlay && !this._grocyRecipeViewerPortalEl) {
const portal = document.createElement("div");
portal.className = "fh-grocy-viewer-portal";
if (typeof this._css === "function") {
const style = document.createElement("style");
style.textContent = this._css().split(":host").join(".fh-grocy-viewer-portal");
portal.appendChild(style);
}
portal.appendChild(overlay);
document.body.appendChild(portal);
this._grocyRecipeViewerPortalEl = portal;
}
if (this._grocyRecipeViewerPortalEl && typeof getComputedStyle === "function") {
const live = getComputedStyle(this);
[
"--fc-bg", "--fc-card", "--fc-card-menu", "--fc-border", "--fc-text", "--fc-text-secondary",
"--fc-accent", "--fc-accent-text", "--fc-accent2", "--fc-accent3",
"--fc-surface-alt", "--fc-surface2", "--fc-glass-blur", "--fh-header-offset",
].forEach((name) => {
const value = live.getPropertyValue(name);
if (value && value.trim()) this._grocyRecipeViewerPortalEl.style.setProperty(name, value.trim());
});
}
return overlay;
},
_fhStepEditorOverlay() {
if (!this._fhStepEditorOverlayEl) {
const root = this._root;
this._fhStepEditorOverlayEl = root && root.querySelector(".fh-step-editor-overlay");
}
const overlay = this._fhStepEditorOverlayEl;
if (overlay && !this._fhStepEditorPortalEl) {
const portal = document.createElement("div");
portal.className = "fh-step-editor-portal";
// See the matching comment in family-week-calendar-card.js - same portal mechanism as _grocyViewerOverlay
if (typeof this._css === "function") {
const style = document.createElement("style");
style.textContent = this._css().split(":host").join(".fh-step-editor-portal");
portal.appendChild(style);
}
portal.appendChild(overlay);
document.body.appendChild(portal);
this._fhStepEditorPortalEl = portal;
}
if (this._fhStepEditorPortalEl && typeof getComputedStyle === "function") {
const live = getComputedStyle(this);
[
"--fc-bg", "--fc-card", "--fc-card-menu", "--fc-border", "--fc-text", "--fc-text-secondary",
"--fc-accent", "--fc-accent-text", "--fc-accent2", "--fc-accent3",
"--fc-surface-alt", "--fc-surface2", "--fc-glass-blur", "--fh-header-offset",
].forEach((name) => {
const value = live.getPropertyValue(name);
if (value && value.trim()) this._fhStepEditorPortalEl.style.setProperty(name, value.trim());
});
}
return overlay;
},
_openGrocyRecipeViewer(recipeId, fallbackName, fallbackLink, isPreview, tabs, sourceRecipe) {
if (!recipeId) return;
this._grocyRecipeViewerRecipeId = recipeId;
this._grocyRecipeViewerFallbackLink = fallbackLink || "";
// the actual Recipe Box entry this viewer was opened FROM, if any - only ever passed by the Recipe Box's own primary browse click
this._grocyRecipeViewerSourceRecipe = sourceRecipe || null;
const overlay = this._grocyViewerOverlay();
// Preview mode (task #177's picker preview icon) opens the exact same viewer, but over a picker that's deliberately left open underneath
overlay.classList.toggle("preview-mode", !!isPreview);
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-back-btn").style.display = isPreview ? "block" : "none";
// v1.129.0+: same "block", not "" gotcha as the back button above -
// .grocy-recipe-viewer-recipe-actions defaults to display:none in CSS.
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-recipe-actions").style.display = this._grocyRecipeViewerSourceRecipe ? "flex" : "none";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-title").textContent = fallbackName || __fhT("text.recipe", "Recipe");
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-stats").innerHTML = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-servings").textContent = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-ingredients").innerHTML = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-instructions").innerHTML = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-description").innerHTML = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-scale-row").style.display = "none";
this._grocyRecipeViewerIngredients = [];
this._grocyRecipeViewerBaseServings = 1;
this._grocyRecipeViewerServings = 1;
this._grocyRecipeViewerRawDescription = "";
const photoEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-photo");
photoEl.style.display = "none";
photoEl.src = "";
// The full-screen modal-box scrolls its own content (overflow-y: auto); without this
this._grocyViewerOverlay().querySelector(".modal-box").scrollTop = 0;
// multi-recipe tabs - see this method's own doc note in the CSS above (.grocy-recipe-viewer-tabs) for the feature this serves.
const dedupedTabs = [];
const seenTabIds = new Set();
(tabs || []).forEach((t) => {
const tid = t && t.id != null ? String(t.id) : "";
if (tid && !seenTabIds.has(tid)) {
seenTabIds.add(tid);
dedupedTabs.push(t);
}
});
this._grocyRecipeViewerTabs = dedupedTabs.length > 1 ? dedupedTabs : null;
this._grocyRecipeViewerDetailsById = {};
this._grocyRecipeViewerTabErrors = {};
const tabsEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-tabs");
if (this._grocyRecipeViewerTabs) {
tabsEl.innerHTML = this._grocyRecipeViewerTabs
.map(
(t) =>
`<button type="button" class="grocy-recipe-viewer-tab-btn ${String(t.id) === String(recipeId) ? "active" : ""}" data-recipe-tab-id="${t.id}">${t.name || __fhT("text.recipe", "Recipe", null, "h")}</button>`
)
.join("");
tabsEl.style.display = "flex";
} else {
tabsEl.innerHTML = "";
tabsEl.style.display = "none";
}
this._openModal(this._grocyViewerOverlay());
if (this._grocyRecipeViewerTabs) {
this._fetchGrocyRecipeDetailsBatch(this._grocyRecipeViewerTabs.map((t) => t.id), recipeId);
} else {
this._fetchGrocyRecipeDetail(recipeId);
}
// Same screensaver idle-timer re-check as _openDishDetail - see its
// comment for why.
this._resetScreenSaverIdleTimer();
},
_closeGrocyRecipeViewer() {
this._grocyViewerOverlay().classList.remove("open");
// don't let a stale Recipe Box entry leak into the NEXT viewer open (a bare-recipe-id call site, e.g. a meal preview
this._grocyRecipeViewerSourceRecipe = null;
// Same screensaver idle-timer re-check as _closeDishDetail - see its
// comment for why.
this._resetScreenSaverIdleTimer();
},
async _consumeGrocyRecipeIngredients() {
const recipeId = this._grocyRecipeViewerRecipeId;
if (!recipeId || !this._hass) return;
if (!window.confirm(__fhT("text.deduct_this_recipe_s_ingredients_from", "Deduct this recipe's ingredients from your Grocy stock now? This can't be undone from here."))) {
return;
}
const statusEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-status");
statusEl.textContent = __fhT("text.consuming_ingredients_in_grocy", "Consuming ingredients in Grocy…");
statusEl.classList.remove("is-error");
try {
// Only sent when the viewer's own scaler has been moved off the recipe's base servings
const servings =
this._grocyRecipeViewerServings && this._grocyRecipeViewerServings !== this._grocyRecipeViewerBaseServings
? this._grocyRecipeViewerServings
: undefined;
const result = await this._hass.connection.sendMessagePromise({
type: "family_hub/consume_grocy_recipe",
recipe_id: recipeId,
...(servings ? { servings } : {}),
});
if (result.configured === false) {
statusEl.textContent = __fhT("text.grocy_isn_t_connected_set_it_up_under", "Grocy isn't connected — set it up under Settings > Devices & Services > Family Hub > Configure > Grocy.");
statusEl.classList.add("is-error");
return;
}
if (!result.success) {
statusEl.textContent = __fhT("text.couldn_t_consume_this_recipe_s", "Couldn't consume this recipe's ingredients: %0%", {0: result.error || "unknown error"});
statusEl.classList.add("is-error");
return;
}
statusEl.textContent = __fhT("text.ingredients_deducted_from_grocy_stock", "Ingredients deducted from Grocy stock.");
statusEl.classList.remove("is-error");
} catch (e) {
statusEl.textContent = __fhT("text.couldn_t_reach_grocy", "Couldn't reach Grocy.");
statusEl.classList.add("is-error");
}
},
async _fetchGrocyRecipeDetail(recipeId) {
if (!this._hass) return;
const statusEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-status");
statusEl.textContent = __fhT("text.loading_recipe_from_grocy", "Loading recipe from Grocy…");
statusEl.classList.remove("is-error");
try {
const result = await this._hass.connection.sendMessagePromise({
type: "family_hub/get_grocy_recipe_detail",
recipe_id: recipeId,
});
if (result.configured === false) {
statusEl.textContent = __fhT("text.grocy_isn_t_connected_set_it_up_under", "Grocy isn't connected — set it up under Settings > Devices & Services > Family Hub > Configure > Grocy.");
return;
}
if (result.error || !result.recipe) {
statusEl.textContent = __fhT("text.couldn_t_load_this_recipe_from_grocy_x", "Couldn't load this recipe from Grocy: %0%", {0: result.error || "not found"});
statusEl.classList.add("is-error");
return;
}
statusEl.textContent = "";
this._renderGrocyRecipeDetail(result.recipe);
} catch (e) {
statusEl.textContent = __fhT("text.couldn_t_reach_grocy", "Couldn't reach Grocy.");
statusEl.classList.add("is-error");
}
},
// batch counterpart to _fetchGrocyRecipeDetail above, for the multi-recipe tabs _openGrocyRecipeViewer sets up when it's passed more than one
async _fetchGrocyRecipeDetailsBatch(recipeIds, activeId) {
if (!this._hass) return;
const statusEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-status");
statusEl.textContent = __fhT("text.loading_recipes_from_grocy", "Loading recipes from Grocy…");
statusEl.classList.remove("is-error");
try {
const result = await this._hass.connection.sendMessagePromise({
type: "family_hub/get_grocy_recipe_details",
recipe_ids: recipeIds,
});
if (result.configured === false) {
statusEl.textContent = __fhT("text.grocy_isn_t_connected_set_it_up_under", "Grocy isn't connected — set it up under Settings > Devices & Services > Family Hub > Configure > Grocy.");
return;
}
this._grocyRecipeViewerDetailsById = result.recipes || {};
this._grocyRecipeViewerTabErrors = result.errors || {};
this._renderActiveGrocyRecipeViewerTab(activeId);
} catch (e) {
statusEl.textContent = __fhT("text.couldn_t_reach_grocy", "Couldn't reach Grocy.");
statusEl.classList.add("is-error");
}
},
// Shared by the batch fetch above (once all tabs' details have loaded) and _switchGrocyRecipeViewerTab
_renderActiveGrocyRecipeViewerTab(recipeId) {
const statusEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-status");
const detail = (this._grocyRecipeViewerDetailsById || {})[String(recipeId)];
if (detail) {
statusEl.textContent = "";
statusEl.classList.remove("is-error");
this._renderGrocyRecipeDetail(detail);
return;
}
const err = (this._grocyRecipeViewerTabErrors || {})[String(recipeId)];
const tabInfo = ((this._grocyRecipeViewerTabs || []).find((t) => String(t.id) === String(recipeId)) || {});
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-title").textContent = tabInfo.name || __fhT("text.recipe", "Recipe");
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-stats").innerHTML = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-servings").textContent = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-ingredients").innerHTML = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-instructions").innerHTML = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-description").innerHTML = "";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-scale-row").style.display = "none";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-photo").style.display = "none";
statusEl.textContent = __fhT("text.couldn_t_load_this_recipe_from_grocy_x", "Couldn't load this recipe from Grocy: %0%", {0: err || "not found"});
statusEl.classList.add("is-error");
},
// Tab-row click handler (delegated, see the connectedCallback wiring on .grocy-recipe-viewer-tabs)
_switchGrocyRecipeViewerTab(recipeId) {
if (!this._grocyRecipeViewerTabs) return;
this._grocyViewerOverlay().querySelectorAll(".grocy-recipe-viewer-tab-btn").forEach((btn) => {
btn.classList.toggle("active", String(btn.dataset.recipeTabId) === String(recipeId));
});
this._grocyRecipeViewerRecipeId = recipeId;
this._renderActiveGrocyRecipeViewerTab(recipeId);
this._grocyViewerOverlay().querySelector(".modal-box").scrollTop = 0;
},
_renderGrocyRecipeDetail(recipe) {
const photoEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-photo");
if (recipe.image) {
photoEl.src = recipe.image;
// NOT "" - .grocy-recipe-viewer-photo's own CSS rule sets `display: none` as its base/default
photoEl.style.display = "block";
} else {
photoEl.style.display = "none";
photoEl.src = "";
}
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-title").textContent = recipe.name || __fhT("text.recipe", "Recipe");
// Prep/Cook/Total stat pills (task #250/mockup) - only the ones this recipe actually has real data for
const statsEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-stats");
const statDefs = [
["Prep", recipe.prep_time],
["Cook", recipe.cook_time],
["Total", recipe.total_time],
].filter(([, value]) => (value || "").trim());
statsEl.innerHTML = statDefs
.map(([label, value]) => `<div class="grocy-recipe-stat"><span class="grocy-recipe-stat-label">${label}</span><span class="grocy-recipe-stat-value">${value}</span></div>`)
.join("");
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-servings").textContent = recipe.servings
? __fhT("text.makes_x_serving_x", "Makes %0% serving%1%", {0: recipe.servings, 1: recipe.servings === 1 ? "" : "s"})
: "";
// The picker only ever had the list-page link; once the detail call resolves we have the authoritative one from the recipe object itself
this._grocyRecipeViewerFallbackLink = recipe.link || this._grocyRecipeViewerFallbackLink || "";

const ingredients = Array.isArray(recipe.ingredients) ? recipe.ingredients : [];
this._grocyRecipeViewerIngredients = ingredients;
// Checking off an ingredient or a step is scoped to one viewing of one recipe - re-opening the same recipe (or switching tabs to another one
this._grocyRecipeViewerCheckedIngredients = new Set();
this._grocyRecipeViewerCheckedSteps = new Set();
// The scaler (task #173) works off the recipe's own base_servings
const baseServings = Number(recipe.base_servings) > 0 ? Number(recipe.base_servings) : (Number(recipe.servings) > 0 ? Number(recipe.servings) : 1);
this._grocyRecipeViewerBaseServings = baseServings;
this._grocyRecipeViewerServings = Number(recipe.servings) > 0 ? Number(recipe.servings) : baseServings;
const scaleRow = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-scale-row");
const canScale = ingredients.some((ing) => typeof ing.amount_value === "number");
scaleRow.style.display = canScale ? "flex" : "none";
this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-scale-value").textContent = String(this._grocyRecipeViewerServings);
this._renderGrocyRecipeIngredients();

// The description/instructions HTML can itself embed a plain-text ingredients list
this._grocyRecipeViewerRawDescription = recipe.description || "";
this._renderGrocyRecipeDescription();
},
// Recomputes the description/instructions block against the current servings ratio - mirrors _renderGrocyRecipeIngredients
_renderGrocyRecipeDescription() {
if (!this._root) return;
const descEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-description");
const instructionsEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-instructions");
if (!descEl) return;
const raw = this._grocyRecipeViewerRawDescription || "";
if (!raw) {
if (instructionsEl) instructionsEl.innerHTML = "";
descEl.innerHTML = `<div data-fh-t="text.no_instructions_added_in_grocy" class="loved-empty">${__fhT("text.no_instructions_added_in_grocy", "No instructions added in Grocy.", null, "h")}</div>`;
this._grocyRecipeViewerStepBlocks = [];
return;
}
const baseServings = this._grocyRecipeViewerBaseServings || 1;
const servings = this._grocyRecipeViewerServings || baseServings;
const ratio = baseServings > 0 ? servings / baseServings : 1;
let html = this._scaleIngredientsDescriptionHtml(raw, ratio);

// Recipes imported via this card's own "Import a recipe from a link" flow (_createImportedGrocyRecipe
const stepsMatch = html.match(/<p><strong(?:>Preparation| data-fh-t="text\.preparation">[^<]*)<\/strong><\/p>([\s\S]*?)(?=<p><strong>|$)/i);
const blocks = stepsMatch ? this._fhParsePreparationBlocks(stepsMatch[1]) : [];
this._grocyRecipeViewerStepBlocks = blocks;

if (instructionsEl) {
instructionsEl.innerHTML = this._fhRenderStepBlocksHtml(blocks, this._grocyRecipeViewerCheckedSteps);
instructionsEl.querySelectorAll(".grocy-recipe-instruction-row").forEach((row) => {
row.querySelector(".grocy-recipe-instruction-check").addEventListener("change", () => {
const idx = Number(row.dataset.idx);
if (!this._grocyRecipeViewerCheckedSteps) this._grocyRecipeViewerCheckedSteps = new Set();
if (row.querySelector(".grocy-recipe-instruction-check").checked) this._grocyRecipeViewerCheckedSteps.add(idx);
else this._grocyRecipeViewerCheckedSteps.delete(idx);
row.classList.toggle("checked-off", row.querySelector(".grocy-recipe-instruction-check").checked);
});
});
}

// Once a block has its own dedicated element above (structured ingredients list, numbered Instructions)
// 2026.11.1.10: the list can have sections - an <h4> heading before each section's own list, or a heading line
// inside the list itself ("<li><strong>Sauce</strong></li>", "<li>For the sauce:</li>") - shown as section headings
const ingredientsBlockMatch = (() => {
const m = html.match(/<p><strong(?:>Ingredients| data-fh-t="text\.ingredients">[^<]*)<\/strong><\/p>((?:\s*(?:<h[1-6][^>]*>[\s\S]*?<\/h[1-6]>|<p>\s*<(?:strong|b|em)>[^<]*<\/(?:strong|b|em)>\s*:?\s*<\/p>)?\s*<ul>[\s\S]*?<\/ul>)+)/i);
if (!m) return null;
const isHead = (inner) => {
const text = inner.replace(/<[^>]+>/g, "").trim();
if (!text || text.length > 60 || /\d/.test(text)) return null;
const bold = /^\s*<(strong|b)>[\s\S]*<\/\1>\s*:?\s*$/i.test(inner);
if (bold || /:$/.test(text) || (/[A-Z]{3}/.test(text) && text === text.toUpperCase()) || /^for (the )?\S/i.test(text)) {
return text.replace(/:$/, "").replace(/^for (the )?/i, "").trim() || null;
}
return null;
};
const cap = (t) => t.charAt(0).toUpperCase() + t.slice(1);
let out = "";
const re = /<h[1-6][^>]*>([\s\S]*?)<\/h[1-6]>|<p>\s*<(?:strong|b|em)>([^<]*)<\/(?:strong|b|em)>\s*:?\s*<\/p>|<ul>([\s\S]*?)<\/ul>/gi;
let t;
while ((t = re.exec(m[1]))) {
const head = t[1] !== undefined ? t[1] : t[2];
if (head !== undefined) {
const name = head.replace(/<[^>]+>/g, "").replace(/:\s*$/, "").replace(/^for (the )?/i, "").trim();
if (name) out += `<div class="grocy-recipe-ingredient-group">${cap(name)}</div>`;
continue;
}
let items = "";
t[3].replace(/<li>([\s\S]*?)<\/li>/gi, (full, inner) => {
const name = isHead(inner);
if (name) {
if (items) { out += `<ul>${items}</ul>`; items = ""; }
out += `<div class="grocy-recipe-ingredient-group">${cap(name)}</div>`;
} else {
items += full;
}
return full;
});
if (items) out += `<ul>${items}</ul>`;
}
return [m[0], out];
})();
if (ingredientsBlockMatch) {
const accordionHtml =
`<div class="grocy-recipe-ingredients-accordion">` +
`<button type="button" class="accordion-toggle recipe-viewer-ingredients-toggle" data-target="recipe-viewer-ingredients-body">` +
`<span data-fh-t="text.written_out_ingredients_list" class="theme-section-label">${__fhT("text.written_out_ingredients_list", "Written-out ingredients list", null, "h")}</span>` +
`<span class="accordion-chevron">&#9660;</span>` +
`</button>` +
`<div class="accordion-body" id="recipe-viewer-ingredients-body">${ingredientsBlockMatch[1]}</div>` +
`</div>`;
html = html.replace(ingredientsBlockMatch[0], accordionHtml);
}
if (stepsMatch) {
html = html.replace(stepsMatch[0], "");
}
// The Prep/Cook line is now always shown as its own stat pills whenever it exists at all (see _renderGrocyRecipeDetail)
html = html.replace(/<p>[\s\S]*?<strong>(?:Prep|Cook):<\/strong>[\s\S]*?<\/p>/i, "");
html = html.trim();
descEl.innerHTML = html || `<div data-fh-t="text.no_additional_notes" class="loved-empty">${__fhT("text.no_additional_notes", "No additional notes.", null, "h")}</div>`;
const ingredientsToggle = descEl.querySelector(".recipe-viewer-ingredients-toggle");
if (ingredientsToggle) {
ingredientsToggle.addEventListener("click", () => {
const body = descEl.querySelector(`#${ingredientsToggle.dataset.target}`);
ingredientsToggle.classList.toggle("open");
if (body) body.classList.toggle("open");
});
}
},
// Save step for the "Edit Steps" button (see _fhOpenStepEditor)
async _saveGrocyRecipeStepEdits(recipeId, blocks, reopenName, reopenLink, reopenSourceRecipe) {
if (!this._hass || !recipeId) return;
// the "Edit Steps" button closes the (possibly document.body -portal'd) Grocy Recipe Viewer before opening this plain shadow-root step editor
const reopenViewer = () => {
this._openGrocyRecipeViewer(recipeId, reopenName, reopenLink, false, null, reopenSourceRecipe);
};
let detailResult;
try {
detailResult = await this._hass.connection.sendMessagePromise({ type: "family_hub/get_grocy_recipe_detail", recipe_id: recipeId });
} catch (e) {
window.alert(__fhT("text.couldn_t_reach_the_backend_steps_weren", "Couldn't reach the backend - steps weren't saved."));
reopenViewer();
return;
}
if (detailResult.configured === false || !detailResult.recipe) {
window.alert(detailResult.error || __fhT("text.couldn_t_load_this_recipe_from_grocy", "Couldn't load this recipe from Grocy - steps weren't saved."));
reopenViewer();
return;
}
const detail = detailResult.recipe;
const rawDescription = detail.description || "";
const ingredients = (detail.ingredients || []).map((ing) => {
const amountText = ing.variable_amount || (typeof ing.amount_value === "number" ? String(ing.amount_value) : "");
const raw = (ing.note && ing.note.trim()) || `${amountText} ${ing.product || ""}`.trim() || ing.product || "";
return {
raw,
amount_text: amountText,
amount: typeof ing.amount_value === "number" && isFinite(ing.amount_value) ? ing.amount_value : null,
not_check_stock_fulfillment: !!ing.not_check_stock_fulfillment,
product_id: ing.product_id || null,
unit_id: ing.qu_id || null,
group: String(ing.group || ""),
};
});
const stepsMatch = rawDescription.match(/<p><strong(?:>Preparation| data-fh-t="text\.preparation">[^<]*)<\/strong><\/p>([\s\S]*?)(?=<p><strong>|$)/i);
const newPrepHtml = blocks.length ? `<p><strong>Preparation</strong></p>${this._fhBlocksToPreparationHtml(blocks)}` : "";
let newDescription;
if (stepsMatch) {
newDescription = rawDescription.slice(0, stepsMatch.index) + newPrepHtml + rawDescription.slice(stepsMatch.index + stepsMatch[0].length);
} else {
newDescription = rawDescription + newPrepHtml;
}
let result;
try {
result = await this._hass.connection.sendMessagePromise({
type: "family_hub/update_grocy_recipe",
recipe_id: recipeId,
name: detail.name || "",
description: newDescription,
servings: detail.base_servings || 1,
ingredients,
});
} catch (e) {
window.alert(__fhT("text.couldn_t_reach_the_backend_steps_weren", "Couldn't reach the backend - steps weren't saved."));
reopenViewer();
return;
}
if (result.configured === false || !result.success) {
window.alert((result && result.error) || __fhT("text.couldn_t_save_those_steps", "Couldn't save those steps."));
reopenViewer();
return;
}
reopenViewer();
},
// Finds the "Ingredients" <ul> block _createImportedGrocyRecipe writes into a recipe's description (raw scraped lines like "2 cups flour"
_scaleIngredientsDescriptionHtml(html, ratio) {
if (!html) return html;
// 2026.11.1.10: a recipe with sections has one list per section, each under its own <h4> heading - all of them scale
const blockRe = /(<p><strong(?:>Ingredients| data-fh-t="text\.ingredients">[^<]*)<\/strong><\/p>)((?:\s*(?:<h4>[\s\S]*?<\/h4>)?\s*<ul>[\s\S]*?<\/ul>)+)()/i;
const match = html.match(blockRe);
if (!match) return html;
const qtyRe = /^(\s*)(\d+\s+\d+\/\d+|\d+\/\d+|\d+(?:\.\d+)?[¼½¾⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞]?|[¼½¾⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞])(?=\s|$)/;
const scaledItems = match[2].replace(/<li>([\s\S]*?)<\/li>/gi, (full, inner) => {
const qm = inner.match(qtyRe);
if (!qm) return full;
const value = this._parseQuantityToken(qm[2]);
if (value === null || !isFinite(value)) return full;
const scaledText = this._formatScaledQuantityToken(value * ratio);
const rest = inner.slice(qm[0].length);
return `<li>${qm[1]}${scaledText}${rest}</li>`;
});
return html.slice(0, match.index) + match[1] + scaledItems + match[3] + html.slice(match.index + match[0].length);
},
_parseQuantityToken(token) {
token = (token || "").trim();
const FRACTION_MAP = {
"¼": 0.25, "½": 0.5, "¾": 0.75,
"⅓": 1 / 3, "⅔": 2 / 3,
"⅕": 0.2, "⅖": 0.4, "⅗": 0.6, "⅘": 0.8,
"⅙": 1 / 6, "⅚": 5 / 6,
"⅛": 0.125, "⅜": 0.375, "⅝": 0.625, "⅞": 0.875,
};
let m = token.match(/^(\d+)\s+(\d+)\/(\d+)$/);
if (m) return parseInt(m[1], 10) + parseInt(m[2], 10) / parseInt(m[3], 10);
m = token.match(/^(\d+)\/(\d+)$/);
if (m) return parseInt(m[1], 10) / parseInt(m[2], 10);
m = token.match(/^(\d+(?:\.\d+)?)?([¼½¾⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞])?$/);
if (m && (m[1] || m[2])) {
const whole = m[1] ? parseFloat(m[1]) : 0;
const frac = m[2] ? FRACTION_MAP[m[2]] : 0;
return whole + frac;
}
m = token.match(/^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)$/);
if (m) return parseFloat(m[2]);
return null;
},
// The inverse of _parseQuantityToken - renders a scaled decimal back as a recipe-friendly whole/fraction string
_formatScaledQuantityToken(value) {
const rounded = Math.round(value * 100) / 100;
const whole = Math.floor(rounded + 1e-6);
const frac = rounded - whole;
const FRACTIONS = [
[1 / 8, "1/8"], [1 / 6, "1/6"], [0.2, "1/5"], [0.25, "1/4"],
[1 / 3, "1/3"], [0.375, "3/8"], [0.4, "2/5"], [0.5, "1/2"],
[0.6, "3/5"], [0.625, "5/8"], [2 / 3, "2/3"], [0.75, "3/4"],
[0.8, "4/5"], [5 / 6, "5/6"], [0.875, "7/8"],
];
if (frac > 0.03) {
for (const [f, label] of FRACTIONS) {
if (Math.abs(frac - f) < 0.03) {
return whole > 0 ? `${whole} ${label}` : label;
}
}
}
return String(rounded);
},
// Recomputes just the ingredients list against this._grocyRecipeViewerServings/_grocyRecipeViewerBaseServings
_renderGrocyRecipeIngredients() {
if (!this._root) return;
const ingredientsEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-ingredients");
if (!ingredientsEl) return;
const ingredients = this._grocyRecipeViewerIngredients || [];
if (!ingredients.length) {
ingredientsEl.innerHTML = "";
return;
}
const baseServings = this._grocyRecipeViewerBaseServings || 1;
const servings = this._grocyRecipeViewerServings || baseServings;
const ratio = baseServings > 0 ? servings / baseServings : 1;
let lastGroup = null;
let numInGroup = 0;
ingredientsEl.innerHTML = ingredients
.map((ing, idx) => {
let groupHtml = "";
const group = ing.group || "";
if (group !== lastGroup) {
lastGroup = group;
// 2026.11.1.10: each section counts from 1 again, so "Sauce" reads 1, 2, 3 under its own heading
numInGroup = 0;
if (group) groupHtml = `<div class="grocy-recipe-ingredient-group">${group}</div>`;
}
numInGroup++;
const note = ing.note ? ` <span class="grocy-recipe-ingredient-note">(${ing.note})</span>` : "";
const amountText = this._formatScaledIngredientAmount(ing, ratio);
// Numbered circular badge (task #251/mockup) in place of the amount leading the row
const checked = this._grocyRecipeViewerCheckedIngredients && this._grocyRecipeViewerCheckedIngredients.has(idx) ? " checked-off" : "";
return `${groupHtml}<label class="grocy-recipe-ingredient-row${checked}" data-idx="${idx}"><input type="checkbox" class="grocy-recipe-ingredient-check"${checked ? " checked" : ""} /><span class="grocy-recipe-ingredient-badge">${numInGroup}</span><span><span class="grocy-recipe-ingredient-amount">${amountText}</span> ${ing.product || ""}${note}</span></label>`;
})
.join("");
ingredientsEl.querySelectorAll(".grocy-recipe-ingredient-row").forEach((row) => {
row.querySelector(".grocy-recipe-ingredient-check").addEventListener("change", () => {
const idx = Number(row.dataset.idx);
if (!this._grocyRecipeViewerCheckedIngredients) this._grocyRecipeViewerCheckedIngredients = new Set();
if (row.querySelector(".grocy-recipe-ingredient-check").checked) this._grocyRecipeViewerCheckedIngredients.add(idx);
else this._grocyRecipeViewerCheckedIngredients.delete(idx);
row.classList.toggle("checked-off", row.querySelector(".grocy-recipe-ingredient-check").checked);
});
});
},
// A free-text amount ("to taste") can't be scaled - passed through as-is.
_formatScaledIngredientAmount(ing, ratio) {
if (ing.variable_amount) return ing.variable_amount;
if (typeof ing.amount_value !== "number") return ing.amount || "";
const scaled = ing.amount_value * ratio;
const rounded = Math.round(scaled * 100) / 100;
const unit = (rounded === 1 ? (ing.unit_name || ing.unit_name_plural) : (ing.unit_name_plural || ing.unit_name)) || "";
return `${rounded} ${unit}`.trim();
},
_adjustGrocyRecipeViewerServings(delta) {
const next = Math.max(1, (this._grocyRecipeViewerServings || 1) + delta);
if (next === this._grocyRecipeViewerServings) return;
this._grocyRecipeViewerServings = next;
const valueEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-scale-value");
if (valueEl) valueEl.textContent = String(next);
this._renderGrocyRecipeIngredients();
this._renderGrocyRecipeDescription();
},
};
}

if (!window.__familyHubTimerAlarm) {
  // (timer + alarm overhaul): the on-screen half of a Family Hub timer alarm
  window.__familyHubTimerAlarm = (function () {
    let modalEl = null;
    let audioCtx = null;
    let beepHandle = null;
    const ringing = new Map(); // uid -> {title, body}
    const dismissedUids = new Set();
    let lastHass = null;
    function myClientId() {
      try {
        let id = sessionStorage.getItem("family_hub_client_id");
        if (!id) {
          id = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
          sessionStorage.setItem("family_hub_client_id", id);
        }
        return id;
      } catch (e) {
        return "";
      }
    }
    function ensureModal() {
      if (modalEl) return modalEl;
      modalEl = document.createElement("div");
      modalEl.id = "family-hub-timer-alarm-overlay";
      Object.assign(modalEl.style, {
        position: "fixed", inset: "0", zIndex: "2147483647", display: "none",
        alignItems: "center", justifyContent: "center",
        background: "rgba(20,16,8,0.78)",
      });
      modalEl.innerHTML =
        '<div class="fh-timer-alarm-box" role="alertdialog" aria-live="assertive" style="background:#fff8ea;color:#3a352c;border-radius:22px;padding:30px 26px;max-width:400px;width:88vw;max-height:86vh;overflow:auto;text-align:center;box-shadow:0 14px 46px rgba(0,0,0,0.45);font-family:-apple-system,\'Segoe UI\',Roboto,sans-serif;">' +
        '<div style="font-size:48px;margin-bottom:6px;">&#9200;</div>' +
        ('<div data-fh-t="text.time_s_up" class="fh-timer-alarm-head" style="font-size:14px;color:#96877a;margin-bottom:14px;font-weight:700;">' + __fhT("text.time_s_up", "Time's up!", null, "h") + '</div>') +
        '<div class="fh-timer-alarm-list" style="display:flex;flex-direction:column;gap:12px;"></div>' +
        ('<button data-fh-t="text.stop_all" type="button" class="fh-timer-alarm-stop-all" style="display:none;margin-top:16px;min-height:46px;width:100%;border:2px solid #8f5a00;border-radius:14px;background:transparent;color:#8f5a00;font-size:16px;font-weight:800;cursor:pointer;">' + __fhT("text.stop_all", "Stop all", null, "h") + '</button>') +
        "</div>";
      document.body.appendChild(modalEl);
      modalEl.addEventListener("click", (e) => {
        const btn = e.target.closest && e.target.closest("button");
        if (!btn) return;
        if (btn.classList.contains("fh-timer-alarm-stop-all")) {
          Array.from(ringing.keys()).forEach((uid) => stop(uid));
        } else if (btn.dataset.uid) {
          stop(btn.dataset.uid);
        }
      });
      return modalEl;
    }
    function render() {
      const el = ensureModal();
      if (!ringing.size) {
        el.style.display = "none";
        return;
      }
      const list = el.querySelector(".fh-timer-alarm-list");
      list.innerHTML = "";
      ringing.forEach((info, uid) => {
        const row = document.createElement("div");
        const title = document.createElement("div");
        title.className = "fh-timer-alarm-title";
        title.style.cssText = "font-size:1.3em;font-weight:800;margin-bottom:4px;overflow-wrap:anywhere;";
        title.textContent = info.title || __fhT("text.timer", "Timer");
        row.appendChild(title);
        if (info.body) {
          const body = document.createElement("div");
          body.style.cssText = "font-size:14px;color:#6b5f52;margin-bottom:10px;overflow-wrap:anywhere;";
          body.textContent = info.body;
          row.appendChild(body);
        }
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "fh-timer-alarm-stop";
        btn.dataset.uid = uid;
        btn.textContent = __fhT("text.stop", "Stop");
        btn.style.cssText = "min-height:54px;width:100%;border:none;border-radius:14px;background:#8f5a00;color:#fff8ea;font-size:19px;font-weight:800;cursor:pointer;";
        row.appendChild(btn);
        list.appendChild(row);
      });
      el.querySelector(".fh-timer-alarm-stop-all").style.display = ringing.size > 1 ? "" : "none";
      el.style.display = "flex";
    }
    function playBeep(atTime, freq) {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "square";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, atTime);
      gain.gain.exponentialRampToValueAtTime(0.3, atTime + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, atTime + 0.13);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(atTime);
      osc.stop(atTime + 0.15);
    }
    // A two-pitch alarm-clock trill via Web Audio (no sound file to ship).
    function beepOnce() {
      try {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === "suspended") audioCtx.resume();
        const now = audioCtx.currentTime;
        [[0, 1046], [0.15, 1318], [0.3, 1046]].forEach(([offset, freq]) => playBeep(now + offset, freq));
      } catch (e) {
        // Autoplay blocked or no Web Audio - the modal is still the alarm.
      }
    }
    // Ends whichever Family Hub screensaver is showing (they all close on
    // pointerdown on their own overlay).
    function wakeAnyScreenSaver() {
      try {
        const overlay = document.querySelector("[data-family-hub-screensaver]");
        if (overlay && overlay.style.display !== "none") {
          overlay.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true }));
        }
      } catch (e) {
        // best-effort
      }
    }
    function start(uid, title, body, hass) {
      if (hass) lastHass = hass;
      if (!uid || dismissedUids.has(uid)) return;
      const isNew = !ringing.has(uid);
      ringing.set(uid, { title: title || (ringing.get(uid) || {}).title || "Timer", body: body || (ringing.get(uid) || {}).body || "" });
      if (!isNew) return;
      wakeAnyScreenSaver();
      render();
      if (!beepHandle) {
        beepOnce();
        beepHandle = setInterval(beepOnce, 950);
      }
    }
    function stop(uid) {
      if (!uid) return;
      dismissedUids.add(uid);
      const had = ringing.delete(uid);
      if (!ringing.size && beepHandle) {
        clearInterval(beepHandle);
        beepHandle = null;
      }
      render();
      if (had && lastHass && lastHass.connection && lastHass.connection.sendMessagePromise) {
        lastHass.connection.sendMessagePromise({ type: "family_hub/timers/dismiss_alarm", uid }).catch(() => {});
      }
    }
    return {
      // From a card's 1-second countdown tick: the tab that started a timer rings the moment it reaches zero (any timer it started
      check(timers, clientId, remainingSecondsFn, hass) {
        if (hass) lastHass = hass;
        const me = clientId || myClientId();
        if (!me) return;
        (timers || []).forEach((t) => {
          if (t && t.origin_client_id && t.origin_client_id === me && !dismissedUids.has(t.uid) && remainingSecondsFn(t) <= 0) {
            start(t.uid, t.title || "Timer", "", hass);
          }
        });
      },
      // The backend's ring event (and list_active_alarms on load).
      ringBroadcast(payload, hass, myUserId) {
        if (!payload || !payload.uid || dismissedUids.has(payload.uid)) return;
        const targets = payload.target_user_ids || [];
        const fromHere = !!payload.origin_client_id && payload.origin_client_id === myClientId();
        const shouldRing = !!payload.broadcast_all || fromHere || (myUserId && targets.includes(myUserId));
        if (!shouldRing) return;
        start(payload.uid, payload.timer_title || payload.title, payload.body, hass);
      },
      // Someone stopped it somewhere else.
      stopFromServer(uid) {
        if (!uid) return;
        dismissedUids.add(uid);
        if (ringing.delete(uid)) {
          if (!ringing.size && beepHandle) {
            clearInterval(beepHandle);
            beepHandle = null;
          }
          render();
        }
      },
      _ringing() {
        return Array.from(ringing.keys());
      },
    };
  })();
}

// Theme flash-of-default fix - Root cause: EVERY themed card's first paint happens with no theme CSS vars set at all
if (!window.__familyHubThemeCache) {
  window.__familyHubThemeCache = (function () {
    const STORAGE_PREFIX = "familyHubThemeVarsCache::";
    const memory = new Map(); // key -> {varName: value}

    function get(key) {
      if (memory.has(key)) return memory.get(key);
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + key);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === "object") {
            memory.set(key, parsed);
            return parsed;
          }
        }
      } catch (e) {
        // Corrupt/blocked localStorage (private browsing, etc.) - just
        // means no cache to apply this time, same as a first-ever load.
      }
      return null;
    }
    function set(key, vars) {
      memory.set(key, vars);
      try {
        localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(vars));
      } catch (e) {
        // Best-effort only - the in-memory copy above still helps every OTHER card mounted later in this same page load even if localStorage itself
      }
    }
    return { get, set };
  })();
}

class FamilyHubRecipeBoxCard extends HTMLElement {
  static getStubConfig() {
    return { title: "Recipe Box" };
  }
  static getConfigForm() {
    return {
      schema: [{ name: "title", selector: { text: {} } }],
      computeLabel: (s) => (s.name === "title" ? "Title" : undefined),
    };
  }
  static getConfigElement() {
    return document.createElement("family-hub-recipe-box-card-editor");
  }
  setConfig(config) {
    this._config = {
      title: (config && config.title) || "Recipe Box",
      // per-card Theme override - see family-hub-goals-card.js's identical field/comment for the full precedence story.
      theme_override: (config && typeof config.theme_override === "string") ? config.theme_override : "",
    };
    if (this._settingsCache === undefined) this._settingsCache = null;
    if (this._globalThemes === undefined) this._globalThemes = [];
    // Everything below mirrors the Recipe Box state family-week-calendar- card.js's own constructor sets up (same field names, same defaults)
    if (this._recipes === undefined) this._recipes = [];
    if (this._suggestions === undefined) this._suggestions = [];
    if (this._myPermissions === undefined) this._myPermissions = {};
    if (this._grocyImageCache === undefined) this._grocyImageCache = {};
    if (this._grocyImageFetching === undefined) this._grocyImageFetching = new Set();
    if (this._recipeBoxSort === undefined) this._recipeBoxSort = "default";
    if (this._recipeBoxSelectMode === undefined) this._recipeBoxSelectMode = false;
    if (this._recipeBoxSelectedUids === undefined) this._recipeBoxSelectedUids = new Set();
    if (this._lovedSearchTerm === undefined) this._lovedSearchTerm = "";
    if (this._recipeBoxCategory === undefined) this._recipeBoxCategory = "All";
    // This card is never a "picker" for some other editor - it's always the full browse/manage experience
    this._pickerMode = false;
    if (this._topModalZ === undefined) this._topModalZ = 1006;
    if (this._firstLoadPromise === undefined) this._firstLoadPromise = null;
    if (!this._built) this._build();
    if (this._root) this._root.querySelector(".fh-recipe-box-title").textContent = this._config.title;
  }
  set hass(hass) {
    const first = !this._hass;
    this._hass = hass;
    this._ensureTranslationsLoaded();
    if (first) this._firstLoadPromise = this._initFirstLoad();
  }
  _t(key, fallback, vars) {
    let str = "";
    try {
      if (this._hass && typeof this._hass.localize === "function") {
        str = this._hass.localize(`component.family_hub.fh_ui.${key}`) || "";
      }
    } catch (e) {
      str = "";
    }
    if (!str) str = fallback;
    if (vars) {
      Object.keys(vars).forEach((k) => {
        str = str.split(`%${k}%`).join(vars[k]);
      });
    }
    return str;
  }
  _baseLanguage(lang) {
    return (lang || "en").split("-")[0].toLowerCase();
  }
  _ensureTranslationsLoaded() {
    __fhUseHass(this._hass);
    if (!this._hass || typeof this._hass.loadBackendTranslation !== "function") return;
    const lang = this._baseLanguage(this._hass.language);
    if (this._i18nLoadedLang === lang) {
      // Home Assistant hands cards the hass object that actually knows the newly loaded strings a moment AFTER loadBackendTranslation resolves
      if (this._hass.localize !== this._i18nLocalize) {
        this._i18nLocalize = this._hass.localize;
        // redraw only when our strings changed - a new localize function alone made cards flicker (GitHub issue #16)
        let probe = "";
        try { probe = this._hass.localize("component.family_hub.fh_ui.nav.settings") || ""; } catch (e) { probe = ""; }
        probe = `${this._hass.language}|${probe}`;
        if (probe !== this._i18nLastProbe) {
          this._i18nLastProbe = probe;
          this._onTranslationsReady();
        }
      }
      return;
    }
    if (this._i18nLoading === lang) return;
    this._i18nLoading = lang;
    this._hass
      .loadBackendTranslation("fh_ui", "family_hub")
      .then(() => {
        this._i18nLoadedLang = lang;
        this._i18nLoading = null;
        this._i18nLocalize = this._hass.localize;
        this._onTranslationsReady();
      })
      .catch((e) => {
        this._i18nLoading = null;
        console.warn("[family_hub] failed to load \"" + lang + "\" translations - staying on English fallback text", e);
      });
  }
  // Redraws everything that shows translated text.
  _onTranslationsReady() {
    this._applyTranslations();
    if (this._root) this._renderLoved();
  }
  _applyTranslations() {
    __fhSweep(this._root || this.shadowRoot);
    if (!this._root) return;
    this._root.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.dataset.i18n;
      if (el.dataset.i18nFallback === undefined) el.dataset.i18nFallback = el.textContent;
      el.textContent = this._t(key, el.dataset.i18nFallback);
    });
    this._root.querySelectorAll("[data-i18n-title]").forEach((el) => {
      const key = el.dataset.i18nTitle;
      if (el.dataset.i18nTitleFallback === undefined) {
        el.dataset.i18nTitleFallback = el.getAttribute("title") || el.getAttribute("aria-label") || "";
      }
      const translated = this._t(key, el.dataset.i18nTitleFallback);
      if (el.hasAttribute("title")) el.setAttribute("title", translated);
      if (el.hasAttribute("aria-label")) el.setAttribute("aria-label", translated);
    });
  }
  async _initFirstLoad() {
    // baseline theming, new for this card - see setConfig's own comment.
    await this._fetchSettings();
    await this._fetchGlobalThemes();
    await this._fetchMyPermissions();
    await this._fetchRecipes();
    await this._fetchSuggestions();
    this._startPolling();
    // see this file's own copy of the window.__familyHubTimerAlarm singleton (below) for the full design note.
    this._subscribeAlarmEvents();
  }
  async _subscribeAlarmEvents() {
    if (this._alarmUnsub || !this._hass || !this._hass.connection) return;
    const myUserId = this._myUserId();
    try {
      const unsubRing = await this._hass.connection.subscribeEvents((event) => {
        if (window.__familyHubTimerAlarm) {
          window.__familyHubTimerAlarm.ringBroadcast(event.data, this._hass, typeof this._myUserId === "function" ? this._myUserId() : myUserId);
        }
      }, "family_hub_timer_alarm_ring");
      const unsubStop = await this._hass.connection.subscribeEvents((event) => {
        if (window.__familyHubTimerAlarm && event.data) {
          window.__familyHubTimerAlarm.stopFromServer(event.data.uid);
        }
      }, "family_hub_timer_alarm_stop");
      this._alarmUnsub = () => {
        try { unsubRing(); } catch (e) { /* no-op */ }
        try { unsubStop(); } catch (e) { /* no-op */ }
      };
    } catch (e) {
      // Best-effort - a dashboard that can't subscribe (e.g. a very old frontend build) simply never gets the WIDENED alarm reach
    }
    // Catch up on anything already ringing before this tab opened
    if (this._hass.connection.sendMessagePromise) {
      try {
        const result = await this._hass.connection.sendMessagePromise({ type: "family_hub/timers/list_active_alarms" });
        for (const alarm of (result && result.alarms) || []) {
          if (window.__familyHubTimerAlarm) window.__familyHubTimerAlarm.ringBroadcast(alarm, this._hass, myUserId);
        }
      } catch (e) {
        // Best-effort catch-up only - the next re-announcement still
        // covers it.
      }
    }
  }
  _startPolling() {
    if (this._interval) return;
    // Same 60s cadence as the calendar card's own _refreshAllData poll - this card shows the same household-wide
    this._interval = setInterval(() => {
      this._fetchRecipes();
      this._fetchSuggestions();
    }, 60 * 1000);
  }
  connectedCallback() {
    if (window.__familyHubEink) window.__familyHubEink.attach(this, Object.assign({}, { css: this.constructor.EINK_CSS || "" }));
    if (window.__familyHubModalScroll) window.__familyHubModalScroll.watch(this);
    if (this._hass && !this._interval) {
      if (this._firstLoadPromise) this._firstLoadPromise.then(() => this.isConnected && this._startPolling());
      else this._startPolling();
    }
  }
  disconnectedCallback() {
    if (window.__familyHubEink) window.__familyHubEink.detach(this);
    if (window.__familyHubModalScroll) window.__familyHubModalScroll.unwatch(this);
    if (this._interval) clearInterval(this._interval);
    this._interval = null;
    // the Grocy Recipe Viewer's portal (see _grocyViewerOverlay's own comment) lives on document.body, outside this card's own DOM entirely
    if (this._grocyRecipeViewerPortalEl) {
      this._grocyRecipeViewerPortalEl.remove();
      this._grocyRecipeViewerPortalEl = null;
      this._grocyRecipeViewerOverlayEl = null;
    }
    // Same teardown, same reason, for the step editor's own portal (see
    // _fhStepEditorOverlay's own comment).
    if (this._fhStepEditorPortalEl) {
      this._fhStepEditorPortalEl.remove();
      this._fhStepEditorPortalEl = null;
      this._fhStepEditorOverlayEl = null;
    }
  }
  getCardSize() {
    return 8;
  }
  getGridOptions() {
    return { columns: 12, min_columns: 6, max_columns: 12, min_rows: 6 };
  }
  // ------------------------------------------------------------------------ Small card-local infra the shared block above calls into
  _openModal(el) {
    if (!el) return;
    this._topModalZ = (this._topModalZ || 1006) + 1;
    el.style.zIndex = String(this._topModalZ);
    el.classList.add("open");
  }
  _closeModal(el) {
    if (el) el.classList.remove("open");
  }
  _renderGrid() {
    // No meal-plan grid on this card - the shared _fetchRecipes/_upsertDish/ _deleteDish call this unconditionally after touching this._recipes
  }
  _resetScreenSaverIdleTimer() {
    // This card has no Screen Saver feature to protect - the shared _openDishDetail/_closeDishDetail call this unconditionally
  }
  // _openGrocyRecipeViewer itself (and its whole supporting cast) is no longer a card-local stub here - it's the real
  _updateRatingButtons() {
    if (!this._root) return;
    const heart = this._root.querySelector(".rb-btn-heart");
    const thumbsdown = this._root.querySelector(".rb-btn-thumbsdown");
    if (heart) heart.classList.toggle("active-up", this._currentRbRating === "up");
    if (thumbsdown) thumbsdown.classList.toggle("active-down", this._currentRbRating === "down");
  }
  // ------------------------------------------------------------------------ This card's own small add/edit-dish mini-modal
  _openRecipeBoxEditor(recipe) {
    const root = this._root;
    if (!root) return;
    this._editingDishUid = recipe ? recipe.uid : null;
    this._editingDishGrocyRecipeId = (recipe && recipe.grocyRecipeId) || null;
this._editingDishSteps = recipe ? recipe.steps || [] : [];
    root.querySelector(".rb-editor-title").textContent = recipe ? this._t("recipe_box.edit_recipe_title", "Edit Recipe") : this._t("recipe_box.add_recipe_title", "Add Recipe");
    root.querySelector(".rb-input-name").value = recipe ? recipe.name || "" : "";
    root.querySelector(".rb-input-description").value = recipe ? recipe.description || "" : "";
    root.querySelector(".rb-input-link").value = recipe ? recipe.link || "" : "";
    root.querySelector(".input-category").value = recipe ? recipe.category || "" : "";
    this._populateDishCategoryOptions();
    root.querySelector(".rb-input-add-suggestion").checked = false;
    this._setRecipeBoxEditorImage(recipe ? recipe.image || "" : "");
    this._currentRbRating = recipe ? recipe.rating || null : null;
    this._updateRatingButtons();
    root.querySelector(".rb-editor-delete-btn").style.display = recipe ? "" : "none";
    this._closeDishDetail();
    this._openModal(root.querySelector(".rb-editor-overlay"));
  }
  _closeRecipeBoxEditor() {
    this._closeModal(this._root.querySelector(".rb-editor-overlay"));
  }
  _setRecipeBoxEditorImage(url) {
    const root = this._root;
    if (!root) return;
    const input = root.querySelector(".rb-input-image");
    const preview = root.querySelector(".rb-image-preview");
    if (input) input.value = url || "";
    if (!preview) return;
    if (url) {
      preview.src = url;
      preview.style.display = "block";
    } else {
      preview.src = "";
      preview.style.display = "none";
    }
  }
  _saveRecipeBoxEditor() {
    const root = this._root;
    if (!root) return;
    const name = root.querySelector(".rb-input-name").value.trim();
    const description = root.querySelector(".rb-input-description").value.trim();
    const link = root.querySelector(".rb-input-link").value.trim();
    const category = root.querySelector(".input-category").value.trim();
    const image = root.querySelector(".rb-input-image").value.trim();
    const addAsSuggestion = root.querySelector(".rb-input-add-suggestion").checked;
    if (name) {
      // checkDuplicates=true - this IS the deliberate "add/edit a Recipe Box
      // entry" action, same as the modal's own _saveDishEditor.
      this._upsertDish(name, description, link, this._currentRbRating, this._editingDishUid, this._editingDishGrocyRecipeId, category, image, true, this._editingDishSteps);
      if (addAsSuggestion) {
        this._addSuggestion(name, description, link, this._editingDishGrocyRecipeId);
      }
    }
    this._closeRecipeBoxEditor();
  }
  _deleteRecipeBoxEditorDish() {
    if (!this._editingDishUid) return;
    const root = this._root;
    const name = root.querySelector(".rb-input-name").value.trim();
    const grocyNote = this._editingDishGrocyRecipeId ? this._t("recipe_box.note_delete_linked", " This will also delete it from Grocy.") : "";
    if (!window.confirm(this._t("recipe_box.confirm_delete_named", `Delete "${name}" from the Recipe Box?${grocyNote}`, { name, note: grocyNote }))) return;
    this._deleteDish(this._editingDishUid, this._editingDishGrocyRecipeId);
    this._closeRecipeBoxEditor();
  }
  // -------------------------------------------------------------------------
  _build() {
    this._built = true;
    // applied BEFORE attachShadow/the first innerHTML paint - see _applyCachedThemeVarsIfAny's own comment and window.__familyHub ThemeCache's
    this._applyCachedThemeVarsIfAny();
    this.attachShadow({ mode: "open" });
    const root = this.shadowRoot;
    root.innerHTML = `
      <style>${this._css()}</style>
      <ha-card>
        <div class="fh-recipe-box-header">
          <div class="fh-recipe-box-title"></div>
          <button type="button" class="suggestion-add-btn add-dish-btn" data-i18n="recipe_box.add_recipe_btn">+ Add Recipe</button>
        </div>
        <div class="recipe-box-actions">
          <button type="button" class="suggestion-add-btn recipe-box-select-btn">&#9989;<span data-i18n="recipe_box.select_btn_suffix"> Select</span></button>
        </div>
        <div class="recipe-box-select-bar" style="display:none;">
          <span data-fh-t="text.n0_selected" class="recipe-box-select-count">${__fhT("text.n0_selected", "0 selected", null, "h")}</span>
          <div class="recipe-box-select-actions">
            <button type="button" class="recipe-box-select-cancel" data-i18n="common.cancel">Cancel</button>
            <button type="button" class="recipe-box-select-delete" data-i18n="recipe_box.delete">Delete</button>
          </div>
        </div>
        <div class="recipe-box-search-row">
          <input data-fh-placeholder="text.search_recipes" type="text" class="loved-search" placeholder="${__fhT("text.search_recipes", "🔍 Search recipes...", null, "h")}" />
          <div class="recipe-view-toggle">
            <button type="button" class="recipe-view-btn" data-view="grid" title="Grid view" aria-label="Grid view" data-i18n-title="recipe_box.grid_view_title">&#9638;</button>
            <button type="button" class="recipe-view-btn" data-view="list" title="List view" aria-label="List view" data-i18n-title="recipe_box.list_view_title">&#9776;</button>
          </div>
        </div>
        <select class="recipe-sort-select">
          <option value="default" data-i18n="recipe_box.sort_default">Sort: Default order</option>
          <option value="name" data-i18n="recipe_box.sort_name">Sort: Name (A-Z)</option>
          <option value="suggested" data-i18n="recipe_box.sort_suggested">Sort: Suggested first</option>
        </select>
        <div class="recipe-box-categories"></div>
        <div class="loved-list"></div>
      </ha-card>
      <div class="modal-overlay dish-detail-overlay">
        <div class="modal-box dish-detail-box">
          <button data-fh-aria="text.close" class="modal-close dish-detail-close" aria-label="${__fhT("text.close", "Close", null, "h")}">&#10005;</button>
          <h2 class="dish-detail-title"></h2>
          <img class="dish-detail-photo" style="display:none;" alt="" />
          <div class="dish-detail-rating"></div>
          <div class="dish-detail-desc"></div>
          <div class="dish-detail-steps"></div>
          <div class="dish-detail-link-row"></div>
          <div class="modal-actions">
            <button data-fh-t="text.suggest_this" class="btn-cancel dish-detail-suggest-btn">${__fhT("text.suggest_this", "💡 Suggest this", null, "h")}</button>
            <button data-fh-t="text.edit_2" class="btn-cancel dish-detail-edit-btn">${__fhT("text.edit_2", "✏️ Edit", null, "h")}</button>
            <button data-fh-t="text.delete_2" class="btn-clear dish-detail-delete-btn">${__fhT("text.delete_2", "🗑️ Delete", null, "h")}</button>
          </div>
        </div>
      </div>
      <div class="modal-overlay grocy-recipe-viewer-overlay">
        <div class="modal-box loved-box">
          <button data-fh-aria="text.close" class="modal-close grocy-recipe-viewer-close" aria-label="${__fhT("text.close", "Close", null, "h")}">&#10005;</button>
          <button data-fh-t="text.back" type="button" class="grocy-recipe-viewer-back-btn" style="display:none;">${__fhT("text.back", "← Back", null, "h")}</button>
          <h2 class="grocy-recipe-viewer-title"></h2>
          <div class="grocy-recipe-viewer-tabs" style="display:none;"></div>
          <div class="grocy-recipe-viewer-status"></div>
          <div class="grocy-recipe-viewer-stats"></div>
          <div class="grocy-recipe-viewer-columns">
            <div class="grocy-recipe-viewer-main-col">
              <div class="grocy-recipe-viewer-servings"></div>
              <div class="grocy-recipe-viewer-scale-row" style="display:none;">
                <span data-fh-t="text.scale_ingredients_for" class="grocy-recipe-viewer-scale-label">${__fhT("text.scale_ingredients_for", "Scale ingredients for", null, "h")}</span>
                <button data-fh-aria="text.fewer_servings" type="button" class="grocy-recipe-viewer-scale-down" aria-label="${__fhT("text.fewer_servings", "Fewer servings", null, "h")}">&#8722;</button>
                <span class="grocy-recipe-viewer-scale-value"></span>
                <span class="grocy-recipe-viewer-scale-unit">servings</span>
                <button data-fh-aria="text.more_servings" type="button" class="grocy-recipe-viewer-scale-up" aria-label="${__fhT("text.more_servings", "More servings", null, "h")}">&#43;</button>
              </div>
              <div class="grocy-recipe-viewer-ingredients"></div>
            </div>
            <img class="grocy-recipe-viewer-photo" style="display:none;" alt="" />
          </div>
          <div class="grocy-recipe-viewer-instructions"></div>
          <div class="grocy-recipe-viewer-description"></div>
          <div class="grocy-recipe-viewer-footer">
            <button data-fh-t="text.mark_consumed_deduct_from_grocy_stock" type="button" class="suggestion-add-btn grocy-recipe-viewer-consume-btn">${__fhT("text.mark_consumed_deduct_from_grocy_stock", "🍴 Mark Consumed (deduct from Grocy stock)", null, "h")}</button>
            <button data-fh-t="text.open_in_grocy" type="button" class="suggestion-add-btn grocy-recipe-viewer-open-btn">${__fhT("text.open_in_grocy", "🔗 Open in Grocy", null, "h")}</button>
            <!-- See the matching comment in family-week-calendar-card.js -
                 moved out of .grocy-recipe-viewer-recipe-actions (source-
                 recipe-only) since Edit Steps only ever needed the Grocy
                 recipe id, same as Open in Grocy/Mark Consumed above. -->
            <button data-fh-t="text.edit_steps" type="button" class="suggestion-add-btn grocy-recipe-viewer-edit-steps-btn">${__fhT("text.edit_steps", "📝 Edit Steps", null, "h")}</button>
            <div class="modal-actions grocy-recipe-viewer-recipe-actions" style="display:none;">
              <button data-fh-t="text.suggest_this" type="button" class="btn-cancel grocy-recipe-viewer-suggest-btn">${__fhT("text.suggest_this", "💡 Suggest this", null, "h")}</button>
              <button data-fh-t="text.edit_2" type="button" class="btn-cancel grocy-recipe-viewer-edit-btn">${__fhT("text.edit_2", "✏️ Edit", null, "h")}</button>
              <button data-fh-t="text.delete_2" type="button" class="btn-clear grocy-recipe-viewer-delete-btn">${__fhT("text.delete_2", "🗑️ Delete", null, "h")}</button>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-overlay fh-step-editor-overlay">
        <div class="modal-box loved-box fh-step-editor-box">
          <button data-fh-aria="text.close" class="modal-close fh-step-editor-close" aria-label="${__fhT("text.close", "Close", null, "h")}">&#10005;</button>
          <h2 data-fh-t="text.edit_steps_2" class="fh-step-editor-title">${__fhT("text.edit_steps_2", "Edit Steps", null, "h")}</h2>
          <div class="fh-step-editor-list"></div>
          <div class="fh-step-editor-add-row">
            <button data-fh-t="text.step" type="button" class="pick-loved-btn fh-step-editor-add-step">${__fhT("text.step", "+ Step", null, "h")}</button>
            <button data-fh-t="text.header" type="button" class="pick-loved-btn fh-step-editor-add-header">${__fhT("text.header", "+ Header", null, "h")}</button>
            <button data-fh-t="text.divider" type="button" class="pick-loved-btn fh-step-editor-add-divider">${__fhT("text.divider", "+ Divider", null, "h")}</button>
            <button data-fh-t="text.photo" type="button" class="pick-loved-btn fh-step-editor-add-image">${__fhT("text.photo", "+ Photo", null, "h")}</button>
            <input type="file" class="fh-step-editor-image-input" accept="image/*" style="display:none;" />
          </div>
          <div class="modal-actions">
            <button data-fh-t="text.cancel" type="button" class="btn-cancel fh-step-editor-cancel-btn">${__fhT("text.cancel", "Cancel", null, "h")}</button>
            <button data-fh-t="text.save" type="button" class="btn-save fh-step-editor-save-btn">${__fhT("text.save", "Save", null, "h")}</button>
          </div>
        </div>
      </div>
      <div class="modal-overlay rb-editor-overlay">
        <div class="modal-box">
          <button class="modal-close rb-editor-close" aria-label="Close" data-i18n-title="common.close">&#10005;</button>
          <h2 data-fh-t="text.add_recipe" class="rb-editor-title">${__fhT("text.add_recipe", "Add Recipe", null, "h")}</h2>
          <label><span data-i18n="recipe_box.name_label">Name</span><input type="text" class="rb-input-name" maxlength="120" /></label>
          <label><span data-i18n="recipe_box.notes_label">Notes</span><textarea class="rb-input-description" rows="2" maxlength="500"></textarea></label>
          <label><span data-i18n="recipe_box.link_label">Link</span><input type="url" class="rb-input-link" placeholder="https://..." maxlength="500" /></label>
          <label><span data-i18n="recipe_box.category_label">Category</span><input data-fh-placeholder="text.e_g_dinner" type="text" class="input-category" list="dish-category-options" placeholder="${__fhT("text.e_g_dinner", "e.g. Dinner", null, "h")}" maxlength="40" /><datalist id="dish-category-options"></datalist></label>
          <label><span data-i18n="recipe_box.photo_url_label">Photo URL</span><input type="url" class="rb-input-image" placeholder="https://..." maxlength="500" /></label>
          <img class="rb-image-preview" style="display:none;" alt="" />
          <div class="rating-row">
            <button type="button" class="rating-btn rb-btn-heart" title="Love it" data-i18n-title="recipe_box.love_it_title">&#10084;&#65039;</button>
            <button type="button" class="rating-btn rb-btn-thumbsdown" title="Not a fan" data-i18n-title="recipe_box.not_a_fan_title">&#128078;</button>
          </div>
          <label class="remind-check-opt"><input type="checkbox" class="rb-input-add-suggestion" />&#128161;<span data-i18n="recipe_box.also_add_suggestion_suffix"> Also add to Meal Suggestions</span></label>
          <button data-fh-t="text.edit_steps" type="button" class="pick-loved-btn rb-editor-edit-steps-btn">${__fhT("text.edit_steps", "📝 Edit Steps", null, "h")}</button>
          <div class="modal-actions">
            <button class="btn-clear rb-editor-delete-btn" style="display:none;" data-i18n="recipe_box.delete">Delete</button>
            <button class="btn-cancel rb-editor-cancel-btn" data-i18n="common.cancel">Cancel</button>
            <button class="btn-save rb-editor-save-btn" data-i18n="common.save">Save</button>
          </div>
        </div>
      </div>
    `;
    this._root = root;
    root.querySelector(".fh-recipe-box-title").textContent = this._config.title;
    root.querySelector(".add-dish-btn").addEventListener("click", () => this._openRecipeBoxEditor(null));
    root.querySelector(".loved-search").addEventListener("input", (e) => {
      this._lovedSearchTerm = e.target.value;
      this._renderLoved();
    });
    root.querySelectorAll(".recipe-view-btn").forEach((btn) => {
      btn.addEventListener("click", () => this._setRecipeBoxViewMode(btn.dataset.view));
    });
    root.querySelector(".recipe-sort-select").addEventListener("change", (e) => {
      this._recipeBoxSort = e.target.value;
      this._renderLoved();
    });
    root.querySelector(".recipe-box-select-btn").addEventListener("click", () => this._toggleRecipeBoxSelectMode(true));
    root.querySelector(".recipe-box-select-cancel").addEventListener("click", () => this._toggleRecipeBoxSelectMode(false));
    root.querySelector(".recipe-box-select-delete").addEventListener("click", () => this._deleteSelectedRecipeBoxItems());
    root.querySelector(".dish-detail-close").addEventListener("click", () => this._closeDishDetail());
    root.querySelector(".dish-detail-edit-btn").addEventListener("click", () => {
      const recipe = this._dishDetailRecipe;
      if (recipe) this._openRecipeBoxEditor(recipe);
    });
    root.querySelector(".dish-detail-delete-btn").addEventListener("click", () => {
      const recipe = this._dishDetailRecipe;
      if (!recipe) return;
      const grocyNote = recipe.grocyRecipeId ? this._t("recipe_box.note_delete_linked", " This will also delete it from Grocy.") : "";
      if (!window.confirm(this._t("recipe_box.confirm_delete_named", `Delete "${recipe.name}" from the Recipe Box?${grocyNote}`, { name: recipe.name, note: grocyNote }))) return;
      this._deleteDish(recipe.uid, recipe.grocyRecipeId);
      this._closeDishDetail();
    });
    // the same Grocy Recipe Viewer wiring as family-week-calendar- card.js's own connectedCallback
    root.querySelector(".grocy-recipe-viewer-close").addEventListener("click", () => this._closeGrocyRecipeViewer());
    root.querySelector(".grocy-recipe-viewer-back-btn").addEventListener("click", () => this._closeGrocyRecipeViewer());
    root.querySelector(".grocy-recipe-viewer-tabs").addEventListener("click", (e) => {
      const btn = e.target.closest(".grocy-recipe-viewer-tab-btn");
      if (!btn) return;
      this._switchGrocyRecipeViewerTab(btn.dataset.recipeTabId);
    });
    root.querySelector(".grocy-recipe-viewer-open-btn").addEventListener("click", () => {
      if (this._grocyRecipeViewerFallbackLink) window.open(this._grocyRecipeViewerFallbackLink, "_blank", "noopener");
    });
    root.querySelector(".grocy-recipe-viewer-consume-btn").addEventListener("click", () => this._consumeGrocyRecipeIngredients());
    root.querySelector(".grocy-recipe-viewer-scale-down").addEventListener("click", () => this._adjustGrocyRecipeViewerServings(-1));
    root.querySelector(".grocy-recipe-viewer-scale-up").addEventListener("click", () => this._adjustGrocyRecipeViewerServings(1));
    // Suggest/Edit/Delete for whichever Recipe Box entry this viewer was opened FROM
    root.querySelector(".grocy-recipe-viewer-suggest-btn").addEventListener("click", (e) => {
      const recipe = this._grocyRecipeViewerSourceRecipe;
      if (!recipe) return;
      this._suggestDish(recipe);
      const btn = e.currentTarget;
      btn.textContent = this._t("recipe_box.added_to_suggestions", "\u{2705} Added to Suggestions");
      setTimeout(() => {
        btn.textContent = this._t("recipe_box.suggest_this", "\u{1F4A1} Suggest this");
      }, 1600);
    });
    root.querySelector(".grocy-recipe-viewer-edit-btn").addEventListener("click", () => {
      const recipe = this._grocyRecipeViewerSourceRecipe;
      if (!recipe) return;
      this._closeGrocyRecipeViewer();
      this._openRecipeBoxEditor(recipe);
    });
    root.querySelector(".grocy-recipe-viewer-edit-steps-btn").addEventListener("click", () => {
      const recipeId = this._grocyRecipeViewerRecipeId;
      if (!recipeId) return;
      // See the matching comment in family-week-calendar-card.js: close the
      const titleEl = this._grocyViewerOverlay().querySelector(".grocy-recipe-viewer-title");
      const name = (titleEl && titleEl.textContent) || "Recipe";
      const link = this._grocyRecipeViewerFallbackLink;
      const sourceRecipe = this._grocyRecipeViewerSourceRecipe;
      this._closeGrocyRecipeViewer();
      this._fhOpenStepEditor(
        this._grocyRecipeViewerStepBlocks || [],
        (blocks) => {
          this._saveGrocyRecipeStepEdits(recipeId, blocks, name, link, sourceRecipe);
        },
        () => {
          this._openGrocyRecipeViewer(recipeId, name, link, false, null, sourceRecipe);
        }
      );
    });
    root.querySelector(".fh-step-editor-add-step").addEventListener("click", () => {
      this._fhStepEditorBlocks.push({ type: "step", text: "" });
      this._renderFhStepEditorList();
    });
    root.querySelector(".fh-step-editor-add-header").addEventListener("click", () => {
      this._fhStepEditorBlocks.push({ type: "header", text: "" });
      this._renderFhStepEditorList();
    });
    root.querySelector(".fh-step-editor-add-divider").addEventListener("click", () => {
      this._fhStepEditorBlocks.push({ type: "divider" });
      this._renderFhStepEditorList();
    });
    root.querySelector(".fh-step-editor-add-image").addEventListener("click", () => {
      this._fhStepEditorOverlay().querySelector(".fh-step-editor-image-input").click();
    });
    root.querySelector(".fh-step-editor-image-input").addEventListener("change", async (e) => {
      const file = e.target.files && e.target.files[0];
      e.target.value = "";
      if (!file) return;
      const addImageBtn = this._fhStepEditorOverlay().querySelector(".fh-step-editor-add-image");
      const prevLabel = addImageBtn.textContent;
      addImageBtn.textContent = __fhT("text.uploading", "Uploading…");
      addImageBtn.disabled = true;
      try {
        const url = await this._fhUploadImage(file);
        this._fhStepEditorBlocks.push({ type: "image", url });
        this._renderFhStepEditorList();
      } catch (err) {
        window.alert(__fhT("text.couldn_t_upload_that_photo_x", "Couldn't upload that photo: %0%", {0: err && err.message ? err.message : err}));
      } finally {
        addImageBtn.textContent = prevLabel;
        addImageBtn.disabled = false;
      }
    });
    root.querySelector(".fh-step-editor-close").addEventListener("click", () => {
      const onCancel = this._fhStepEditorOnCancel;
      this._closeFhStepEditor();
      if (onCancel) onCancel();
    });
    root.querySelector(".fh-step-editor-cancel-btn").addEventListener("click", () => {
      const onCancel = this._fhStepEditorOnCancel;
      this._closeFhStepEditor();
      if (onCancel) onCancel();
    });
    root.querySelector(".fh-step-editor-save-btn").addEventListener("click", () => {
      const blocks = (this._fhStepEditorBlocks || []).filter((b) => b.type === "divider" || b.type === "image" || (b.text && b.text.trim()));
      const onSave = this._fhStepEditorOnSave;
      this._closeFhStepEditor();
      if (onSave) onSave(blocks);
    });
    root.querySelector(".grocy-recipe-viewer-delete-btn").addEventListener("click", () => {
      const recipe = this._grocyRecipeViewerSourceRecipe;
      if (!recipe) return;
      if (!window.confirm(this._t("recipe_box.confirm_delete_with_grocy", `Delete "${recipe.name}" from the Recipe Box? This will also delete it from Grocy.`, { name: recipe.name }))) return;
      this._deleteDish(recipe.uid, recipe.grocyRecipeId);
      this._closeGrocyRecipeViewer();
    });
    root.querySelectorAll(".rating-btn.rb-btn-heart").forEach((btn) => {
      btn.addEventListener("click", () => {
        this._currentRbRating = this._currentRbRating === "up" ? null : "up";
        this._updateRatingButtons();
      });
    });
    root.querySelectorAll(".rating-btn.rb-btn-thumbsdown").forEach((btn) => {
      btn.addEventListener("click", () => {
        this._currentRbRating = this._currentRbRating === "down" ? null : "down";
        this._updateRatingButtons();
      });
    });
    root.querySelector(".rb-input-image").addEventListener("input", (e) => this._setRecipeBoxEditorImage(e.target.value.trim()));
    root.querySelector(".rb-editor-close").addEventListener("click", () => this._closeRecipeBoxEditor());
    root.querySelector(".rb-editor-cancel-btn").addEventListener("click", () => this._closeRecipeBoxEditor());
    root.querySelector(".rb-editor-save-btn").addEventListener("click", () => this._saveRecipeBoxEditor());
    root.querySelector(".rb-editor-delete-btn").addEventListener("click", () => this._deleteRecipeBoxEditorDish());
    root.querySelector(".rb-editor-edit-steps-btn").addEventListener("click", () => {
      this._fhOpenStepEditor(this._editingDishSteps || [], (blocks) => {
        this._editingDishSteps = blocks;
      });
    });
    this._recipeBoxCategory = "All";
    this._renderRecipeBoxCategoryChips();
    this._updateRecipeBoxViewButtons();
    this._renderLoved();
    // this used to unconditionally call `_applyThemeVars()` here too
  }
  // -- Baseline theming (new for this card, v1.111.0+) - see setConfig's own comment on why this card never had any theming at all before.
  _defaultTheme() {
    return {
      colors: {
        bg: "#fbf7e5", card: "#f5f3f0", border: "#e6ddc4", text: "#423d34", textSecondary: "#96877a",
        accent: "#8f5a00", accentText: "#fff8ea", accent2: "#305545", accent3: "#b5583c",
        surfaceAlt: "#efe6cf", surface2: "#f2eede",
      },
    };
  }
  _defaultSettings() {
    return { theme: this._defaultTheme(), useGlobalTheme: true, globalThemeId: "slate" };
  }
  _getSettings() {
    return this._settingsCache || this._defaultSettings();
  }
  // Same this-device-only theme-override key as every other standalone Family Hub card
  _getDeviceThemeOverride() {
    let raw = "";
    try {
      raw = localStorage.getItem("familyHubDeviceThemeOverrideLocal") || "";
    } catch (e) {
    }
    return raw;
  }
  _themeFromGlobalEntry(g) {
    const defaultTheme = this._defaultTheme();
    const colors = {};
    Object.keys(defaultTheme.colors).forEach((k) => {
      const v = g.colors && g.colors[k];
      colors[k] = typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v) ? v : defaultTheme.colors[k];
    });
    const cardOpacity = typeof g.cardOpacity === "number" ? g.cardOpacity : 100;
    const glassBlur = typeof g.glassBlur === "number" ? g.glassBlur : 0;
    return { colors, fontFamily: (typeof g.fontFamily === "string" && /^[\w\s,'"\-]{1,200}$/.test(g.fontFamily.trim()) ? g.fontFamily.trim() : ""), cardOpacity, glassBlur, background: g.background || null };
  }
  _resolveTheme(settings) {
    const local = settings.theme || this._defaultTheme();
    // a per-card-placement Theme override (set from this card's own native "Edit Card" dialog) wins over everything else
    const cardOverride = this._config && this._config.theme_override;
    if (cardOverride) {
      const g = (this._globalThemes || []).find((t) => t && t.id === cardOverride);
      if (g) return this._themeFromGlobalEntry(g);
    }
    // a holiday background set to change the theme wins while it's showing
    if (window.__fhHolidayTheme) {
      if (!this.__fhHolidaySub) this.__fhHolidaySub = window.__fhHolidayTheme.subscribe(() => { if (this.isConnected) this._applyThemeVars(); });
      const holidayThemeId = window.__fhHolidayTheme.themeId(this._hass);
      const hg = holidayThemeId && (this._globalThemes || []).find((t) => t && t.id === holidayThemeId);
      if (hg) return this._themeFromGlobalEntry(hg);
    }
    const override = this._getDeviceThemeOverride();
    const useGlobalTheme = override ? override !== "__default__" : settings.useGlobalTheme;
    const globalThemeId = override ? (override === "__default__" ? "" : override) : settings.globalThemeId;
    if (!useGlobalTheme || !globalThemeId) return local;
    const g = (this._globalThemes || []).find((t) => t && t.id === globalThemeId);
    if (!g) return local;
    return this._themeFromGlobalEntry(g);
  }
  _hexToRgba(hex, alpha) {
    const h = (hex || "#000000").replace("#", "");
    if (h.length !== 6) return "rgba(0,0,0,0)";
    const r = parseInt(h.substr(0, 2), 16);
    const g = parseInt(h.substr(2, 2), 16);
    const b = parseInt(h.substr(4, 2), 16);
    const a = Math.max(0, Math.min(1, typeof alpha === "number" ? alpha : 1));
    return `rgba(${r}, ${g}, ${b}, ${a})`;
  }
  // see window.__familyHubThemeCache's own comment above the class for the full "why a key, not one shared blob" reasoning.
  _familyHubThemeCacheKey() {
    const cardOverride = this._config && this._config.theme_override;
    if (cardOverride) return `card:${cardOverride}`;
    const deviceOverride = this._getDeviceThemeOverride();
    if (deviceOverride) return `device:${deviceOverride}`;
    return "household";
  }
  _fhThemeBgVars(bg) {
    const img = bg && typeof bg.image === "string" && bg.image ? bg.image : "";
    if (!img) return { "--fc-bg-image": "none", "--fc-bg-overlay-image": "none", "--fc-bg-size": "cover", "--fc-bg-position": "center" };
    const ov = this._hexToRgba(/^#[0-9a-fA-F]{6}$/.test(bg.overlayColor || "") ? bg.overlayColor : "#000000", Number(bg.overlayOpacity) || 0);
    return {
      "--fc-bg-image": `url("${img.replace(/"/g, '\\"')}")`,
      "--fc-bg-overlay-image": `linear-gradient(${ov}, ${ov})`,
      "--fc-bg-size": bg.size === "repeat" ? "auto" : bg.size || "cover",
      "--fc-bg-position": bg.position || "center",
    };
  }
  _applyThemeVars() {
    if (!this._root) return;
    const theme = this._resolveTheme(this._getSettings());
    const cardOpacity = typeof theme.cardOpacity === "number" ? theme.cardOpacity : 100;
    const glassBlur = typeof theme.glassBlur === "number" ? theme.glassBlur : 0;
    // built as a plain object first (rather than each var going straight into its own setProperty call
    const vars = {
      "--fc-font-family": theme.fontFamily || "",
      "--fc-bg": theme.colors.bg,
      "--fc-card": this._hexToRgba(theme.colors.card, cardOpacity / 100),
      "--fc-card-menu": this._hexToRgba(theme.colors.card, Math.max(cardOpacity, 88) / 100),
      "--fc-border": theme.colors.border,
      "--fc-text": theme.colors.text,
      "--fc-text-secondary": theme.colors.textSecondary,
      "--fc-accent": theme.colors.accent,
      "--fc-accent-text": theme.colors.accentText,
      "--fc-accent2": theme.colors.accent2,
      "--fc-accent3": theme.colors.accent3,
      "--fc-surface-alt": this._hexToRgba(theme.colors.surfaceAlt, cardOpacity / 100),
      "--fc-surface2": this._hexToRgba(theme.colors.surface2, cardOpacity / 100),
      "--fc-glass-blur": `${glassBlur}px`,
    };
        // the theme's own background image (the Liquid Glass aurora, or any image a theme sets in Theme Builder) now paints behind this card too
    Object.assign(vars, this._fhThemeBgVars(theme.background));
    Object.keys(vars).forEach((name) => this.style.setProperty(name, vars[name]));
    // only cache once `_hass` is actually set.
    if (this._hass && window.__familyHubThemeCache) window.__familyHubThemeCache.set(this._familyHubThemeCacheKey(), vars);
  }
  // applies whatever theme this device/placement last actually resolved to, SYNCHRONOUSLY
  _applyCachedThemeVarsIfAny() {
    if (!window.__familyHubThemeCache) return;
    const cached = window.__familyHubThemeCache.get(this._familyHubThemeCacheKey());
    if (!cached) return;
    Object.keys(cached).forEach((name) => {
      if (typeof cached[name] === "string") this.style.setProperty(name, cached[name]);
    });
  }
  async _fetchSettings() {
    if (!this._hass) return;
    try {
      const result = await this._hass.connection.sendMessagePromise({ type: "family_hub/get_settings" });
      const raw = result && result.settings;
      this._settingsCache = raw && typeof raw === "object" ? Object.assign(this._defaultSettings(), raw) : this._defaultSettings();
    } catch (e) {
      if (!this._settingsCache) this._settingsCache = this._defaultSettings();
    }
    this._applyThemeVars();
  }
  async _fetchGlobalThemes() {
    let custom = [];
    try {
      const result = await this._hass.connection.sendMessagePromise({ type: "theme_builder/list" });
      custom = (result && Array.isArray(result.themes)) ? result.themes : [];
    } catch (e) {
      custom = [];
    }
    this._globalThemes = custom.concat(this._nativeHaThemeEntries());
    this._applyThemeVars();
  }
  // -- Native HA theme support (duplicated from family-week-calendar- card.js's identical methods
  _haVarsToBuilderColors(vars) {
    const v = vars || {};
    const accent = v["primary-color"];
    return {
      bg: v["primary-background-color"],
      card: v["card-background-color"] || v["ha-card-background"],
      border: v["divider-color"],
      text: v["primary-text-color"],
      textSecondary: v["secondary-text-color"],
      accent: accent,
      accentText: v["text-primary-color"],
      accent2: v["accent-color"] || accent,
      accent3: v["warning-color"],
      surfaceAlt: v["secondary-background-color"],
      surface2: v["secondary-background-color"],
    };
  }
  _haThemeCssVars(name) {
    const themes = (this._hass && this._hass.themes && this._hass.themes.themes) || {};
    const theme = themes[name];
    if (!theme) return {};
    const vars = {};
    for (const key of Object.keys(theme)) {
      if (key === "modes") continue;
      vars[key] = theme[key];
    }
    if (theme.modes) {
      const dark = !!(this._hass && this._hass.themes && this._hass.themes.darkMode);
      const modeVars = theme.modes[dark ? "dark" : "light"] || {};
      for (const key of Object.keys(modeVars)) vars[key] = modeVars[key];
    }
    return vars;
  }
  _haDefaultCssVars() {
    try {
      if (typeof getComputedStyle !== "function" || !document || !document.documentElement) return {};
      const style = getComputedStyle(document.documentElement);
      const keys = [
        "primary-color", "text-primary-color", "primary-background-color", "secondary-background-color",
        "card-background-color", "primary-text-color", "secondary-text-color", "divider-color",
        "accent-color", "warning-color", "ha-card-background",
      ];
      const vars = {};
      keys.forEach((k) => {
        const val = style.getPropertyValue(`--${k}`);
        if (val && val.trim()) vars[k] = val.trim();
      });
      return vars;
    } catch (e) {
      return {};
    }
  }
  _nativeHaThemeEntries() {
    const entries = [
      {
        id: "ha:__default__",
        name: "Default (Home Assistant)",
        colors: this._haVarsToBuilderColors(this._haDefaultCssVars()),
        native: true,
      },
    ];
    const themes = (this._hass && this._hass.themes && this._hass.themes.themes) || {};
    Object.keys(themes)
      .filter((name) => name.indexOf("Theme Builder - ") !== 0)
      .sort((a, b) => a.localeCompare(b))
      .forEach((name) => {
        entries.push({
          id: "ha:" + name,
          name: name,
          colors: this._haVarsToBuilderColors(this._haThemeCssVars(name)),
          native: true,
        });
      });
    return entries;
  }
  _css() {
    return `
      :host {
        --fc-bg: #fbf7e5; --fc-card: #f5f3f0; --fc-border: #e6ddc4; --fc-text: #423d34;
        --fc-text-secondary: #96877a; --fc-accent: #8f5a00; --fc-accent-text: #fff8ea;
        --fc-accent2: #305545; --fc-accent3: #b5583c; --fc-surface-alt: #efe6cf;
        --fc-surface2: #f2eede; --fc-shadow: 0 2px 5px rgba(58, 53, 44, 0.16);
        display: block; font-family: var(--fc-font-family, inherit);
      }
      * { box-sizing: border-box; }
      ha-card { background: var(--fc-bg); background-image: var(--fc-bg-overlay-image, none), var(--fc-bg-image, none); background-size: cover, var(--fc-bg-size, cover); background-position: center, var(--fc-bg-position, center); color: var(--fc-text); border-radius: 14px; padding: 16px; }
      .fh-recipe-box-header { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 10px; flex-wrap: wrap; }
      .fh-recipe-box-title { font-size: 1.25em; font-weight: 800; }
      .recipe-box-actions { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; }
      .recipe-box-select-bar { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 10px; }
      .recipe-box-select-actions { display: flex; gap: 8px; }
      .recipe-box-search-row { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
      .loved-search { flex: 1 1 auto; box-sizing: border-box; font-size: 15px; padding: 10px 12px; border-radius: 8px; border: 1px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); font-family: inherit; }
      .recipe-view-toggle { display: flex; gap: 4px; flex-shrink: 0; }
      .recipe-view-btn { border: 2px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); border-radius: 8px; width: 40px; height: 40px; font-size: 15px; cursor: pointer; }
      .recipe-view-btn.active { background: var(--fc-accent); color: var(--fc-accent-text); border-color: var(--fc-accent); }
      .recipe-sort-select { width: 100%; box-sizing: border-box; padding: 8px 10px; border-radius: 8px; border: 1px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); font-size: 13px; margin-bottom: 10px; }
      .recipe-box-categories { display: flex; gap: 6px; flex-wrap: wrap; margin: -2px 0 12px; }
      .recipe-chip { border: 1px solid var(--fc-border); border-radius: 20px; padding: 5px 12px; font-size: 12px; font-weight: 700; background: var(--fc-card); color: var(--fc-text-secondary); cursor: pointer; white-space: nowrap; }
      .recipe-chip.active { background: var(--fc-accent); border-color: var(--fc-accent); color: var(--fc-accent-text); }
      .suggestion-add-btn { flex: 0 0 auto; min-height: 40px; padding: 0 16px; border: none; border-radius: 10px; background: var(--fc-accent); color: var(--fc-accent-text); font-size: 14px; font-weight: 700; cursor: pointer; box-shadow: var(--fc-shadow); }
      .loved-list.recipe-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(132px, 1fr)); gap: 14px; }
      .loved-list.recipe-list { display: flex; flex-direction: column; gap: 8px; }
      .loved-empty { color: var(--fc-text-secondary); font-style: italic; text-align: center; padding: 20px 0; grid-column: 1 / -1; }
      .recipe-card { position: relative; border-radius: 16px; overflow: hidden; background: var(--fc-card); box-shadow: var(--fc-shadow); cursor: pointer; display: flex; flex-direction: column; transition: transform 0.12s ease; }
      .recipe-card:active { transform: scale(0.97); }
      .recipe-card-media { width: 100%; aspect-ratio: 1 / 1; background-size: cover; background-position: center; background-color: var(--fc-surface-alt); }
      .recipe-card-media-placeholder { display: flex; align-items: center; justify-content: center; background-image: linear-gradient(135deg, var(--fc-surface-alt), var(--fc-surface2)); }
      .recipe-card-media-placeholder span { font-size: 34px; font-weight: 800; color: var(--fc-text-secondary); opacity: 0.6; }
      .recipe-card-heart, .recipe-card-suggest { position: absolute; top: 8px; width: 30px; height: 30px; border-radius: 50%; border: none; background: rgba(255,255,255,0.88); font-size: 15px; display: flex; align-items: center; justify-content: center; cursor: pointer; box-shadow: 0 1px 4px rgba(0,0,0,0.2); padding: 0; }
      .recipe-card-heart { right: 8px; }
      .recipe-card-heart.is-loved { background: rgba(255,255,255,0.95); }
      .recipe-card-suggest.is-suggested { background: #ffe9a8; box-shadow: 0 0 0 2px #f2c94c inset, 0 1px 4px rgba(0,0,0,0.2); }
      .recipe-card-suggest { left: 8px; }
      .recipe-card-body { padding: 8px 10px 10px; flex: 1 1 auto; }
      .recipe-card-name { font-size: 13px; font-weight: 800; line-height: 1.25; color: var(--fc-text); word-break: break-word; }
      .recipe-card-category { display: inline-block; margin-top: 4px; font-size: 10px; font-weight: 700; color: var(--fc-text-secondary); background: var(--fc-surface-alt); border-radius: 8px; padding: 2px 7px; }
      .recipe-row { display: flex; align-items: center; gap: 10px; border-radius: 12px; padding: 8px; background: var(--fc-card); box-shadow: var(--fc-shadow); cursor: pointer; }
      .recipe-row:active { background: var(--fc-surface-alt); }
      .recipe-row-media { width: 52px; height: 52px; flex-shrink: 0; border-radius: 10px; background-size: cover; background-position: center; background-color: var(--fc-surface-alt); display: flex; align-items: center; justify-content: center; }
      .recipe-row-media.recipe-row-media-placeholder { background-image: linear-gradient(135deg, var(--fc-surface-alt), var(--fc-surface2)); }
      .recipe-row-media-placeholder span { font-size: 18px; font-weight: 800; color: var(--fc-text-secondary); opacity: 0.6; }
      .recipe-row-body { flex: 1 1 auto; min-width: 0; }
      .recipe-row-name { font-size: 14px; font-weight: 800; color: var(--fc-text); word-break: break-word; }
      .recipe-row-category { display: inline-block; margin-top: 3px; font-size: 10px; font-weight: 700; color: var(--fc-text-secondary); background: var(--fc-surface-alt); border-radius: 8px; padding: 2px 7px; }
      .recipe-row-actions { display: flex; gap: 6px; flex-shrink: 0; }
      .recipe-row-heart, .recipe-row-suggest { border: none; background: var(--fc-surface-alt); width: 32px; height: 32px; border-radius: 50%; font-size: 15px; display: flex; align-items: center; justify-content: center; cursor: pointer; padding: 0; }
      .recipe-row-heart.is-loved { background: var(--fc-accent); }
      .recipe-row-suggest.is-suggested { background: #ffe9a8; box-shadow: 0 0 0 2px #f2c94c inset; }
      .recipe-row-select-badge, .recipe-card-select-badge { width: 24px; height: 24px; border-radius: 50%; border: 2px solid var(--fc-border); background: var(--fc-card); display: flex; align-items: center; justify-content: center; font-size: 13px; }
      .recipe-card-select-badge { position: absolute; top: 8px; right: 8px; }
      .recipe-card.is-selected, .recipe-row.is-selected { outline: 3px solid var(--fc-accent); }
      .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(40,34,20,0.45); z-index: 1000; align-items: center; justify-content: center; }
      .modal-overlay.open { display: flex; }
      .modal-box { position: relative; background: var(--fc-card-menu, var(--fc-card)); color: var(--fc-text); border-radius: 14px; padding: 24px 22px 18px; width: min(92vw, 480px); max-height: 85vh; overflow-y: auto; box-shadow: 0 8px 30px rgba(58,53,44,0.3); }
      .modal-close { position: absolute; top: 10px; right: 10px; width: 36px; height: 36px; border-radius: 50%; border: none; background: var(--fc-surface-alt); color: var(--fc-text); font-size: 18px; line-height: 1; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: var(--fc-shadow); }
      .modal-box h2 { margin: 0 26px 14px 0; font-size: 1.2em; color: var(--fc-text); }
      .modal-actions { display: flex; gap: 10px; margin-top: 14px; flex-wrap: wrap; }
      .modal-actions button { flex: 1 1 auto; min-height: 44px; border: none; border-radius: 10px; font-size: 15px; font-weight: 600; cursor: pointer; box-shadow: var(--fc-shadow); }
      .btn-save { background: var(--fc-accent); color: var(--fc-accent-text); }
      .btn-clear { background: var(--fc-accent3); color: #fff8ea; }
      .btn-cancel { background: var(--fc-surface-alt); color: var(--fc-text); }
      .dish-detail-photo { width: 100%; max-height: 220px; object-fit: cover; border-radius: 12px; margin-bottom: 10px; }
      .dish-detail-rating { margin-bottom: 8px; }
      .event-info-chip { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 14px; font-size: 13px; font-weight: 700; color: #3a352c; box-shadow: var(--fc-shadow); margin-right: 6px; }
      .pick-loved-btn { border: none; border-radius: 10px; background: var(--fc-surface-alt); color: var(--fc-text); font-size: 14px; font-weight: 700; padding: 10px 14px; cursor: pointer; box-shadow: var(--fc-shadow); }
      .rb-editor-overlay label { display: block; font-size: 12px; font-weight: 700; color: var(--fc-text-secondary); margin: 10px 0 4px; }
      .rb-editor-overlay input[type="text"], .rb-editor-overlay input[type="url"], .rb-editor-overlay textarea { width: 100%; box-sizing: border-box; font-size: 15px; padding: 8px 10px; border-radius: 8px; border: 1px solid var(--fc-border); background: var(--fc-bg); color: var(--fc-text); font-family: inherit; }
      .remind-check-opt { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 400; margin-top: 12px; }
      .rb-image-preview { width: 100%; max-height: 140px; object-fit: cover; border-radius: 10px; margin-top: 8px; }
      .rating-row { display: flex; gap: 10px; margin-top: 12px; }
      .rating-btn { flex: 1 1 auto; min-height: 48px; border-radius: 10px; border: 2px solid var(--fc-border); background: var(--fc-card); font-size: 22px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: var(--fc-shadow); }
      .rating-btn.active-up { background: #f2ddd4; border-color: #cf8f6c; }
      /* v1.118.0+: the full in-card Grocy Recipe Viewer's CSS, copied
         verbatim from family-week-calendar-card.js's own rules for these
         same classes (the markup and the shared methods that populate it
         are the exact same ones too) - see this file's own top comment.
         --fh-header-offset (the calendar card's kiosk-mode header height)
         has no equivalent on this card, so its var() fallback (0px) is
         always what applies here - correct, since this card has no such
         header to offset around. (Was a // JS-style comment, which isn't
         valid CSS - browsers silently stop parsing the stylesheet right
         there, which is why none of the Grocy Recipe Viewer's styling
         below this point ever actually applied. Fixed to a real CSS
         block comment.) */
      .grocy-recipe-viewer-overlay { top: var(--fh-header-offset, 0px); z-index: 1002; align-items: stretch; justify-content: stretch; padding: 0; }
      .grocy-recipe-viewer-overlay .modal-box { background: var(--fc-bg); width: 100%; max-width: 100%; height: calc(100vh - var(--fh-header-offset, 0px)); max-height: calc(100vh - var(--fh-header-offset, 0px)); border-radius: 0; box-shadow: none; box-sizing: border-box; padding: 28px max(22px, calc(50% - 380px)) 60px; overflow-y: auto; }
      .grocy-recipe-viewer-overlay .grocy-recipe-viewer-close { position: fixed; top: calc(14px + var(--fh-header-offset, 0px)); right: 14px; }
      /* Shown only when the viewer was opened via a picker's preview icon (task
      #177) rather than the normal "click a suggestion/meal's link" flow - lets
      someone check out a recipe without it feeling like they've left the
      picker underneath, which stays open and is exactly what "Back" returns
      them to (see _closeGrocyRecipeViewer). */
      .grocy-recipe-viewer-back-btn { display: none; }
      .grocy-recipe-viewer-overlay .grocy-recipe-viewer-back-btn { position: fixed; top: calc(14px + var(--fh-header-offset, 0px)); left: 14px; border: 1px solid var(--fc-border); background: var(--fc-surface-alt); color: var(--fc-text); border-radius: 20px; padding: 8px 16px; font-size: 14px; font-weight: 700; cursor: pointer; }
      .grocy-recipe-viewer-overlay .grocy-recipe-viewer-back-btn:active { background: var(--fc-border); }
      .grocy-recipe-viewer-overlay .grocy-recipe-viewer-title { font-size: 1.8em; text-align: center; margin: 4px 50px 6px; color: var(--fc-accent); }
      .grocy-recipe-viewer-overlay.preview-mode .grocy-recipe-viewer-title { margin-left: 70px; margin-right: 70px; }
      /* v1.114.0+ multi-recipe tabs (task: a meal card with more than one Grocy
      recipe attached - its main recipe plus any "additional recipes" that are
      themselves imported Grocy recipes, not just plain links - now shows every
      one of them as a tab here, so switching between e.g. a main dish and its
      side doesn't mean backing out and re-opening a different recipe). Same
      button-row idiom as .shopping-tabs/.shopping-tab-btn and .settings-tabs/
      .settings-tab-btn elsewhere in this file - a flex row of equal-width
      buttons, one highlighted .active - built dynamically in
      _openGrocyRecipeViewer instead of fixed markup, since a meal's recipe
      count varies. Hidden entirely (see the base "display:none" on the inline
      style in the DOM template) whenever a viewer is opened for just one
      recipe, which is every OTHER call site (additional-recipe links, Expiring
      Soon chips, Recipe Box dish detail, the picker preview icon) as well as a
      meal with only a main recipe. */
      .grocy-recipe-viewer-tabs { display: flex; gap: 8px; margin: 0 0 14px; flex-wrap: wrap; justify-content: center; }
      .grocy-recipe-viewer-tab-btn { flex: 0 1 auto; min-height: 36px; padding: 7px 14px; border-radius: 10px; border: 2px solid var(--fc-border); background: var(--fc-card); color: var(--fc-text); font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: var(--fc-shadow); }
      .grocy-recipe-viewer-tab-btn.active { background: var(--fc-accent); color: var(--fc-accent-text); border-color: var(--fc-accent); }
      /* The photo grabbed during recipe import (see create_grocy_recipe's
      picture upload) or added by hand in Grocy - hidden entirely when the
      recipe has none, in which case the ingredients column below just takes
      the full width (see .grocy-recipe-viewer-columns). */
      .grocy-recipe-viewer-photo { display: none; flex: 1 1 260px; min-width: 220px; max-width: 100%; max-height: 320px; object-fit: cover; border-radius: 12px; align-self: flex-start; }
      .grocy-recipe-viewer-status { font-size: 12px; color: var(--fc-text-secondary); padding: 2px 2px 10px; text-align: center; }
      .grocy-recipe-viewer-status.is-error { color: #b5583c; }
      /* Prep/Cook/Total stat pills (task #250) - only ever populated with real
      values parsed off the recipe (see _renderGrocyRecipeDetail); a recipe with
      none of the three published stays an empty, invisible row via :empty
      rather than showing a blank card, same treatment as every other optional
      field on this page. */
      .grocy-recipe-viewer-stats { display: flex; justify-content: center; gap: 10px; margin: 0 0 16px; flex-wrap: wrap; }
      .grocy-recipe-viewer-stats:empty { display: none; margin: 0; }
      .grocy-recipe-stat { background: var(--fc-surface-alt); border: 1px solid var(--fc-border); border-radius: 10px; padding: 8px 18px; text-align: center; min-width: 78px; }
      .grocy-recipe-stat-label { display: block; font-size: 10px; letter-spacing: 0.06em; text-transform: uppercase; color: var(--fc-text-secondary); margin-bottom: 2px; }
      .grocy-recipe-stat-value { display: block; font-size: 15px; font-weight: 800; color: var(--fc-text); }
      /* Two-column reading layout (task #251) - ingredients (with their own
      scaler) on one side, hero photo on the other; wraps to a single stacked
      column on narrow widths via flex-wrap, and the photo simply isn't in the
      DOM's visible flow at all when the recipe has none (display:none above),
      so the ingredients column naturally takes the full width instead of
      leaving an empty gap next to it. */
      .grocy-recipe-viewer-columns { display: flex; gap: 24px; align-items: flex-start; flex-wrap: wrap; margin-bottom: 10px; }
      .grocy-recipe-viewer-main-col { flex: 1 1 280px; min-width: 240px; }
      .grocy-recipe-viewer-servings { font-size: 12px; color: var(--fc-text-secondary); margin-bottom: 10px; }
      .grocy-recipe-viewer-scale-row { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--fc-text-secondary); margin-bottom: 14px; }
      .grocy-recipe-viewer-scale-row button { border: 1px solid var(--fc-border); background: var(--fc-surface-alt); color: var(--fc-text); border-radius: 8px; width: 28px; height: 28px; font-size: 16px; font-weight: 800; line-height: 1; cursor: pointer; flex-shrink: 0; }
      .grocy-recipe-viewer-scale-row button:active { background: var(--fc-border); }
      .grocy-recipe-viewer-scale-value { font-weight: 800; color: var(--fc-text); min-width: 20px; text-align: center; }
      .grocy-recipe-viewer-ingredients { margin-bottom: 14px; }
      .grocy-recipe-ingredient-group { font-size: 12px; font-weight: 700; color: var(--fc-text-secondary); text-transform: uppercase; letter-spacing: 0.03em; margin: 10px 0 4px; }
      .grocy-recipe-ingredient-group:first-child { margin-top: 0; }
      .grocy-recipe-ingredient-row { display: flex; align-items: flex-start; gap: 10px; padding: 6px 0; font-size: 14px; color: var(--fc-text); border-bottom: 1px solid var(--fc-border); cursor: pointer; }
      .grocy-recipe-ingredient-check { margin-top: 3px; width: 16px; height: 16px; flex-shrink: 0; cursor: pointer; }
      .grocy-recipe-ingredient-row.checked-off { opacity: 0.5; }
      .grocy-recipe-ingredient-row.checked-off .grocy-recipe-ingredient-amount,
      .grocy-recipe-ingredient-row.checked-off > span:last-child { text-decoration: line-through; }
      /* Numbered circular badge (task #251/mockup) standing in for the plain
      amount text that used to lead each row - the amount itself moved into the
      row's second line/span alongside the product name so nothing that used to
      be shown is lost, just restyled. */
      .grocy-recipe-ingredient-badge { flex: 0 0 auto; width: 24px; height: 24px; border-radius: 50%; background: var(--fc-accent); color: var(--fc-accent-text); font-size: 12px; font-weight: 800; display: flex; align-items: center; justify-content: center; margin-top: 1px; }
      .grocy-recipe-ingredient-amount { font-weight: 600; color: var(--fc-text-secondary); }
      .grocy-recipe-ingredient-note { font-size: 12px; color: var(--fc-text-secondary); font-style: italic; }
      /* Numbered Instructions steps (task #252) - parsed from the recipe's own
      "Preparation" block when it has one (see _renderGrocyRecipeDescription);
      recipes without that exact structure never populate this element at all,
      so it stays empty/invisible via :empty and the raw description below
      carries the full instructions instead, same as before this feature. */
      .grocy-recipe-viewer-instructions:empty { display: none; }
      .grocy-recipe-instructions-title { font-size: 1.1em; font-weight: 800; color: var(--fc-accent); margin: 6px 0 10px; }
      .grocy-recipe-instruction-row { display: flex; align-items: flex-start; gap: 12px; padding: 8px 0; font-size: 14px; line-height: 1.5; color: var(--fc-text); cursor: pointer; }
      .grocy-recipe-instruction-check { margin-top: 5px; width: 16px; height: 16px; flex-shrink: 0; cursor: pointer; }
      .grocy-recipe-instruction-row.checked-off { opacity: 0.5; }
      .grocy-recipe-instruction-row.checked-off .grocy-recipe-instruction-text { text-decoration: line-through; }
      .grocy-recipe-step-header { font-size: 1.05em; font-weight: 800; color: var(--fc-text); margin: 14px 0 4px; }
      .grocy-recipe-step-divider { border: none; border-top: 1px solid var(--fc-border); margin: 14px 0; }
      .grocy-recipe-step-image-wrap { margin: 10px 0; }
      .grocy-recipe-step-image { max-width: 100%; border-radius: 10px; display: block; }
      .fh-step-editor-overlay { top: var(--fh-header-offset, 0px); z-index: 1002; align-items: stretch; justify-content: stretch; padding: 0; }
      .fh-step-editor-overlay .fh-step-editor-box { background: var(--fc-bg); width: 100%; max-width: 100%; height: calc(100vh - var(--fh-header-offset, 0px)); max-height: calc(100vh - var(--fh-header-offset, 0px)); border-radius: 0; box-shadow: none; box-sizing: border-box; padding: 28px max(22px, calc(50% - 380px)) 60px; overflow-y: auto; }
      .fh-step-editor-list { display: flex; flex-direction: column; gap: 8px; margin: 10px 0 14px; }
      .fh-step-editor-row { display: flex; align-items: flex-start; gap: 8px; background: var(--fc-surface-alt, #f5f5f5); border-radius: 10px; padding: 8px; }
      .fh-step-editor-drag-handle { flex: 0 0 auto; cursor: grab; touch-action: none; padding: 4px 6px; margin-top: 4px; font-size: 18px; line-height: 1; color: var(--fc-text-secondary, #888); user-select: none; }
      .fh-step-editor-row.fh-step-editor-dragging { opacity: 0.5; box-shadow: 0 6px 16px rgba(0,0,0,0.25); }
      .fh-step-editor-text-input { flex: 1; min-height: 44px; resize: vertical; font-family: inherit; font-size: 14px; padding: 6px 8px; border-radius: 8px; border: 1px solid var(--fc-border); }
      .fh-step-editor-header-input { flex: 1; font-weight: 800; font-size: 14px; padding: 6px 8px; border-radius: 8px; border: 1px solid var(--fc-border); }
      .fh-step-editor-step-num { flex: 0 0 auto; width: 22px; height: 22px; border-radius: 50%; background: var(--fc-accent); color: var(--fc-accent-text); font-size: 12px; font-weight: 800; display: flex; align-items: center; justify-content: center; margin-top: 8px; }
      .fh-step-editor-divider-row { justify-content: space-between; align-items: center; }
      .fh-step-editor-divider-label { color: var(--fc-text-muted, #888); font-size: 13px; flex: 1; text-align: center; }
      .fh-step-editor-image-row { align-items: center; }
      .fh-step-editor-image-preview { flex: 1; max-width: 100%; max-height: 120px; border-radius: 8px; object-fit: cover; }
      .fh-step-editor-row-controls { display: flex; gap: 4px; flex-shrink: 0; }
      .fh-step-editor-row-controls button { width: 28px; height: 28px; border-radius: 6px; border: 1px solid var(--fc-border); background: var(--fc-bg); cursor: pointer; font-size: 13px; padding: 0; }
      .fh-step-editor-row-controls button:disabled { opacity: 0.35; cursor: default; }
      .fh-step-editor-add-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 14px; }
      .fh-step-editor-add-row button { flex: 1 1 auto; }
      .grocy-recipe-instruction-badge { flex: 0 0 auto; width: 26px; height: 26px; border-radius: 50%; background: var(--fc-accent); color: var(--fc-accent-text); font-size: 13px; font-weight: 800; display: flex; align-items: center; justify-content: center; margin-top: 1px; }
      .grocy-recipe-instruction-text { padding-top: 3px; }
      .grocy-recipe-viewer-description { font-size: 14px; line-height: 1.5; color: var(--fc-text); }
      .grocy-recipe-viewer-description img { max-width: 100%; }
      .grocy-recipe-ingredients-accordion { margin: 10px 0; }
      .grocy-recipe-ingredients-accordion .accordion-toggle { font-size: 13px; padding: 8px 10px; }
      .grocy-recipe-ingredients-accordion .accordion-body { padding-left: 4px; }
      .grocy-recipe-viewer-footer { margin-top: 14px; display: flex; flex-direction: column; gap: 8px; }
      .grocy-recipe-viewer-open-btn { width: 100%; box-sizing: border-box; }
      /* Consuming ingredients is a real, one-way Grocy stock deduction (see
         _consumeGrocyRecipeIngredients) - kept visually secondary next to Open in
         Grocy's solid accent button so it doesn't read as the default/expected
         tap, closer to how a "destructive-ish but sometimes wanted" action would
         look in a settings list than a bright primary call to action. */
      .grocy-recipe-viewer-consume-btn { width: 100%; box-sizing: border-box; background: var(--fc-surface-alt, #fff); color: var(--fc-text); border: 1px solid var(--fc-border); box-shadow: none; }
      .grocy-recipe-viewer-overlay .grocy-recipe-viewer-servings { font-size: 14px; }
      .grocy-recipe-viewer-overlay .grocy-recipe-ingredient-row { font-size: 15px; padding: 7px 0; }
      .grocy-recipe-viewer-overlay .grocy-recipe-instruction-row { font-size: 15px; }
      .grocy-recipe-viewer-overlay .grocy-recipe-viewer-description { font-size: 16px; line-height: 1.6; }
      .grocy-recipe-viewer-overlay .grocy-recipe-viewer-footer { max-width: 320px; margin: 14px auto 0; }
      /* Base accordion/section-label classes the ingredients-accordion
         rules above build on (.grocy-recipe-ingredients-accordion
         .accordion-toggle/.accordion-body) - also copied verbatim from the
         calendar card, which already has these for its OTHER accordions
         (this card had none before now). (Same // -> CSS-comment fix as
         above.) */
      .theme-section-label { font-size: 13px; font-weight: 800; color: var(--fc-text); margin: 6px 0 8px; text-transform: uppercase; letter-spacing: 0.02em; }
      .accordion-toggle { width: 100%; display: flex; align-items: center; justify-content: space-between; background: var(--fc-surface-alt); border: none; border-radius: 10px; padding: 10px 12px; cursor: pointer; box-shadow: var(--fc-shadow); }
      .accordion-toggle .theme-section-label { margin: 0; }
      .accordion-chevron { font-size: 12px; color: var(--fc-text-secondary); transition: transform 0.2s ease; }
      .accordion-toggle.open .accordion-chevron { transform: rotate(180deg); }
      .accordion-body { display: none; margin-top: 10px; }
      .accordion-body.open { display: block; }
      .rating-btn.active-down { background: #d8e3e0; border-color: #6f9a94; }
    `;
  }
}

class FamilyHubRecipeBoxCardEditor extends HTMLElement {
  setConfig(config) {
    this._config = config || {};
    this._render();
  }
  set hass(hass) {
    this._hass = hass;
    if (this._form) this._form.hass = hass;
    if (!this._themeOptions) this._fetchThemeOptions();
  }
  // per-card Theme override options - duplicated (not shared/ imported) from family-hub-goals-card.js's own editor
  async _fetchThemeOptions() {
    this._themeOptions = [{ value: "", label: "Use device settings (default)" }];
    if (!this._hass) {
      this._render();
      return;
    }
    try {
      const result = await this._hass.connection.sendMessagePromise({ type: "theme_builder/list" });
      const custom = (result && Array.isArray(result.themes)) ? result.themes : [];
      custom.forEach((t) => {
        if (t && t.id) this._themeOptions.push({ value: t.id, label: "Theme Builder: " + (t.name || t.id) });
      });
    } catch (e) {
    }
    this._themeOptions.push({ value: "ha:__default__", label: "Home Assistant: Default" });
    const themes = (this._hass && this._hass.themes && this._hass.themes.themes) || {};
    Object.keys(themes)
      .filter((name) => name.indexOf("Theme Builder - ") !== 0)
      .sort((a, b) => a.localeCompare(b))
      .forEach((name) => this._themeOptions.push({ value: "ha:" + name, label: "Home Assistant: " + name }));
    this._render();
  }
  _formData() {
    return {
      title: this._config.title,
      theme_override: (typeof this._config.theme_override === "string") ? this._config.theme_override : "",
    };
  }
  _schema() {
    const base = FamilyHubRecipeBoxCard.getConfigForm().schema;
    return base.concat([
      {
        name: "theme_override",
        selector: { select: { mode: "dropdown", options: this._themeOptions || [{ value: "", label: "Use device settings (default)" }] } },
      },
    ]);
  }
  _render() {
    const { computeLabel } = FamilyHubRecipeBoxCard.getConfigForm();
    if (this._built) {
      this._form.schema = this._schema();
      this._form.data = this._formData();
      return;
    }
    this._built = true;
    this.innerHTML = "";
    const form = document.createElement("ha-form");
    form.schema = this._schema();
    form.computeLabel = (s) => (s.name === "theme_override" ? "Theme" : computeLabel(s));
    form.computeHelper = (s) => (
      s.name === "theme_override"
        ? "Pin this one card to a specific theme, or leave on \"Use device settings\" to follow whatever this device/household normally shows."
        : undefined
    );
    form.data = this._formData();
    if (this._hass) form.hass = this._hass;
    form.addEventListener("value-changed", (e) => {
      e.stopPropagation();
      const merged = Object.assign({}, this._config, e.detail.value);
      this._config = merged;
      this.dispatchEvent(new CustomEvent("config-changed", { detail: { config: merged }, bubbles: true, composed: true }));
    });
    this._form = form;
    this.appendChild(form);
  }
}

// applies the Recipe Box shared-logic object above onto this card's own prototype
Object.assign(FamilyHubRecipeBoxCard.prototype, window.__familyHubRecipeBoxShared);

if (!customElements.get("family-hub-recipe-box-card")) customElements.define("family-hub-recipe-box-card", FamilyHubRecipeBoxCard);
if (!customElements.get("family-hub-recipe-box-card-editor")) customElements.define("family-hub-recipe-box-card-editor", FamilyHubRecipeBoxCardEditor);

window.customCards = window.customCards || [];
if (!window.customCards.some((c) => c.type === "family-hub-recipe-box-card")) {
  window.customCards.push({
    type: "family-hub-recipe-box-card",
    name: "Family Hub Recipe Box",
    description: "Your Family Hub Recipe Box (\"Loved Dishes\") as its own dashboard tab - browse, search, add, edit, heart, and suggest dishes. Runs on the exact same shared logic as the Recipe Box modal in the weekly calendar card, so the two always behave identically.",
  });
}
